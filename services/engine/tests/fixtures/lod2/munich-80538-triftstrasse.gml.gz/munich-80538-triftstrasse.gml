<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:tex="http://www.opengis.net/citygml/texturedsurface/1.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:tran="http://www.opengis.net/citygml/transportation/1.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/1.0" xmlns:base="http://www.citygml.org/citygml/profiles/base/1.0" xmlns:bldg="http://www.opengis.net/citygml/building/1.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/1.0" xmlns:dem="http://www.opengis.net/citygml/relief/1.0" xmlns:gen="http://www.opengis.net/citygml/generics/1.0" xmlns:app="http://www.opengis.net/citygml/appearance/1.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/1.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns="http://www.opengis.net/citygml/1.0" xmlns:luse="http://www.opengis.net/citygml/landuse/1.0" xsi:schemaLocation="http://www.opengis.net/citygml/1.0 http://repository.gdi-de.org/schemas/adv/citygml/1.0/cityGMLBaseLoD2.xsd http://www.opengis.net/citygml/building/1.0 http://repository.gdi-de.org/schemas/adv/citygml/building/1.0/buildingLoD2.xsd http://www.opengis.net/citygml/appearance/1.0 http://repository.gdi-de.org/schemas/adv/citygml/appearance/1.0/appearanceLoD2.xsd http://www.opengis.net/citygml/generics/1.0 http://repository.gdi-de.org/schemas/adv/citygml/generics/1.0/genericsLoD2.xsd">
<gml:name>LoD2_32_692_5334_2_BY</gml:name>
<gml:boundedBy>
<gml:Envelope srsName="urn:adv:crs:ETRS89_UTM32*DE_DHHN2016_NH" srsDimension="3">
<gml:lowerCorner>691970.05 5333961.63 504.02</gml:lowerCorner>
<gml:upperCorner>694019.452 5336013.271 616.43</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_59918">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSezx9</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>515.156</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>510.880</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>514.264</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_2000</bldg:function>
<bldg:roofType>1000</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">4.276</bldg:measuredHeight>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_59918_d5c2d547-b702-4644-a839-6793ab8bdd15_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_59918_058d7b6a-499b-4b92-94b1-ffb8ae502649_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_59918_2a4d6109-aba4-487e-a125-93d560f14b1f_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_59918_62f26a9a-f52b-4094-b5c2-29af8b6a6543_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_59918_c5db0b4a-caa5-419c-a16f-8eae30926482_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_59918_e800570b-fe4d-4458-9107-ecd21e55a362_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_59918_f8875ffd-3250-4807-9f9f-9681d8905348_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_59918_b61fc3e0-7e02-462d-aa45-a70d4d2f3021_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_59918_d5c2d547-b702-4644-a839-6793ab8bdd15">
<gen:stringAttribute name="Flaeche">
<gen:value>43.836</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>510.880</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.880</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_59918_d5c2d547-b702-4644-a839-6793ab8bdd15_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692591.675 5335144.235 510.88 692591.671 5335144.212 510.88 692590.052 5335144.499 510.88 692580.787 5335146.137 510.88 692581.372 5335150.122 510.88 692581.825 5335150.07 510.88 692581.801 5335149.909 510.88 692592.287 5335148.189 510.88 692591.675 5335144.235 510.88</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_59918_058d7b6a-499b-4b92-94b1-ffb8ae502649">
<gen:stringAttribute name="Flaeche">
<gen:value>42.347</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>4.276</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.156</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.880</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_59918_058d7b6a-499b-4b92-94b1-ffb8ae502649_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692590.052 5335144.499 510.88 692591.671 5335144.212 510.88 692591.671 5335144.212 514.266 692590.052 5335144.499 514.399 692580.787 5335146.137 515.156 692580.787 5335146.137 510.88 692590.052 5335144.499 510.88</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_59918_2a4d6109-aba4-487e-a125-93d560f14b1f">
<gen:stringAttribute name="Flaeche">
<gen:value>0.690</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>4.239</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.119</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.880</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_59918_2a4d6109-aba4-487e-a125-93d560f14b1f_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692581.825 5335150.07 510.88 692581.825 5335150.07 515.119 692581.801 5335149.909 515.119 692581.801 5335149.909 510.88 692581.825 5335150.07 510.88</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_59918_62f26a9a-f52b-4094-b5c2-29af8b6a6543">
<gen:stringAttribute name="Flaeche">
<gen:value>13.623</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.386</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>514.266</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.880</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_59918_62f26a9a-f52b-4094-b5c2-29af8b6a6543_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692591.671 5335144.212 510.88 692591.675 5335144.235 510.88 692592.287 5335148.189 510.88 692592.287 5335148.189 514.264 692591.675 5335144.235 514.266 692591.671 5335144.212 514.266 692591.671 5335144.212 510.88</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_59918_c5db0b4a-caa5-419c-a16f-8eae30926482">
<gen:stringAttribute name="Flaeche">
<gen:value>40.501</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>4.239</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.119</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.880</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_59918_c5db0b4a-caa5-419c-a16f-8eae30926482_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692581.801 5335149.909 510.88 692581.801 5335149.909 515.119 692592.287 5335148.189 514.264 692592.287 5335148.189 510.88 692581.801 5335149.909 510.88</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_59918_e800570b-fe4d-4458-9107-ecd21e55a362">
<gen:stringAttribute name="Flaeche">
<gen:value>17.222</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>4.276</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.156</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.880</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_59918_e800570b-fe4d-4458-9107-ecd21e55a362_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692580.787 5335146.137 510.88 692580.787 5335146.137 515.156 692581.372 5335150.122 515.156 692581.372 5335150.122 510.88 692580.787 5335146.137 510.88</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_59918_f8875ffd-3250-4807-9f9f-9681d8905348">
<gen:stringAttribute name="Flaeche">
<gen:value>1.941</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>4.276</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.156</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.880</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_59918_f8875ffd-3250-4807-9f9f-9681d8905348_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692581.372 5335150.122 510.88 692581.372 5335150.122 515.156 692581.825 5335150.07 515.119 692581.825 5335150.07 510.88 692581.372 5335150.122 510.88</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_59918_b61fc3e0-7e02-462d-aa45-a70d4d2f3021">
<gen:stringAttribute name="Dachneigung">
<gen:value>85.396</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>98.317</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>43.978</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>4.276</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.156</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>3.384</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>514.264</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_59918_b61fc3e0-7e02-462d-aa45-a70d4d2f3021_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692590.052 5335144.499 514.399 692591.671 5335144.212 514.266 692591.675 5335144.235 514.266 692592.287 5335148.189 514.264 692581.801 5335149.909 515.119 692581.825 5335150.07 515.119 692581.372 5335150.122 515.156 692580.787 5335146.137 515.156 692590.052 5335144.499 514.399</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006471">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSezyr</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>533.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>510.354</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>526.096</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_9998</bldg:function>
<bldg:roofType>3100</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">22.966</bldg:measuredHeight>
<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_dbcb780a-304e-42cc-9d19-5b82a60b2ddc_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_123d37de-7e71-459c-90b6-72f57fe44bf8_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_1351c828-08d3-419a-b25e-9cf49bf2dd05_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_3689ff27-3721-4f2b-a391-dc3c60425d26_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_3773eb23-0dca-491b-86e6-7a97b1bfa64b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_439b5d61-5b05-4522-bfae-484daa11e73a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_451b63bf-6613-40cc-9d13-5687b6191008_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_474f43b9-f934-4cad-bf38-0a83bef6bd0e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_56d15268-ea36-44dc-a166-1af4f0444764_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_5b4b936a-f011-4857-95cd-6909f9f1bc00_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_8b0083f2-94b1-474e-9c19-b9392712447f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_9f6a5ea6-3629-4b01-b788-0145a57658ad_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_c1707999-eaef-41f7-a2a2-0de05fb1fd75_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_c63b8311-e213-41f9-9313-537191aca5af_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_c73735af-2af5-4be9-9262-2f30b2cfde8d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_c89065b2-79b2-4082-b9ba-5f4841ca25d4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_e5c9607b-a480-493d-bedf-f607831b9d68_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_e9f5f718-c474-4124-b1e2-2aa4673f96dc_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_19a363be-0dee-4806-81fb-6d4dd25a2ddb_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_3de8dea2-9f46-40bb-8960-b35b6fdfcbf4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_5ebb5c34-2617-4bf9-a520-320e0f7bb984_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_9cded6b0-a512-4246-a3a0-112af6722c0c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_a55a570f-2d1f-46eb-9b5c-f02c21acb1a8_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006471_cfb75140-bb7e-4761-b593-3436db8759eb_2_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006471_dbcb780a-304e-42cc-9d19-5b82a60b2ddc_2">
<gen:stringAttribute name="Flaeche">
<gen:value>450.077</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_dbcb780a-304e-42cc-9d19-5b82a60b2ddc_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.48 5335126.18 510.35 692600.02 5335125.22 510.35 692597.27 5335119.49 510.35 692578.93 5335122.04 510.35 692577.91 5335123.42 510.35 692577.05 5335124.58 510.35 692577.77 5335129.52 510.35 692578.35 5335129.43 510.35 692580.79 5335146.14 510.35 692591.67 5335144.21 510.35 692595.14 5335143.63 510.35 692594.11 5335137.01 510.35 692592.83 5335137.19 510.35 692592.49 5335134.75 510.35 692596.41 5335134.13 510.35 692600.1 5335132.26 510.35 692602.82 5335130.88 510.35 692600.48 5335126.18 510.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_123d37de-7e71-459c-90b6-72f57fe44bf8_2">
<gen:stringAttribute name="Flaeche">
<gen:value>64.667</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.190</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.544</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_123d37de-7e71-459c-90b6-72f57fe44bf8_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692593.647 5335134.567 526.468 692596.41 5335134.13 526.518 692596.41 5335134.13 510.35 692592.49 5335134.75 510.35 692592.49 5335134.75 527.544 692593.647 5335134.567 526.468</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_1351c828-08d3-419a-b25e-9cf49bf2dd05_2">
<gen:stringAttribute name="Flaeche">
<gen:value>176.187</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.139</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.493</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_1351c828-08d3-419a-b25e-9cf49bf2dd05_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692591.67 5335144.21 526.493 692591.67 5335144.21 510.35 692580.79 5335146.14 510.35 692580.79 5335146.14 526.096 692591.67 5335144.21 526.493</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_3689ff27-3721-4f2b-a391-dc3c60425d26_2">
<gen:stringAttribute name="Flaeche">
<gen:value>56.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.224</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.578</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_3689ff27-3721-4f2b-a391-dc3c60425d26_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692594.854 5335143.678 526.578 692595.14 5335143.63 526.311 692595.14 5335143.63 510.35 692591.67 5335144.21 510.35 692591.67 5335144.21 526.493 692594.854 5335143.678 526.578</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_3773eb23-0dca-491b-86e6-7a97b1bfa64b_2">
<gen:stringAttribute name="Flaeche">
<gen:value>107.134</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.017</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.371</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_3773eb23-0dca-491b-86e6-7a97b1bfa64b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692595.14 5335143.63 526.311 692594.11 5335137.01 526.371 692594.11 5335137.01 510.35 692595.14 5335143.63 510.35 692595.14 5335143.63 526.311</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_439b5d61-5b05-4522-bfae-484daa11e73a_2">
<gen:stringAttribute name="Flaeche">
<gen:value>279.874</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.592</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.946</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_439b5d61-5b05-4522-bfae-484daa11e73a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692580.662 5335145.264 526.946 692580.79 5335146.14 526.096 692580.79 5335146.14 510.35 692578.35 5335129.43 510.35 692578.35 5335129.43 526.945 692580.662 5335145.264 526.946</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_451b63bf-6613-40cc-9d13-5687b6191008_2">
<gen:stringAttribute name="Flaeche">
<gen:value>23.754</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.794</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.148</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_451b63bf-6613-40cc-9d13-5687b6191008_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.48 5335126.18 510.35 692600.48 5335126.18 533.148 692600.02 5335125.22 532.181 692600.02 5335125.22 510.35 692600.48 5335126.18 510.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_474f43b9-f934-4cad-bf38-0a83bef6bd0e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>120.405</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.827</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.181</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_474f43b9-f934-4cad-bf38-0a83bef6bd0e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.02 5335125.22 532.181 692597.27 5335119.49 526.408 692597.27 5335119.49 510.35 692600.02 5335125.22 510.35 692600.02 5335125.22 532.181</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_56d15268-ea36-44dc-a166-1af4f0444764_2">
<gen:stringAttribute name="Flaeche">
<gen:value>109.009</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.966</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_56d15268-ea36-44dc-a166-1af4f0444764_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.48 5335126.18 510.35 692602.82 5335130.88 510.35 692602.82 5335130.88 528.745 692600.565 5335126.35 533.32 692600.48 5335126.18 533.148 692600.48 5335126.18 510.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_5b4b936a-f011-4857-95cd-6909f9f1bc00_2">
<gen:stringAttribute name="Flaeche">
<gen:value>80.155</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.053</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.407</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_5b4b936a-f011-4857-95cd-6909f9f1bc00_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692577.05 5335124.58 510.35 692577.05 5335124.58 526.407 692577.77 5335129.52 526.405 692577.77 5335129.52 510.35 692577.05 5335124.58 510.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_8b0083f2-94b1-474e-9c19-b9392712447f_2">
<gen:stringAttribute name="Flaeche">
<gen:value>42.377</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.204</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_8b0083f2-94b1-474e-9c19-b9392712447f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692592.83 5335137.19 527.558 692592.49 5335134.75 527.544 692592.49 5335134.75 510.35 692592.83 5335137.19 510.35 692592.83 5335137.19 527.558</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_9f6a5ea6-3629-4b01-b788-0145a57658ad_2">
<gen:stringAttribute name="Flaeche">
<gen:value>69.533</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.445</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.799</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_9f6a5ea6-3629-4b01-b788-0145a57658ad_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692596.41 5335134.13 510.35 692596.41 5335134.13 526.518 692600.1 5335132.26 527.799 692600.1 5335132.26 510.35 692596.41 5335134.13 510.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_c1707999-eaef-41f7-a2a2-0de05fb1fd75_2">
<gen:stringAttribute name="Flaeche">
<gen:value>21.476</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.204</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_c1707999-eaef-41f7-a2a2-0de05fb1fd75_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692594.11 5335137.01 510.35 692594.11 5335137.01 526.371 692592.83 5335137.19 527.558 692592.83 5335137.19 510.35 692594.11 5335137.01 510.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_c63b8311-e213-41f9-9313-537191aca5af_2">
<gen:stringAttribute name="Flaeche">
<gen:value>27.729</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.169</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.523</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_c63b8311-e213-41f9-9313-537191aca5af_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692577.91 5335123.42 510.35 692578.93 5335122.04 510.35 692578.93 5335122.04 526.408 692578.83 5335122.176 526.523 692577.91 5335123.42 526.504 692577.91 5335123.42 510.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_c73735af-2af5-4be9-9262-2f30b2cfde8d_2">
<gen:stringAttribute name="Flaeche">
<gen:value>54.664</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.391</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.745</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_c73735af-2af5-4be9-9262-2f30b2cfde8d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.1 5335132.26 527.799 692602.82 5335130.88 528.745 692602.82 5335130.88 510.35 692600.1 5335132.26 510.35 692600.1 5335132.26 527.799</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_c89065b2-79b2-4082-b9ba-5f4841ca25d4_2">
<gen:stringAttribute name="Flaeche">
<gen:value>9.582</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.591</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.945</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_c89065b2-79b2-4082-b9ba-5f4841ca25d4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692577.77 5335129.52 510.35 692577.77 5335129.52 526.405 692578.35 5335129.43 526.945 692578.35 5335129.43 510.35 692577.77 5335129.52 510.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_e5c9607b-a480-493d-bedf-f607831b9d68_2">
<gen:stringAttribute name="Flaeche">
<gen:value>23.309</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.150</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.504</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_e5c9607b-a480-493d-bedf-f607831b9d68_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692577.05 5335124.58 510.35 692577.91 5335123.42 510.35 692577.91 5335123.42 526.504 692577.124 5335124.481 526.487 692577.05 5335124.58 526.407 692577.05 5335124.58 510.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006471_e9f5f718-c474-4124-b1e2-2aa4673f96dc_2">
<gen:stringAttribute name="Flaeche">
<gen:value>297.331</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.054</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.408</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_e9f5f718-c474-4124-b1e2-2aa4673f96dc_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692597.27 5335119.49 526.408 692578.93 5335122.04 526.408 692578.93 5335122.04 510.35 692597.27 5335119.49 510.35 692597.27 5335119.49 526.408</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006471_19a363be-0dee-4806-81fb-6d4dd25a2ddb_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>52.535</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>234.418</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>16.059</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.966</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.133</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.487</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_19a363be-0dee-4806-81fb-6d4dd25a2ddb_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692577.91 5335123.42 526.504 692578.83 5335122.176 526.523 692585.223 5335128.483 533.32 692577.124 5335124.481 526.487 692577.91 5335123.42 526.504</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006471_3de8dea2-9f46-40bb-8960-b35b6fdfcbf4_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.187</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>7.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>76.057</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.966</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.742</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.096</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_3de8dea2-9f46-40bb-8960-b35b6fdfcbf4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692591.67 5335144.21 526.493 692580.79 5335146.14 526.096 692580.662 5335145.264 526.946 692586.574 5335137.734 533.32 692594.854 5335143.678 526.578 692591.67 5335144.21 526.493</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006471_5ebb5c34-2617-4bf9-a520-320e0f7bb984_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>47.419</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>278.306</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>145.629</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.966</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.051</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.405</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_5ebb5c34-2617-4bf9-a520-320e0f7bb984_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692585.223 5335128.483 533.32 692586.574 5335137.734 533.32 692580.662 5335145.264 526.946 692578.35 5335129.43 526.945 692577.77 5335129.52 526.405 692577.05 5335124.58 526.407 692577.124 5335124.481 526.487 692585.223 5335128.483 533.32</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006471_9cded6b0-a512-4246-a3a0-112af6722c0c_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.361</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>7.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>115.624</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.966</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.114</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.468</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_9cded6b0-a512-4246-a3a0-112af6722c0c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.1 5335132.26 527.799 692596.41 5335134.13 526.518 692593.647 5335134.567 526.468 692585.223 5335128.483 533.32 692600.565 5335126.35 533.32 692602.82 5335130.88 528.745 692600.1 5335132.26 527.799</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006471_a55a570f-2d1f-46eb-9b5c-f02c21acb1a8_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>47.418</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>98.301</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>91.740</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.966</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.957</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.311</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_a55a570f-2d1f-46eb-9b5c-f02c21acb1a8_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692592.83 5335137.19 527.558 692594.11 5335137.01 526.371 692595.14 5335143.63 526.311 692594.854 5335143.678 526.578 692586.574 5335137.734 533.32 692585.223 5335128.483 533.32 692593.647 5335134.567 526.468 692592.49 5335134.75 527.544 692592.83 5335137.19 527.558</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006471_cfb75140-bb7e-4761-b593-3436db8759eb_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.361</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>187.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>171.330</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.966</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.054</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.408</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006471_cfb75140-bb7e-4761-b593-3436db8759eb_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692597.27 5335119.49 526.408 692600.02 5335125.22 532.181 692600.48 5335126.18 533.148 692600.565 5335126.35 533.32 692585.223 5335128.483 533.32 692578.83 5335122.176 526.523 692578.93 5335122.04 526.408 692597.27 5335119.49 526.408</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>Triftstraße 4</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006477">
<creationDate>2015-09-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSezik</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>532.143</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>527.341</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_1000</bldg:function>
<bldg:roofType>2100</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">22.233</bldg:measuredHeight>
<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_55ce4608-93db-4f42-85a3-98e0650aa172_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_04f82128-6552-4bb1-853e-85cbf4b7f1d3_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_0c7a0698-34c7-4e67-b2fb-13ee4896aec1_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_3f64ddac-5c6a-427c-9fae-8e269d62bbe6_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_4a7fa6d3-69ed-4d02-b6c3-4649a1dc08b7_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_6896a846-34b1-48a5-9a2e-48f533f20e92_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_707485dc-1693-412a-b468-f512d333e1bd_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_770c1daf-8585-42be-bfb5-f3843db41cda_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_7d3fb1ab-10f1-4c92-8784-517d884a6ecb_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_91d154a7-0ab2-4665-8e70-3cfa0af0cbb2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_a9de10ba-40b4-4768-bf34-b1c8f3c7e92f_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_d9d70868-3c20-4f84-8433-d473f3c61ac2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_e972193a-7a6d-4dbc-a124-cc95c5c515c5_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_f5eb5038-1d44-4531-9ab7-0c1079d9da54_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_8431ab6b-2e26-4787-8dc4-c24b3ab3909c_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_9b8d6c8e-cec6-4c64-8cec-a880fa13c2e8_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006477_aadfbac2-9df1-4e6d-93f9-c474a7f02395_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006477_55ce4608-93db-4f42-85a3-98e0650aa172">
<gen:stringAttribute name="Flaeche">
<gen:value>345.391</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_55ce4608-93db-4f42-85a3-98e0650aa172_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692621.604 5335132.482 509.91 692617.178 5335123.525 509.91 692614.777 5335118.663 509.91 692614.331 5335117.76 509.91 692614.313 5335117.725 509.91 692611.485 5335111.971 509.91 692601.878 5335117.055 509.91 692597.271 5335119.493 509.91 692600.019 5335125.224 509.91 692600.046 5335125.279 509.91 692600.482 5335126.183 509.91 692602.821 5335130.877 509.91 692607.526 5335128.502 509.91 692607.691 5335128.419 509.91 692609.671 5335127.42 509.91 692609.703 5335127.479 509.91 692612.672 5335133.102 509.91 692611.169 5335133.654 509.91 692611.019 5335134.939 509.91 692614.289 5335141.413 509.91 692623.598 5335136.523 509.91 692621.604 5335132.482 509.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_04f82128-6552-4bb1-853e-85cbf4b7f1d3">
<gen:stringAttribute name="Flaeche">
<gen:value>280.308</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.430</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.341</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_04f82128-6552-4bb1-853e-85cbf4b7f1d3_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692601.878 5335117.055 509.91 692611.485 5335111.971 509.91 692611.485 5335111.971 527.341 692601.878 5335117.055 527.341 692597.271 5335119.493 527.341 692597.271 5335119.493 509.91 692601.878 5335117.055 509.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_0c7a0698-34c7-4e67-b2fb-13ee4896aec1">
<gen:stringAttribute name="Flaeche">
<gen:value>29.109</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.537</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.447</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_0c7a0698-34c7-4e67-b2fb-13ee4896aec1_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692612.672 5335133.102 509.91 692612.672 5335133.102 528.447 692611.169 5335133.654 527.741 692611.169 5335133.654 509.91 692612.672 5335133.102 509.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_3f64ddac-5c6a-427c-9fae-8e269d62bbe6">
<gen:stringAttribute name="Flaeche">
<gen:value>22.870</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.831</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.741</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_3f64ddac-5c6a-427c-9fae-8e269d62bbe6_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692611.169 5335133.654 509.91 692611.169 5335133.654 527.741 692611.019 5335134.939 527.429 692611.019 5335134.939 509.91 692611.169 5335133.654 509.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_4a7fa6d3-69ed-4d02-b6c3-4649a1dc08b7">
<gen:stringAttribute name="Flaeche">
<gen:value>365.516</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.230</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.141</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_4a7fa6d3-69ed-4d02-b6c3-4649a1dc08b7_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692614.313 5335117.725 509.91 692614.331 5335117.76 509.91 692614.777 5335118.663 509.91 692617.178 5335123.525 509.91 692621.604 5335132.482 509.91 692621.604 5335132.482 532.121 692617.178 5335123.525 532.118 692614.777 5335118.663 532.117 692614.331 5335117.76 532.117 692614.313 5335117.725 532.141 692614.313 5335117.725 509.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_6896a846-34b1-48a5-9a2e-48f533f20e92">
<gen:stringAttribute name="Flaeche">
<gen:value>135.382</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.458</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.368</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_6896a846-34b1-48a5-9a2e-48f533f20e92_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692607.526 5335128.502 527.388 692607.691 5335128.419 527.386 692609.671 5335127.42 528.368 692609.671 5335127.42 509.91 692607.691 5335128.419 509.91 692607.526 5335128.502 509.91 692602.821 5335130.877 509.91 692602.821 5335130.877 527.465 692607.526 5335128.502 527.388</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_707485dc-1693-412a-b468-f512d333e1bd">
<gen:stringAttribute name="Flaeche">
<gen:value>125.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.187</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.098</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_707485dc-1693-412a-b468-f512d333e1bd_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692597.271 5335119.493 509.91 692597.271 5335119.493 527.341 692600.019 5335125.224 532.098 692600.019 5335125.224 509.91 692597.271 5335119.493 509.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_770c1daf-8585-42be-bfb5-f3843db41cda">
<gen:stringAttribute name="Flaeche">
<gen:value>102.376</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.482</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.392</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_770c1daf-8585-42be-bfb5-f3843db41cda_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.482 5335126.183 509.91 692600.482 5335126.183 531.392 692602.821 5335130.877 527.465 692602.821 5335130.877 509.91 692600.482 5335126.183 509.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_7d3fb1ab-10f1-4c92-8784-517d884a6ecb">
<gen:stringAttribute name="Flaeche">
<gen:value>23.294</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.233</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.143</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_7d3fb1ab-10f1-4c92-8784-517d884a6ecb_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.019 5335125.224 532.098 692600.046 5335125.279 532.143 692600.482 5335126.183 531.392 692600.482 5335126.183 509.91 692600.046 5335125.279 509.91 692600.019 5335125.224 509.91 692600.019 5335125.224 532.098</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_91d154a7-0ab2-4665-8e70-3cfa0af0cbb2">
<gen:stringAttribute name="Flaeche">
<gen:value>209.034</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.211</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.121</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_91d154a7-0ab2-4665-8e70-3cfa0af0cbb2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692614.289 5335141.413 509.91 692614.289 5335141.413 527.46 692623.598 5335136.523 532.121 692623.598 5335136.523 509.91 692614.289 5335141.413 509.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_a9de10ba-40b4-4768-bf34-b1c8f3c7e92f">
<gen:stringAttribute name="Flaeche">
<gen:value>127.151</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.230</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.141</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_a9de10ba-40b4-4768-bf34-b1c8f3c7e92f_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692614.313 5335117.725 509.91 692614.313 5335117.725 532.141 692611.485 5335111.971 527.341 692611.485 5335111.971 509.91 692614.313 5335117.725 509.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_d9d70868-3c20-4f84-8433-d473f3c61ac2">
<gen:stringAttribute name="Flaeche">
<gen:value>118.851</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.537</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.447</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_d9d70868-3c20-4f84-8433-d473f3c61ac2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692609.671 5335127.42 528.368 692609.703 5335127.479 528.369 692612.672 5335133.102 528.447 692612.672 5335133.102 509.91 692609.703 5335127.479 509.91 692609.671 5335127.42 509.91 692609.671 5335127.42 528.368</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_e972193a-7a6d-4dbc-a124-cc95c5c515c5">
<gen:stringAttribute name="Flaeche">
<gen:value>100.083</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.211</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.121</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_e972193a-7a6d-4dbc-a124-cc95c5c515c5_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692623.598 5335136.523 509.91 692623.598 5335136.523 532.121 692621.604 5335132.482 532.121 692621.604 5335132.482 509.91 692623.598 5335136.523 509.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006477_f5eb5038-1d44-4531-9ab7-0c1079d9da54">
<gen:stringAttribute name="Flaeche">
<gen:value>127.155</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.550</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.460</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_f5eb5038-1d44-4531-9ab7-0c1079d9da54_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692611.019 5335134.939 509.91 692611.019 5335134.939 527.429 692614.289 5335141.413 527.46 692614.289 5335141.413 509.91 692611.019 5335134.939 509.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006477_8431ab6b-2e26-4787-8dc4-c24b3ab3909c">
<gen:stringAttribute name="Dachneigung">
<gen:value>53.185</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>30.120</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>85.640</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.233</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.143</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.475</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.386</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_8431ab6b-2e26-4787-8dc4-c24b3ab3909c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692604.716 5335122.807 532.143 692614.313 5335117.725 532.141 692614.331 5335117.76 532.117 692607.691 5335128.419 527.386 692607.526 5335128.502 527.388 692602.821 5335130.877 527.465 692600.482 5335126.183 531.392 692600.046 5335125.279 532.143 692604.716 5335122.807 532.143</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006477_9b8d6c8e-cec6-4c64-8cec-a880fa13c2e8">
<gen:stringAttribute name="Dachneigung">
<gen:value>53.169</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>210.120</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>129.063</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.233</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.143</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.430</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.341</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_9b8d6c8e-cec6-4c64-8cec-a880fa13c2e8_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692601.878 5335117.055 527.341 692611.485 5335111.971 527.341 692614.313 5335117.725 532.141 692604.716 5335122.807 532.143 692600.046 5335125.279 532.143 692600.019 5335125.224 532.098 692597.271 5335119.493 527.341 692601.878 5335117.055 527.341</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006477_aadfbac2-9df1-4e6d-93f9-c474a7f02395">
<gen:stringAttribute name="Dachneigung">
<gen:value>66.086</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>298.494</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>189.824</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.211</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.121</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.475</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.386</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006477_aadfbac2-9df1-4e6d-93f9-c474a7f02395_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692614.331 5335117.76 532.117 692614.777 5335118.663 532.117 692617.178 5335123.525 532.118 692621.604 5335132.482 532.121 692623.598 5335136.523 532.121 692614.289 5335141.413 527.46 692611.019 5335134.939 527.429 692611.169 5335133.654 527.741 692612.672 5335133.102 528.447 692609.703 5335127.479 528.369 692609.671 5335127.42 528.368 692607.691 5335128.419 527.386 692614.331 5335117.76 532.117</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>Robert-Koch-Straße 1</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006485">
<creationDate>2023-06-05</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSezfn</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>531.620</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>523.933</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_1000</bldg:function>
<bldg:roofType>3100</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">21.916</bldg:measuredHeight>
<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_75bec0e4-2ed2-4569-a7b0-61861a0906d1_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_081c3a17-baee-4744-8947-332e456cca46_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_11b27702-8831-4a38-beda-5828d4b8a469_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_165ecc8b-c5a5-4219-8ffb-35a1e3210158_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_1ca4e9a4-da76-4ba9-a74d-f2e24a31dea6_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_27a8b718-4e65-4a76-ba66-2ec1df468577_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_2c8ba546-260c-480c-ac8b-f8f21168ba6d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_438c114b-7993-45db-bb09-e9189088cb8c_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_523793b6-1be5-42e9-b707-fcc9020a6a35_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_5e5d1f8e-a24e-418f-b3a7-dd835cd527b4_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_796f74bb-31cc-413b-882f-46ff3c3ffd65_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_804afd61-9d69-4415-a076-e34e3372fa5f_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_8fdb92b2-eef4-4867-a92e-ca82a001861d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_93ca9f87-a50e-43c8-bb5c-37078b15f7fe_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_98257a32-6f0a-4ac1-a8db-bf2c88b6c101_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_98304609-7541-4b62-8491-6f8e867a77b5_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_a19a672b-d6f7-4ec6-94d4-d17bee429100_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_a733125b-80a6-42fe-97fb-73242d1c48a7_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_a8c62dd0-d4d6-47dc-9344-779ce7a45113_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_c062d8cc-4a89-4fde-8222-67fd4adb7194_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_f6564848-1698-47da-a2a3-9225cfe05f5f_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_f72af8e3-8e41-40c2-a7c3-f49f17bc4d87_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_ff778644-5f22-43b1-9294-0e8635d561cc_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_200cca42-ee8c-40f8-9e1b-ad214b0cc3b3_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_2a41eab9-4602-4ca6-ab74-5e11f20e7e0a_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_3bda6476-fd75-4183-aecb-de7fd59dca0f_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_4a228900-89cd-4008-aec8-5729b3d9dca9_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_aec09f5e-eb83-4991-89f0-cd0b59a3f2a2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_b2f39202-aa74-4ca5-8827-94e432a22c8e_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_bcc6e1a5-7582-4773-a87f-a42e87c579a4_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006485_d110fe0c-b281-48d1-9c7a-bedaefae3ac3_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006485_75bec0e4-2ed2-4569-a7b0-61861a0906d1">
<gen:stringAttribute name="Flaeche">
<gen:value>452.779</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_75bec0e4-2ed2-4569-a7b0-61861a0906d1_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692602.62 5335089.57 509.704 692601.71 5335087.97 509.704 692601.46 5335088.08 509.704 692601.24 5335088.22 509.704 692598.42 5335089.65 509.704 692590.91 5335093.4 509.704 692589.14 5335093.59 509.704 692589.05 5335091.98 509.704 692586.21 5335092.12 509.704 692585.96 5335087 509.704 692582.31 5335087.61 509.704 692581.09 5335087.83 509.704 692574.05 5335088.03 509.704 692574.09 5335088.45 509.704 692574.47 5335096.44 509.704 692574.99 5335107.55 509.704 692592.7 5335105.08 509.704 692604.47 5335098.91 509.704 692606.86 5335097.67 509.704 692607.34 5335097.41 509.704 692604.49 5335092.68 509.704 692602.62 5335089.57 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_081c3a17-baee-4744-8947-332e456cca46">
<gen:stringAttribute name="Flaeche">
<gen:value>120.247</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.729</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.433</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_081c3a17-baee-4744-8947-332e456cca46_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692590.91 5335093.4 509.704 692598.42 5335089.65 509.704 692598.42 5335089.65 524.004 692590.994 5335093.358 523.933 692590.994 5335093.358 529.39 692590.91 5335093.4 529.433 692590.91 5335093.4 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_11b27702-8831-4a38-beda-5828d4b8a469">
<gen:stringAttribute name="Flaeche">
<gen:value>85.441</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.689</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.393</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_11b27702-8831-4a38-beda-5828d4b8a469_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692607.34 5335097.41 509.704 692607.34 5335097.41 523.96 692604.49 5335092.68 526.393 692604.49 5335092.68 509.704 692607.34 5335097.41 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_165ecc8b-c5a5-4219-8ffb-35a1e3210158">
<gen:stringAttribute name="Flaeche">
<gen:value>8.314</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.711</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.415</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_165ecc8b-c5a5-4219-8ffb-35a1e3210158_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692574.05 5335088.03 509.704 692574.05 5335088.03 529.408 692574.09 5335088.45 529.415 692574.09 5335088.45 509.704 692574.05 5335088.03 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_1ca4e9a4-da76-4ba9-a74d-f2e24a31dea6">
<gen:stringAttribute name="Flaeche">
<gen:value>157.662</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.711</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.415</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_1ca4e9a4-da76-4ba9-a74d-f2e24a31dea6_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692574.47 5335096.44 529.414 692574.47 5335096.44 509.704 692574.09 5335088.45 509.704 692574.09 5335088.45 529.415 692574.47 5335096.44 529.414</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_27a8b718-4e65-4a76-ba66-2ec1df468577">
<gen:stringAttribute name="Flaeche">
<gen:value>35.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.743</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.447</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_27a8b718-4e65-4a76-ba66-2ec1df468577_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692589.14 5335093.59 509.704 692590.91 5335093.4 509.704 692590.91 5335093.4 529.433 692590.882 5335093.403 529.447 692589.14 5335093.59 529.427 692589.14 5335093.59 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_2c8ba546-260c-480c-ac8b-f8f21168ba6d">
<gen:stringAttribute name="Flaeche">
<gen:value>27.102</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.130</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.834</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_2c8ba546-260c-480c-ac8b-f8f21168ba6d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692602.62 5335089.57 509.704 692602.62 5335089.57 524.834 692601.71 5335087.97 524.022 692601.71 5335087.97 509.704 692602.62 5335089.57 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_438c114b-7993-45db-bb09-e9189088cb8c">
<gen:stringAttribute name="Flaeche">
<gen:value>49.741</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.686</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.390</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.229</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.933</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_438c114b-7993-45db-bb09-e9189088cb8c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692592.783 5335105.036 529.39 692590.994 5335093.358 529.39 692590.994 5335093.358 523.933 692591.893 5335099.229 526.413 692592.783 5335105.036 523.96 692592.783 5335105.036 529.39</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_523793b6-1be5-42e9-b707-fcc9020a6a35">
<gen:stringAttribute name="Flaeche">
<gen:value>26.457</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.566</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_523793b6-1be5-42e9-b707-fcc9020a6a35_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692582.31 5335087.61 509.704 692582.31 5335087.61 530.823 692581.09 5335087.83 531.27 692581.09 5335087.83 509.704 692582.31 5335087.61 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_5e5d1f8e-a24e-418f-b3a7-dd835cd527b4">
<gen:stringAttribute name="Flaeche">
<gen:value>353.042</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.744</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.448</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_5e5d1f8e-a24e-418f-b3a7-dd835cd527b4_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692592.669 5335105.084 529.448 692592.7 5335105.08 529.433 692592.7 5335105.08 509.704 692574.99 5335107.55 509.704 692574.99 5335107.55 529.408 692575.1 5335107.535 529.448 692592.669 5335105.084 529.448</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_796f74bb-31cc-413b-882f-46ff3c3ffd65">
<gen:stringAttribute name="Flaeche">
<gen:value>45.243</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.319</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.023</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_796f74bb-31cc-413b-882f-46ff3c3ffd65_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692601.24 5335088.22 509.704 692601.24 5335088.22 524.023 692598.42 5335089.65 524.004 692598.42 5335089.65 509.704 692601.24 5335088.22 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_804afd61-9d69-4415-a076-e34e3372fa5f">
<gen:stringAttribute name="Flaeche">
<gen:value>31.745</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.723</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.427</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_804afd61-9d69-4415-a076-e34e3372fa5f_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692589.05 5335091.98 509.704 692589.14 5335093.59 509.704 692589.14 5335093.59 529.427 692589.134 5335093.49 529.39 692589.05 5335091.98 529.39 692589.05 5335091.98 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_8fdb92b2-eef4-4867-a92e-ca82a001861d">
<gen:stringAttribute name="Flaeche">
<gen:value>38.382</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.258</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.962</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_8fdb92b2-eef4-4867-a92e-ca82a001861d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692604.47 5335098.91 509.704 692604.47 5335098.91 523.962 692606.86 5335097.67 523.957 692606.86 5335097.67 509.704 692604.47 5335098.91 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_93ca9f87-a50e-43c8-bb5c-37078b15f7fe">
<gen:stringAttribute name="Flaeche">
<gen:value>3.733</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.319</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.023</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_93ca9f87-a50e-43c8-bb5c-37078b15f7fe_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692601.46 5335088.08 509.704 692601.46 5335088.08 524.013 692601.24 5335088.22 524.023 692601.24 5335088.22 509.704 692601.46 5335088.08 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_98257a32-6f0a-4ac1-a8db-bf2c88b6c101">
<gen:stringAttribute name="Flaeche">
<gen:value>3.909</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.318</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.022</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_98257a32-6f0a-4ac1-a8db-bf2c88b6c101_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692601.71 5335087.97 509.704 692601.71 5335087.97 524.022 692601.46 5335088.08 524.013 692601.46 5335088.08 509.704 692601.71 5335087.97 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_98304609-7541-4b62-8491-6f8e867a77b5">
<gen:stringAttribute name="Flaeche">
<gen:value>101.400</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.782</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.486</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_98304609-7541-4b62-8491-6f8e867a77b5_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692586.21 5335092.12 509.704 692586.21 5335092.12 529.485 692585.96 5335087 529.486 692585.96 5335087 509.704 692586.21 5335092.12 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_a19a672b-d6f7-4ec6-94d4-d17bee429100">
<gen:stringAttribute name="Flaeche">
<gen:value>57.804</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.709</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.413</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_a19a672b-d6f7-4ec6-94d4-d17bee429100_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692602.62 5335089.57 509.704 692604.49 5335092.68 509.704 692604.49 5335092.68 526.393 692604.467 5335092.642 526.413 692602.62 5335089.57 524.834 692602.62 5335089.57 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_a733125b-80a6-42fe-97fb-73242d1c48a7">
<gen:stringAttribute name="Flaeche">
<gen:value>7.781</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.256</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_a733125b-80a6-42fe-97fb-73242d1c48a7_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692606.86 5335097.67 509.704 692606.86 5335097.67 523.957 692607.34 5335097.41 523.96 692607.34 5335097.41 509.704 692606.86 5335097.67 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_a8c62dd0-d4d6-47dc-9344-779ce7a45113">
<gen:stringAttribute name="Flaeche">
<gen:value>189.971</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.729</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.433</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_a8c62dd0-d4d6-47dc-9344-779ce7a45113_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692604.47 5335098.91 509.704 692592.7 5335105.08 509.704 692592.7 5335105.08 529.433 692592.783 5335105.036 529.39 692592.783 5335105.036 523.96 692604.47 5335098.91 523.962 692604.47 5335098.91 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_c062d8cc-4a89-4fde-8222-67fd4adb7194">
<gen:stringAttribute name="Flaeche">
<gen:value>75.678</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.119</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.823</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_c062d8cc-4a89-4fde-8222-67fd4adb7194_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692585.96 5335087 509.704 692585.96 5335087 529.486 692582.31 5335087.61 530.823 692582.31 5335087.61 509.704 692585.96 5335087 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_f6564848-1698-47da-a2a3-9225cfe05f5f">
<gen:stringAttribute name="Flaeche">
<gen:value>147.455</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.620</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_f6564848-1698-47da-a2a3-9225cfe05f5f_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692574.05 5335088.03 509.704 692581.09 5335087.83 509.704 692581.09 5335087.83 531.27 692580.128 5335087.857 531.62 692574.05 5335088.03 529.408 692574.05 5335088.03 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_f72af8e3-8e41-40c2-a7c3-f49f17bc4d87">
<gen:stringAttribute name="Flaeche">
<gen:value>55.988</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.781</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.485</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_f72af8e3-8e41-40c2-a7c3-f49f17bc4d87_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692586.21 5335092.12 509.704 692589.05 5335091.98 509.704 692589.05 5335091.98 529.39 692586.47 5335092.107 529.39 692586.21 5335092.12 529.485 692586.21 5335092.12 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006485_ff778644-5f22-43b1-9294-0e8635d561cc">
<gen:stringAttribute name="Flaeche">
<gen:value>219.181</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.710</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.414</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>509.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_ff778644-5f22-43b1-9294-0e8635d561cc_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692574.47 5335096.44 509.704 692574.47 5335096.44 529.414 692574.99 5335107.55 529.408 692574.99 5335107.55 509.704 692574.47 5335096.44 509.704</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006485_200cca42-ee8c-40f8-9e1b-ad214b0cc3b3">
<gen:stringAttribute name="Dachneigung">
<gen:value>69.815</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>187.936</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>35.712</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.620</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.686</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.390</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_200cca42-ee8c-40f8-9e1b-ad214b0cc3b3_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692580.751 5335100.783 531.62 692586.554 5335093.85 529.39 692589.134 5335093.49 529.39 692589.14 5335093.59 529.427 692590.882 5335093.403 529.447 692587.352 5335099.863 531.62 692580.751 5335100.783 531.62</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006485_2a41eab9-4602-4ca6-ab74-5e11f20e7e0a">
<gen:stringAttribute name="Dachneigung">
<gen:value>70.009</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>272.759</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>105.184</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.620</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.704</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.408</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_2a41eab9-4602-4ca6-ab74-5e11f20e7e0a_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692580.128 5335087.857 531.62 692580.751 5335100.783 531.62 692575.1 5335107.535 529.448 692574.99 5335107.55 529.408 692574.47 5335096.44 529.414 692574.09 5335088.45 529.415 692574.05 5335088.03 529.408 692580.128 5335087.857 531.62</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006485_3bda6476-fd75-4183-aecb-de7fd59dca0f">
<gen:stringAttribute name="Dachneigung">
<gen:value>66.185</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>27.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>93.005</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.709</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.413</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.253</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.957</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_3bda6476-fd75-4183-aecb-de7fd59dca0f_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692604.467 5335092.642 526.413 692604.49 5335092.68 526.393 692607.34 5335097.41 523.96 692606.86 5335097.67 523.957 692604.47 5335098.91 523.962 692592.783 5335105.036 523.96 692591.893 5335099.229 526.413 692604.467 5335092.642 526.413</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006485_4a228900-89cd-4008-aec8-5729b3d9dca9">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>4.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.686</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.390</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.686</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.390</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_4a228900-89cd-4008-aec8-5729b3d9dca9_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692589.05 5335091.98 529.39 692589.134 5335093.49 529.39 692586.554 5335093.85 529.39 692586.47 5335092.107 529.39 692589.05 5335091.98 529.39</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006485_aec09f5e-eb83-4991-89f0-cd0b59a3f2a2">
<gen:stringAttribute name="Dachneigung">
<gen:value>64.065</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>98.708</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>30.904</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.620</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.686</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.390</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_aec09f5e-eb83-4991-89f0-cd0b59a3f2a2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692592.783 5335105.036 529.39 692592.7 5335105.08 529.433 692592.669 5335105.084 529.448 692587.352 5335099.863 531.62 692590.882 5335093.403 529.447 692590.91 5335093.4 529.433 692590.994 5335093.358 529.39 692592.783 5335105.036 529.39</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006485_b2f39202-aa74-4ca5-8827-94e432a22c8e">
<gen:stringAttribute name="Dachneigung">
<gen:value>69.809</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>7.940</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>76.784</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.620</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.744</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.448</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_b2f39202-aa74-4ca5-8827-94e432a22c8e_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692580.751 5335100.783 531.62 692587.352 5335099.863 531.62 692592.669 5335105.084 529.448 692575.1 5335107.535 529.448 692580.751 5335100.783 531.62</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006485_bcc6e1a5-7582-4773-a87f-a42e87c579a4">
<gen:stringAttribute name="Dachneigung">
<gen:value>66.180</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>207.653</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>78.817</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.709</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.413</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.229</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.933</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_bcc6e1a5-7582-4773-a87f-a42e87c579a4_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692598.42 5335089.65 524.004 692601.24 5335088.22 524.023 692601.46 5335088.08 524.013 692601.71 5335087.97 524.022 692602.62 5335089.57 524.834 692604.467 5335092.642 526.413 692591.893 5335099.229 526.413 692590.994 5335093.358 523.933 692598.42 5335089.65 524.004</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006485_d110fe0c-b281-48d1-9c7a-bedaefae3ac3">
<gen:stringAttribute name="Dachneigung">
<gen:value>70.010</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>92.757</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>62.944</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.620</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.686</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.390</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006485_d110fe0c-b281-48d1-9c7a-bedaefae3ac3_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692580.128 5335087.857 531.62 692581.09 5335087.83 531.27 692582.31 5335087.61 530.823 692585.96 5335087 529.486 692586.21 5335092.12 529.485 692586.47 5335092.107 529.39 692586.554 5335093.85 529.39 692580.751 5335100.783 531.62 692580.128 5335087.857 531.62</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>Triftstraße 2</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006489">
<creationDate>2015-09-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfn6y</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>532.250</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>528.101</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_1000</bldg:function>
<bldg:roofType>1000</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">21.42</bldg:measuredHeight>
<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_f8ca1fa1-2456-4623-b152-524a8d522de9_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_05b0c62e-d46d-4708-a7ac-afe5574a8752_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_08290b6a-8886-44c2-9bff-91f974ab5f6e_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_1d9322c7-39c6-4182-9154-29f48ab186b8_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_2b4c926e-3b13-4967-a037-52df2e7a41e3_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_2edd87da-950a-4874-8ce3-0ad750dec404_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_33c4ae12-33b3-4d6f-bfd1-334c5e37ff48_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_45589e26-389a-415e-b90b-be66feb1bbe1_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_57f092ee-5a2d-414d-8b89-701cfbcaa679_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_5a56c4d2-b6d5-425e-af0e-aabf41f6b265_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_5d001ba2-482f-4f5d-a702-8ed5ede5abef_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_661434f9-3964-4c2d-99b4-49fce2a7dde2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_6dfc3a11-3708-47cb-99ed-57286becd08e_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_701ebaa5-5682-4171-abf8-36be4bbfc8b2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_8f5b1f66-dc26-459a-b6b9-a1103bb5fd69_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_97aa356c-2685-466d-bebb-dc294a52c35a_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_b8ab419e-1ca6-4471-8934-c4c023a79050_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_c7424967-0fba-46d3-9a42-505ceb21230d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_ef44e88c-b139-46b9-9c44-f9c6f3a3ba7f_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_f6fe7a9b-5651-4fe1-815f-a5ce926547b4_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_0747dcd6-793b-4474-a243-546bfc28acf7_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_0939b792-2883-4810-abf9-8a7ed33f5e7d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_3bca946f-d627-4700-b0ee-52ac4d28d505_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_3bfb600b-cda6-4329-8cde-2cd8f0dfb514_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_6b2ada18-0b81-4048-b5ce-7b4f19a00639_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_a27c4826-34f0-4e70-9aa6-b7a3362a150c_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_c5cbf6c2-9dc4-415d-a1c5-ab9fff80ffa7_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006489_ce2809db-9ac8-4b18-b254-a04db2bb7f5e_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006489_f8ca1fa1-2456-4623-b152-524a8d522de9">
<gen:stringAttribute name="Flaeche">
<gen:value>234.094</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_f8ca1fa1-2456-4623-b152-524a8d522de9_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692567.89 5335178.364 510.83 692567.861 5335178.184 510.83 692567.564 5335176.386 510.83 692565.923 5335166.441 510.83 692564.32 5335166.704 510.83 692563.264 5335166.878 510.83 692558.65 5335167.62 510.83 692557.946 5335167.733 510.83 692551.153 5335168.828 510.83 692548.781 5335169.209 510.83 692548.055 5335169.33 510.83 692546.635 5335169.567 510.83 692548.545 5335179.468 510.83 692548.774 5335180.659 510.83 692549.891 5335180.46 510.83 692551.082 5335180.248 510.83 692551.228 5335180.874 510.83 692555.921 5335180.125 510.83 692555.928 5335180.302 510.83 692555.936 5335180.506 510.83 692566.326 5335178.863 510.83 692567.93 5335178.609 510.83 692567.89 5335178.364 510.83</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_05b0c62e-d46d-4708-a7ac-afe5574a8752">
<gen:stringAttribute name="Flaeche">
<gen:value>199.102</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.760</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_05b0c62e-d46d-4708-a7ac-afe5574a8752_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692546.635 5335169.567 528.368 692548.545 5335179.468 528.59 692548.545 5335179.468 528.26 692548.774 5335180.659 528.26 692548.774 5335180.659 510.83 692548.545 5335179.468 510.83 692546.635 5335169.567 510.83 692546.635 5335169.567 528.368</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_08290b6a-8886-44c2-9bff-91f974ab5f6e">
<gen:stringAttribute name="Flaeche">
<gen:value>83.376</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.549</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.379</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_08290b6a-8886-44c2-9bff-91f974ab5f6e_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692551.228 5335180.874 510.83 692551.228 5335180.874 528.379 692555.921 5335180.125 528.372 692555.921 5335180.125 510.83 692551.228 5335180.874 510.83</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_1d9322c7-39c6-4182-9154-29f48ab186b8">
<gen:stringAttribute name="Flaeche">
<gen:value>12.191</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.450</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.280</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.710</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.540</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_1d9322c7-39c6-4182-9154-29f48ab186b8_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692552.794 5335178.779 530.28 692560.291 5335177.564 530.28 692565.96 5335176.645 530.28 692565.96 5335176.645 529.54 692560.291 5335177.564 529.54 692552.794 5335178.779 529.54 692549.696 5335179.282 529.54 692549.696 5335179.282 530.28 692552.794 5335178.779 530.28</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_2b4c926e-3b13-4967-a037-52df2e7a41e3">
<gen:stringAttribute name="Flaeche">
<gen:value>50.345</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.601</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.431</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_2b4c926e-3b13-4967-a037-52df2e7a41e3_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692564.32 5335166.704 510.83 692565.923 5335166.441 510.83 692565.923 5335166.441 528.376 692564.32 5335166.704 529.54 692564.32 5335166.704 530.28 692563.264 5335166.878 530.431 692563.264 5335166.878 510.83 692564.32 5335166.704 510.83</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_2edd87da-950a-4874-8ce3-0ad750dec404">
<gen:stringAttribute name="Flaeche">
<gen:value>7.463</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.450</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.280</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.710</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.540</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_2edd87da-950a-4874-8ce3-0ad750dec404_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692548.055 5335169.33 530.28 692548.721 5335173.365 530.28 692549.696 5335179.282 530.28 692549.696 5335179.282 529.54 692548.721 5335173.365 529.54 692548.055 5335169.33 529.54 692548.055 5335169.33 530.28</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_33c4ae12-33b3-4d6f-bfd1-334c5e37ff48">
<gen:stringAttribute name="Flaeche">
<gen:value>8.808</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.420</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.250</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>20.260</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>531.090</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_33c4ae12-33b3-4d6f-bfd1-334c5e37ff48_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692551.818 5335172.863 531.09 692551.818 5335172.863 532.25 692559.315 5335171.648 532.25 692559.315 5335171.648 531.09 692551.818 5335172.863 531.09</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_45589e26-389a-415e-b90b-be66feb1bbe1">
<gen:stringAttribute name="Flaeche">
<gen:value>41.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.959</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.789</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_45589e26-389a-415e-b90b-be66feb1bbe1_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692549.891 5335180.46 528.26 692549.891 5335180.46 528.777 692551.082 5335180.248 528.789 692551.082 5335180.248 510.83 692549.891 5335180.46 510.83 692548.774 5335180.659 510.83 692548.774 5335180.659 528.26 692549.891 5335180.46 528.26</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_57f092ee-5a2d-414d-8b89-701cfbcaa679">
<gen:stringAttribute name="Flaeche">
<gen:value>4.744</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.420</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.250</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>20.260</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>531.090</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_57f092ee-5a2d-414d-8b89-701cfbcaa679_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692551.153 5335168.828 531.09 692551.153 5335168.828 532.25 692551.818 5335172.863 532.25 692551.818 5335172.863 531.09 692551.153 5335168.828 531.09</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_5a56c4d2-b6d5-425e-af0e-aabf41f6b265">
<gen:stringAttribute name="Flaeche">
<gen:value>11.414</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.959</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.789</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_5a56c4d2-b6d5-425e-af0e-aabf41f6b265_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692551.082 5335180.248 510.83 692551.082 5335180.248 528.789 692551.228 5335180.874 528.379 692551.228 5335180.874 510.83 692551.082 5335180.248 510.83</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_5d001ba2-482f-4f5d-a702-8ed5ede5abef">
<gen:stringAttribute name="Flaeche">
<gen:value>7.455</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.450</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.280</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.710</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.540</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_5d001ba2-482f-4f5d-a702-8ed5ede5abef_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692564.32 5335166.704 529.54 692564.985 5335170.729 529.54 692565.96 5335176.645 529.54 692565.96 5335176.645 530.28 692564.985 5335170.729 530.28 692564.32 5335166.704 530.28 692564.32 5335166.704 529.54</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_661434f9-3964-4c2d-99b4-49fce2a7dde2">
<gen:stringAttribute name="Flaeche">
<gen:value>0.939</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.710</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.540</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.430</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>528.260</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_661434f9-3964-4c2d-99b4-49fce2a7dde2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692548.545 5335179.468 528.26 692548.545 5335179.468 528.59 692549.696 5335179.282 529.54 692549.696 5335179.282 528.26 692548.545 5335179.468 528.26</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_6dfc3a11-3708-47cb-99ed-57286becd08e">
<gen:stringAttribute name="Flaeche">
<gen:value>195.294</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.420</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.250</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_6dfc3a11-3708-47cb-99ed-57286becd08e_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692551.153 5335168.828 510.83 692557.946 5335167.733 510.83 692557.946 5335167.733 532.25 692551.153 5335168.828 532.25 692551.153 5335168.828 531.09 692548.781 5335169.209 530.47 692548.781 5335169.209 510.83 692551.153 5335168.828 510.83</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_701ebaa5-5682-4171-abf8-36be4bbfc8b2">
<gen:stringAttribute name="Flaeche">
<gen:value>108.394</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.420</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.250</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_701ebaa5-5682-4171-abf8-36be4bbfc8b2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692558.65 5335167.62 510.83 692563.264 5335166.878 510.83 692563.264 5335166.878 530.431 692558.65 5335167.62 531.09 692558.65 5335167.62 532.25 692557.946 5335167.733 532.25 692557.946 5335167.733 510.83 692558.65 5335167.62 510.83</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_8f5b1f66-dc26-459a-b6b9-a1103bb5fd69">
<gen:stringAttribute name="Flaeche">
<gen:value>216.316</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.546</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.376</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_8f5b1f66-dc26-459a-b6b9-a1103bb5fd69_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692565.923 5335166.441 510.83 692567.564 5335176.386 510.83 692567.861 5335178.184 510.83 692567.89 5335178.364 510.83 692567.93 5335178.609 510.83 692567.93 5335178.609 528.101 692567.89 5335178.364 528.26 692567.861 5335178.184 528.376 692567.564 5335176.386 528.376 692565.923 5335166.441 528.376 692565.923 5335166.441 510.83</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_97aa356c-2685-466d-bebb-dc294a52c35a">
<gen:stringAttribute name="Flaeche">
<gen:value>40.465</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.640</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.470</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_97aa356c-2685-466d-bebb-dc294a52c35a_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692548.055 5335169.33 510.83 692548.781 5335169.209 510.83 692548.781 5335169.209 530.47 692548.055 5335169.33 530.28 692548.055 5335169.33 529.54 692546.635 5335169.567 528.368 692546.635 5335169.567 510.83 692548.055 5335169.33 510.83</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_b8ab419e-1ca6-4471-8934-c4c023a79050">
<gen:stringAttribute name="Flaeche">
<gen:value>209.877</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.301</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.131</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_b8ab419e-1ca6-4471-8934-c4c023a79050_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692566.326 5335178.863 528.105 692567.93 5335178.609 528.101 692567.93 5335178.609 510.83 692566.326 5335178.863 510.83 692555.936 5335180.506 510.83 692555.936 5335180.506 528.131 692566.326 5335178.863 528.105</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_c7424967-0fba-46d3-9a42-505ceb21230d">
<gen:stringAttribute name="Flaeche">
<gen:value>1.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.710</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.540</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.430</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>528.260</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_c7424967-0fba-46d3-9a42-505ceb21230d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692549.696 5335179.282 528.26 692549.696 5335179.282 529.54 692549.891 5335180.46 528.777 692549.891 5335180.46 528.26 692549.696 5335179.282 528.26</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_ef44e88c-b139-46b9-9c44-f9c6f3a3ba7f">
<gen:stringAttribute name="Flaeche">
<gen:value>6.641</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.542</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.372</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.830</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_ef44e88c-b139-46b9-9c44-f9c6f3a3ba7f_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692555.921 5335180.125 528.372 692555.928 5335180.302 528.26 692555.936 5335180.506 528.131 692555.936 5335180.506 510.83 692555.928 5335180.302 510.83 692555.921 5335180.125 510.83 692555.921 5335180.125 528.372</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006489_f6fe7a9b-5651-4fe1-815f-a5ce926547b4">
<gen:stringAttribute name="Flaeche">
<gen:value>4.735</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.420</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.250</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>20.260</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>531.090</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_f6fe7a9b-5651-4fe1-815f-a5ce926547b4_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692559.315 5335171.648 531.09 692559.315 5335171.648 532.25 692558.65 5335167.62 532.25 692558.65 5335167.62 531.09 692559.315 5335171.648 531.09</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006489_0747dcd6-793b-4474-a243-546bfc28acf7">
<gen:stringAttribute name="Dachneigung">
<gen:value>54.361</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>101.602</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>21.953</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.710</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.540</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.546</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>528.376</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_0747dcd6-793b-4474-a243-546bfc28acf7_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692565.923 5335166.441 528.376 692567.564 5335176.386 528.376 692567.861 5335178.184 528.376 692565.96 5335176.645 529.54 692564.985 5335170.729 529.54 692564.32 5335166.704 529.54 692565.923 5335166.441 528.376</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006489_0939b792-2883-4810-abf9-8a7ed33f5e7d">
<gen:stringAttribute name="Dachneigung">
<gen:value>81.973</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>101.603</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>41.048</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>20.260</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.090</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.450</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>530.280</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_0939b792-2883-4810-abf9-8a7ed33f5e7d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692563.264 5335166.878 530.431 692564.32 5335166.704 530.28 692564.985 5335170.729 530.28 692565.96 5335176.645 530.28 692559.315 5335171.648 531.09 692558.65 5335167.62 531.09 692563.264 5335166.878 530.431</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006489_3bca946f-d627-4700-b0ee-52ac4d28d505">
<gen:stringAttribute name="Dachneigung">
<gen:value>57.439</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>11.425</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>42.317</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.710</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.540</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.271</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>528.101</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_3bca946f-d627-4700-b0ee-52ac4d28d505_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692552.794 5335178.779 529.54 692560.291 5335177.564 529.54 692565.96 5335176.645 529.54 692567.861 5335178.184 528.376 692567.89 5335178.364 528.26 692567.93 5335178.609 528.101 692566.326 5335178.863 528.105 692555.936 5335180.506 528.131 692555.928 5335180.302 528.26 692555.921 5335180.125 528.372 692551.228 5335180.874 528.379 692551.082 5335180.248 528.789 692549.891 5335180.46 528.777 692549.696 5335179.282 529.54 692552.794 5335178.779 529.54</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006489_3bfb600b-cda6-4329-8cde-2cd8f0dfb514">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>31.025</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.420</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.250</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.420</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.250</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_3bfb600b-cda6-4329-8cde-2cd8f0dfb514_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692557.946 5335167.733 532.25 692558.65 5335167.62 532.25 692559.315 5335171.648 532.25 692551.818 5335172.863 532.25 692551.153 5335168.828 532.25 692557.946 5335167.733 532.25</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006489_6b2ada18-0b81-4048-b5ce-7b4f19a00639">
<gen:stringAttribute name="Dachneigung">
<gen:value>75.525</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>281.602</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>22.972</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>20.260</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.090</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.450</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>530.280</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_6b2ada18-0b81-4048-b5ce-7b4f19a00639_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692548.781 5335169.209 530.47 692551.153 5335168.828 531.09 692551.818 5335172.863 531.09 692549.696 5335179.282 530.28 692548.721 5335173.365 530.28 692548.055 5335169.33 530.28 692548.781 5335169.209 530.47</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006489_a27c4826-34f0-4e70-9aa6-b7a3362a150c">
<gen:stringAttribute name="Dachneigung">
<gen:value>82.306</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>11.425</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>72.809</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>20.260</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.090</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.450</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>530.280</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_a27c4826-34f0-4e70-9aa6-b7a3362a150c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692551.818 5335172.863 531.09 692559.315 5335171.648 531.09 692565.96 5335176.645 530.28 692560.291 5335177.564 530.28 692552.794 5335178.779 530.28 692549.696 5335179.282 530.28 692551.818 5335172.863 531.09</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006489_c5cbf6c2-9dc4-415d-a1c5-ab9fff80ffa7">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.385</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.430</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.260</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.430</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>528.260</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_c5cbf6c2-9dc4-415d-a1c5-ab9fff80ffa7_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692549.696 5335179.282 528.26 692549.891 5335180.46 528.26 692548.774 5335180.659 528.26 692548.545 5335179.468 528.26 692549.696 5335179.282 528.26</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006489_ce2809db-9ac8-4b18-b254-a04db2bb7f5e">
<gen:stringAttribute name="Dachneigung">
<gen:value>50.840</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>281.601</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>16.939</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.710</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.540</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.538</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>528.368</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006489_ce2809db-9ac8-4b18-b254-a04db2bb7f5e_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692548.055 5335169.33 529.54 692548.721 5335173.365 529.54 692549.696 5335179.282 529.54 692548.545 5335179.468 528.59 692546.635 5335169.567 528.368 692548.055 5335169.33 529.54</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>Triftstraße 11</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006490">
<creationDate>2015-09-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfn3v</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>529.680</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>523.903</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_9998</bldg:function>
<bldg:roofType>3100</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">18.68</bldg:measuredHeight>
<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_9544f45f-b7c1-4e0b-ae85-f3ad0301ac9e_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_0970792c-bc2a-4d0e-8aa3-9d1fb348101a_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_09e12994-9036-46c5-8b55-b7afce1beccb_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_12c35e8c-1d35-47b6-8741-7569f84efbf4_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_2a6d0aba-92ea-46dc-ad5f-9e43729d6e27_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_376f33a3-5aab-4b81-80e9-4ead64ab3e91_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_413f89bb-e797-4c17-afbb-1bb08ed634ff_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_4156ddb3-8141-4b10-9241-936a71ef627e_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_6ff21431-a930-4ed4-8f13-0d1c12c45314_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_7391d811-2deb-4038-b3ba-dda6caed6566_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_763393ba-99de-4a5e-bca6-6b58179ccb49_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_860b3a4a-8e12-4f59-bd2c-92ef869b270e_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_8f939c20-f083-45fc-a7b7-ab7957b2df86_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_9c0ab9bd-b5e3-43bc-aded-c8bdc5cc24d5_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_9cb503ea-045b-47a9-a737-e37bf605c1f4_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_a6a12857-0288-4758-aeb1-8af274b4c39c_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_accc9583-c17b-4edd-921a-19420431bbee_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_eefb92bd-25ad-4852-82e8-9fa601852443_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_32df7e3c-bee2-4af3-9e8c-a064ed63eb10_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006490_d1c64467-2138-497f-9baa-af27047efb8c_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006490_9544f45f-b7c1-4e0b-ae85-f3ad0301ac9e">
<gen:stringAttribute name="Flaeche">
<gen:value>294.432</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_9544f45f-b7c1-4e0b-ae85-f3ad0301ac9e_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.921 5335166.847 511 692529.812 5335166.84 511 692528.834 5335166.771 511 692528.206 5335166.727 511 692525.272 5335166.513 511 692524.494 5335166.462 511 692521.996 5335179.053 511 692521.87 5335179.708 511 692521.26 5335182.766 511 692520.662 5335185.775 511 692520.717 5335185.788 511 692521.187 5335185.906 511 692520.15 5335191.25 511 692520.026 5335191.866 511 692520.453 5335191.952 511 692523.247 5335192.431 511 692524.907 5335192.716 511 692525.264 5335192.778 511 692525.503 5335192.819 511 692530.841 5335193.748 511 692532.4 5335185.043 511 692532.989 5335181.743 511 692535.478 5335167.92 511 692535.599 5335167.245 511 692529.921 5335166.847 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_0970792c-bc2a-4d0e-8aa3-9d1fb348101a">
<gen:stringAttribute name="Flaeche">
<gen:value>120.860</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.680</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.680</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_0970792c-bc2a-4d0e-8aa3-9d1fb348101a_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692528.206 5335166.727 511 692528.834 5335166.771 511 692529.812 5335166.84 511 692529.921 5335166.847 511 692535.599 5335167.245 511 692535.599 5335167.245 524.007 692529.921 5335166.847 529.68 692529.812 5335166.84 529.571 692528.834 5335166.771 528.594 692528.206 5335166.727 527.966 692528.206 5335166.727 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_09e12994-9036-46c5-8b55-b7afce1beccb">
<gen:stringAttribute name="Flaeche">
<gen:value>39.670</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_09e12994-9036-46c5-8b55-b7afce1beccb_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692521.26 5335182.766 511 692521.26 5335182.766 523.96 692520.662 5335185.775 523.903 692520.662 5335185.775 511 692521.26 5335182.766 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_12c35e8c-1d35-47b6-8741-7569f84efbf4">
<gen:stringAttribute name="Flaeche">
<gen:value>191.652</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.012</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.012</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_12c35e8c-1d35-47b6-8741-7569f84efbf4_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692535.478 5335167.92 524.007 692535.599 5335167.245 524.007 692535.599 5335167.245 511 692535.478 5335167.92 511 692532.989 5335181.743 511 692532.989 5335181.743 524.012 692535.478 5335167.92 524.007</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_2a6d0aba-92ea-46dc-ad5f-9e43729d6e27">
<gen:stringAttribute name="Flaeche">
<gen:value>115.048</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.009</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.009</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_2a6d0aba-92ea-46dc-ad5f-9e43729d6e27_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692530.841 5335193.748 511 692530.841 5335193.748 524.007 692532.4 5335185.043 524.009 692532.4 5335185.043 511 692530.841 5335193.748 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_376f33a3-5aab-4b81-80e9-4ead64ab3e91">
<gen:stringAttribute name="Flaeche">
<gen:value>168.704</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.257</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.257</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_376f33a3-5aab-4b81-80e9-4ead64ab3e91_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692524.494 5335166.462 511 692524.494 5335166.462 524.257 692521.996 5335179.053 524.027 692521.996 5335179.053 511 692524.494 5335166.462 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_413f89bb-e797-4c17-afbb-1bb08ed634ff">
<gen:stringAttribute name="Flaeche">
<gen:value>43.606</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.012</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.012</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_413f89bb-e797-4c17-afbb-1bb08ed634ff_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692532.4 5335185.043 511 692532.4 5335185.043 524.009 692532.989 5335181.743 524.012 692532.989 5335181.743 511 692532.4 5335185.043 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_4156ddb3-8141-4b10-9241-936a71ef627e">
<gen:stringAttribute name="Flaeche">
<gen:value>40.511</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.020</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.020</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_4156ddb3-8141-4b10-9241-936a71ef627e_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692521.87 5335179.708 511 692521.87 5335179.708 524.02 692521.26 5335182.766 523.96 692521.26 5335182.766 511 692521.87 5335179.708 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_6ff21431-a930-4ed4-8f13-0d1c12c45314">
<gen:stringAttribute name="Flaeche">
<gen:value>10.647</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.034</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.034</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_6ff21431-a930-4ed4-8f13-0d1c12c45314_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692525.272 5335166.513 511 692525.272 5335166.513 525.034 692524.494 5335166.462 524.257 692524.494 5335166.462 511 692525.272 5335166.513 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_7391d811-2deb-4038-b3ba-dda6caed6566">
<gen:stringAttribute name="Flaeche">
<gen:value>11.212</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.680</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.680</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_7391d811-2deb-4038-b3ba-dda6caed6566_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692524.907 5335192.716 529.316 692525.264 5335192.778 529.68 692525.503 5335192.819 529.437 692525.503 5335192.819 511 692525.264 5335192.778 511 692524.907 5335192.716 511 692524.907 5335192.716 529.316</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_763393ba-99de-4a5e-bca6-6b58179ccb49">
<gen:stringAttribute name="Flaeche">
<gen:value>72.969</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.444</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.444</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_763393ba-99de-4a5e-bca6-6b58179ccb49_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692521.187 5335185.906 511 692521.187 5335185.906 524.444 692520.15 5335191.25 524.365 692520.15 5335191.25 511 692521.187 5335185.906 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_860b3a4a-8e12-4f59-bd2c-92ef869b270e">
<gen:stringAttribute name="Flaeche">
<gen:value>7.131</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.444</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.444</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_860b3a4a-8e12-4f59-bd2c-92ef869b270e_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692520.662 5335185.775 523.903 692520.717 5335185.788 523.959 692521.187 5335185.906 524.444 692521.187 5335185.906 511 692520.717 5335185.788 511 692520.662 5335185.775 511 692520.662 5335185.775 523.903</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_8f939c20-f083-45fc-a7b7-ab7957b2df86">
<gen:stringAttribute name="Flaeche">
<gen:value>8.694</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.027</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.027</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_8f939c20-f083-45fc-a7b7-ab7957b2df86_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692521.996 5335179.053 511 692521.996 5335179.053 524.027 692521.87 5335179.708 524.02 692521.87 5335179.708 511 692521.996 5335179.053 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_9c0ab9bd-b5e3-43bc-aded-c8bdc5cc24d5">
<gen:stringAttribute name="Flaeche">
<gen:value>8.389</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.365</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.365</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_9c0ab9bd-b5e3-43bc-aded-c8bdc5cc24d5_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692520.15 5335191.25 511 692520.15 5335191.25 524.365 692520.026 5335191.866 524.352 692520.026 5335191.866 511 692520.15 5335191.25 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_9cb503ea-045b-47a9-a737-e37bf605c1f4">
<gen:stringAttribute name="Flaeche">
<gen:value>85.181</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.437</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.437</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_9cb503ea-045b-47a9-a737-e37bf605c1f4_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692525.503 5335192.819 511 692525.503 5335192.819 529.437 692530.841 5335193.748 524.007 692530.841 5335193.748 511 692525.503 5335192.819 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_a6a12857-0288-4758-aeb1-8af274b4c39c">
<gen:stringAttribute name="Flaeche">
<gen:value>5.912</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.788</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.788</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_a6a12857-0288-4758-aeb1-8af274b4c39c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692520.026 5335191.866 511 692520.026 5335191.866 524.352 692520.453 5335191.952 524.788 692520.453 5335191.952 511 692520.026 5335191.866 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_accc9583-c17b-4edd-921a-19420431bbee">
<gen:stringAttribute name="Flaeche">
<gen:value>45.596</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.966</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.966</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_accc9583-c17b-4edd-921a-19420431bbee_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692528.206 5335166.727 511 692528.206 5335166.727 527.966 692525.272 5335166.513 525.034 692525.272 5335166.513 511 692528.206 5335166.727 511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006490_eefb92bd-25ad-4852-82e8-9fa601852443">
<gen:stringAttribute name="Flaeche">
<gen:value>72.535</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.316</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.316</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_eefb92bd-25ad-4852-82e8-9fa601852443_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692520.453 5335191.952 524.788 692523.247 5335192.431 527.628 692524.907 5335192.716 529.316 692524.907 5335192.716 511 692523.247 5335192.431 511 692520.453 5335191.952 511 692520.453 5335191.952 524.788</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006490_32df7e3c-bee2-4af3-9e8c-a064ed63eb10">
<gen:stringAttribute name="Dachneigung">
<gen:value>44.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>262.060</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>203.441</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.680</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.680</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>12.903</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.903</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_32df7e3c-bee2-4af3-9e8c-a064ed63eb10_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692520.15 5335191.25 524.365 692521.187 5335185.906 524.444 692520.717 5335185.788 523.959 692520.662 5335185.775 523.903 692521.26 5335182.766 523.96 692521.87 5335179.708 524.02 692521.996 5335179.053 524.027 692524.494 5335166.462 524.257 692525.272 5335166.513 525.034 692528.206 5335166.727 527.966 692528.834 5335166.771 528.594 692529.812 5335166.84 529.571 692529.921 5335166.847 529.68 692529.902 5335166.956 529.68 692525.264 5335192.778 529.68 692524.907 5335192.716 529.316 692523.247 5335192.431 527.628 692520.453 5335191.952 524.788 692520.026 5335191.866 524.352 692520.15 5335191.25 524.365</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006490_d1c64467-2138-497f-9baa-af27047efb8c">
<gen:stringAttribute name="Dachneigung">
<gen:value>44.939</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>82.059</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>213.397</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.680</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.680</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>13.007</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>524.007</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006490_d1c64467-2138-497f-9baa-af27047efb8c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.902 5335166.956 529.68 692529.921 5335166.847 529.68 692535.599 5335167.245 524.007 692535.478 5335167.92 524.007 692532.989 5335181.743 524.012 692532.4 5335185.043 524.009 692530.841 5335193.748 524.007 692525.503 5335192.819 529.437 692525.264 5335192.778 529.68 692529.902 5335166.956 529.68</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>St.-Anna-Platz 8</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006491">
<creationDate>2015-09-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfnxX</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>533.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>526.600</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_1000</bldg:function>
<bldg:roofType>3200</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">23.03</bldg:measuredHeight>
<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_aea0ce6d-8d71-4ff3-95b2-4aed59bb05e5_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_065ac60e-c7ec-4dee-9c6a-5a31e0645649_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_0865286f-b454-4ed2-b986-a2dd9ec430fc_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_22b8b3d9-29d6-4c4e-964a-982a6d80e997_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_25941641-feda-48c2-82c8-58b448b64222_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_368054db-be15-41ed-b02f-7df6904e340e_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_46023b14-58f5-46a8-8a1f-67aa3c89d096_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_5a76a924-6c9d-4f19-82cb-c071a5dfca72_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_5f90dfca-d296-42b8-a491-5351576173a8_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_792736d8-aa7e-4a9c-abb1-276bb1705fa2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_9ec14b3d-d970-44ef-9504-d2fe937fda3d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_a2f09de2-9e4b-484c-8b40-037b22910ac0_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_a866ad24-9f2f-4753-aa74-5f032128d2b2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_c08b79ac-e360-4a2f-8f61-aae121f90946_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_f34059be-725f-413f-a2af-c48b25edd3a8_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_f501c97d-c00b-43b8-91a1-e279c4aa38cc_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_fa7244da-f1fb-4df2-a124-c5e7f36d3d6d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_fcc08bee-0c53-4595-bcd5-3ec561910231_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_70272ae1-3846-48b5-a822-f5fbb95448f7_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_c13a6869-ebc3-4a68-a0b8-1230541ef8c5_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_c15c046b-4db6-42bc-a4da-9172aaf18f19_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006491_cc8e1863-359d-451a-b9c0-0e4be4bde597_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006491_aea0ce6d-8d71-4ff3-95b2-4aed59bb05e5">
<gen:stringAttribute name="Flaeche">
<gen:value>286.307</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_aea0ce6d-8d71-4ff3-95b2-4aed59bb05e5_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692565.446 5335163.53 510.94 692564.885 5335159.965 510.94 692564.249 5335156.007 510.94 692563.361 5335150.529 510.94 692559.412 5335151.196 510.94 692555.432 5335151.892 510.94 692550.999 5335152.641 510.94 692548.026 5335153.166 510.94 692548.049 5335153.312 510.94 692548.948 5335159.037 510.94 692548.807 5335159.263 510.94 692548.062 5335160.454 510.94 692545.021 5335160.947 510.94 692546.635 5335169.567 510.94 692548.781 5335169.209 510.94 692550.367 5335168.954 510.94 692557.946 5335167.733 510.94 692558.171 5335167.697 510.94 692563.264 5335166.878 510.94 692565.923 5335166.441 510.94 692565.446 5335163.53 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_065ac60e-c7ec-4dee-9c6a-5a31e0645649">
<gen:stringAttribute name="Flaeche">
<gen:value>47.817</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.840</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.780</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_065ac60e-c7ec-4dee-9c6a-5a31e0645649_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692563.264 5335166.878 510.94 692563.264 5335166.878 529.78 692565.923 5335166.441 527.591 692565.923 5335166.441 510.94 692563.264 5335166.878 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_0865286f-b454-4ed2-b986-a2dd9ec430fc">
<gen:stringAttribute name="Flaeche">
<gen:value>74.822</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.591</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_0865286f-b454-4ed2-b986-a2dd9ec430fc_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692555.432 5335151.892 510.94 692555.432 5335151.892 527.591 692550.999 5335152.641 527.58 692550.999 5335152.641 510.94 692555.432 5335151.892 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_22b8b3d9-29d6-4c4e-964a-982a6d80e997">
<gen:stringAttribute name="Flaeche">
<gen:value>92.401</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.651</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.591</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_22b8b3d9-29d6-4c4e-964a-982a6d80e997_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692564.249 5335156.007 510.94 692564.249 5335156.007 527.587 692563.361 5335150.529 527.591 692563.361 5335150.529 510.94 692564.249 5335156.007 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_25941641-feda-48c2-82c8-58b448b64222">
<gen:stringAttribute name="Flaeche">
<gen:value>113.196</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.030</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_25941641-feda-48c2-82c8-58b448b64222_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692558.171 5335167.697 533.97 692563.264 5335166.878 529.78 692563.264 5335166.878 510.94 692558.171 5335167.697 510.94 692557.946 5335167.733 510.94 692557.946 5335167.733 533.786 692558.171 5335167.697 533.97</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_368054db-be15-41ed-b02f-7df6904e340e">
<gen:stringAttribute name="Flaeche">
<gen:value>48.248</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.660</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.600</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_368054db-be15-41ed-b02f-7df6904e340e_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692548.062 5335160.454 510.94 692548.062 5335160.454 526.6 692545.021 5335160.947 526.6 692545.021 5335160.947 510.94 692548.062 5335160.454 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_46023b14-58f5-46a8-8a1f-67aa3c89d096">
<gen:stringAttribute name="Flaeche">
<gen:value>26.435</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.752</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.692</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_46023b14-58f5-46a8-8a1f-67aa3c89d096_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692548.807 5335159.263 510.94 692548.948 5335159.037 510.94 692548.948 5335159.037 527.692 692548.807 5335159.263 527.55 692548.807 5335159.263 526.6 692548.062 5335160.454 526.6 692548.062 5335160.454 510.94 692548.807 5335159.263 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_5a76a924-6c9d-4f19-82cb-c071a5dfca72">
<gen:stringAttribute name="Flaeche">
<gen:value>60.091</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.657</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.597</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_5a76a924-6c9d-4f19-82cb-c071a5dfca72_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692565.446 5335163.53 510.94 692565.446 5335163.53 527.597 692564.885 5335159.965 527.587 692564.885 5335159.965 510.94 692565.446 5335163.53 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_5f90dfca-d296-42b8-a491-5351576173a8">
<gen:stringAttribute name="Flaeche">
<gen:value>34.060</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.660</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.600</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_5f90dfca-d296-42b8-a491-5351576173a8_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692546.635 5335169.567 510.94 692546.635 5335169.567 526.6 692548.781 5335169.209 526.6 692548.781 5335169.209 510.94 692546.635 5335169.567 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_792736d8-aa7e-4a9c-abb1-276bb1705fa2">
<gen:stringAttribute name="Flaeche">
<gen:value>49.123</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.657</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.597</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_792736d8-aa7e-4a9c-abb1-276bb1705fa2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692565.923 5335166.441 510.94 692565.923 5335166.441 527.591 692565.446 5335163.53 527.597 692565.446 5335163.53 510.94 692565.923 5335166.441 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_9ec14b3d-d970-44ef-9504-d2fe937fda3d">
<gen:stringAttribute name="Flaeche">
<gen:value>66.731</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.647</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.587</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_9ec14b3d-d970-44ef-9504-d2fe937fda3d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692564.885 5335159.965 510.94 692564.885 5335159.965 527.587 692564.249 5335156.007 527.587 692564.249 5335156.007 510.94 692564.885 5335159.965 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_a2f09de2-9e4b-484c-8b40-037b22910ac0">
<gen:stringAttribute name="Flaeche">
<gen:value>137.331</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.660</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.600</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_a2f09de2-9e4b-484c-8b40-037b22910ac0_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692545.021 5335160.947 510.94 692545.021 5335160.947 526.6 692546.635 5335169.567 526.6 692546.635 5335169.567 510.94 692545.021 5335160.947 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_a866ad24-9f2f-4753-aa74-5f032128d2b2">
<gen:stringAttribute name="Flaeche">
<gen:value>66.664</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.651</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.591</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_a866ad24-9f2f-4753-aa74-5f032128d2b2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692563.361 5335150.529 510.94 692563.361 5335150.529 527.591 692559.412 5335151.196 527.581 692559.412 5335151.196 510.94 692563.361 5335150.529 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_c08b79ac-e360-4a2f-8f61-aae121f90946">
<gen:stringAttribute name="Flaeche">
<gen:value>9.325</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.610</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.550</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.660</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.600</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_c08b79ac-e360-4a2f-8f61-aae121f90946_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692548.807 5335159.263 526.6 692548.807 5335159.263 527.55 692550.367 5335168.954 527.55 692550.367 5335168.954 526.6 692548.807 5335159.263 526.6</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_f34059be-725f-413f-a2af-c48b25edd3a8">
<gen:stringAttribute name="Flaeche">
<gen:value>176.584</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>22.846</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.786</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_f34059be-725f-413f-a2af-c48b25edd3a8_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692550.367 5335168.954 526.6 692550.367 5335168.954 527.55 692557.946 5335167.733 533.786 692557.946 5335167.733 510.94 692550.367 5335168.954 510.94 692548.781 5335169.209 510.94 692548.781 5335169.209 526.6 692550.367 5335168.954 526.6</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_f501c97d-c00b-43b8-91a1-e279c4aa38cc">
<gen:stringAttribute name="Flaeche">
<gen:value>67.256</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.591</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_f501c97d-c00b-43b8-91a1-e279c4aa38cc_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692559.412 5335151.196 510.94 692559.412 5335151.196 527.581 692555.432 5335151.892 527.591 692555.432 5335151.892 510.94 692559.412 5335151.196 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_fa7244da-f1fb-4df2-a124-c5e7f36d3d6d">
<gen:stringAttribute name="Flaeche">
<gen:value>99.594</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.770</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.710</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_fa7244da-f1fb-4df2-a124-c5e7f36d3d6d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692548.026 5335153.166 527.591 692548.049 5335153.312 527.71 692548.948 5335159.037 527.692 692548.948 5335159.037 510.94 692548.049 5335153.312 510.94 692548.026 5335153.166 510.94 692548.026 5335153.166 527.591</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006491_fcc08bee-0c53-4595-bcd5-3ec561910231">
<gen:stringAttribute name="Flaeche">
<gen:value>50.245</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.651</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.591</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.940</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_fcc08bee-0c53-4595-bcd5-3ec561910231_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692550.999 5335152.641 510.94 692550.999 5335152.641 527.58 692548.026 5335153.166 527.591 692548.026 5335153.166 510.94 692550.999 5335152.641 510.94</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006491_70272ae1-3846-48b5-a822-f5fbb95448f7">
<gen:stringAttribute name="Dachneigung">
<gen:value>50.893</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>191.981</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>79.540</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.030</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.640</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.580</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_70272ae1-3846-48b5-a822-f5fbb95448f7_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692550.999 5335152.641 527.58 692555.432 5335151.892 527.591 692559.412 5335151.196 527.581 692563.361 5335150.529 527.591 692556.868 5335159.608 533.97 692548.049 5335153.312 527.71 692548.026 5335153.166 527.591 692550.999 5335152.641 527.58</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006491_c13a6869-ebc3-4a68-a0b8-1230541ef8c5">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>34.596</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.660</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.600</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.660</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.600</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_c13a6869-ebc3-4a68-a0b8-1230541ef8c5_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692548.062 5335160.454 526.6 692548.807 5335159.263 526.6 692550.367 5335168.954 526.6 692548.781 5335169.209 526.6 692546.635 5335169.567 526.6 692545.021 5335160.947 526.6 692548.062 5335160.454 526.6</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006491_c15c046b-4db6-42bc-a4da-9172aaf18f19">
<gen:stringAttribute name="Dachneigung">
<gen:value>50.911</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>101.380</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>123.023</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.030</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.646</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.587</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_c15c046b-4db6-42bc-a4da-9172aaf18f19_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692563.361 5335150.529 527.591 692564.249 5335156.007 527.587 692564.885 5335159.965 527.587 692565.446 5335163.53 527.597 692565.923 5335166.441 527.591 692563.264 5335166.878 529.78 692558.171 5335167.697 533.97 692556.868 5335159.608 533.97 692563.361 5335150.529 527.591</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006491_cc8e1863-359d-451a-b9c0-0e4be4bde597">
<gen:stringAttribute name="Dachneigung">
<gen:value>50.912</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>281.380</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>121.755</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.030</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.610</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.550</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006491_cc8e1863-359d-451a-b9c0-0e4be4bde597_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692556.868 5335159.608 533.97 692558.171 5335167.697 533.97 692557.946 5335167.733 533.786 692550.367 5335168.954 527.55 692548.807 5335159.263 527.55 692548.948 5335159.037 527.692 692548.049 5335153.312 527.71 692556.868 5335159.608 533.97</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>Triftstraße 9</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006492">
<creationDate>2015-09-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfnt2</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>529.707</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>523.904</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_1000</bldg:function>
<bldg:roofType>3100</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">18.747</bldg:measuredHeight>
<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_5a45ca86-cce1-4208-bc46-83b40fdd1477_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_0c0220bf-6069-4115-9156-2ff0295f86ba_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_3b09060f-e537-49bd-8efd-f759fd9ca135_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_482e5e9b-d060-4df6-9898-7add90e2fe39_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_60a8b9bd-9e33-48e5-ad6a-77eaaf04eb3c_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_7cddef9a-e30b-45e2-bdde-60cad7a544df_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_9c0e2b89-3bac-46b4-b61d-a4483c549b78_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_abb72588-9bb9-430d-9352-1ed149efeb3d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_cff73013-30ab-4fa7-9ad5-fa81cc0aa530_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_dd2c9321-da05-4ad2-8762-45b39b8dc0e5_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_e3c2f584-7cf2-4503-92cc-11308f909fe3_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_7fd21dc6-0149-4813-b54a-33cfa323cc3d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006492_87fbd2a7-1f38-46a3-adaf-463fe7422eea_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006492_5a45ca86-cce1-4208-bc46-83b40fdd1477">
<gen:stringAttribute name="Flaeche">
<gen:value>193.189</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_5a45ca86-cce1-4208-bc46-83b40fdd1477_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692533.756 5335148.115 510.96 692533.468 5335148.068 510.96 692531.168 5335147.686 510.96 692529.86 5335147.468 510.96 692528.428 5335147.242 510.96 692528.378 5335147.49 510.96 692524.494 5335166.462 510.96 692525.272 5335166.513 510.96 692528.206 5335166.727 510.96 692529.812 5335166.84 510.96 692529.922 5335166.847 510.96 692535.401 5335167.231 510.96 692535.599 5335167.245 510.96 692536.162 5335164.115 510.96 692536.044 5335164.088 510.96 692535.31 5335163.922 510.96 692538.001 5335148.814 510.96 692533.756 5335148.115 510.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006492_0c0220bf-6069-4115-9156-2ff0295f86ba">
<gen:stringAttribute name="Flaeche">
<gen:value>20.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.688</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.648</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_0c0220bf-6069-4115-9156-2ff0295f86ba_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.86 5335147.468 510.96 692529.86 5335147.468 525.648 692528.428 5335147.242 524.158 692528.428 5335147.242 510.96 692529.86 5335147.468 510.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006492_3b09060f-e537-49bd-8efd-f759fd9ca135">
<gen:stringAttribute name="Flaeche">
<gen:value>76.588</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.747</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.707</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_3b09060f-e537-49bd-8efd-f759fd9ca135_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692533.468 5335148.068 510.96 692533.756 5335148.115 510.96 692538.001 5335148.814 510.96 692538.001 5335148.814 525.284 692533.756 5335148.115 529.707 692533.468 5335148.068 529.408 692533.468 5335148.068 510.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006492_482e5e9b-d060-4df6-9898-7add90e2fe39">
<gen:stringAttribute name="Flaeche">
<gen:value>258.943</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.198</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.158</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_482e5e9b-d060-4df6-9898-7add90e2fe39_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692528.378 5335147.49 510.96 692528.428 5335147.242 510.96 692528.428 5335147.242 524.158 692528.378 5335147.49 524.158 692524.494 5335166.462 524.158 692524.494 5335166.462 510.96 692528.378 5335147.49 510.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006492_60a8b9bd-9e33-48e5-ad6a-77eaaf04eb3c">
<gen:stringAttribute name="Flaeche">
<gen:value>11.785</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.922</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.882</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_60a8b9bd-9e33-48e5-ad6a-77eaaf04eb3c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692535.31 5335163.922 510.96 692536.044 5335164.088 510.96 692536.162 5335164.115 510.96 692536.162 5335164.115 523.982 692536.044 5335164.088 524.107 692535.31 5335163.922 524.882 692535.31 5335163.922 510.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006492_7cddef9a-e30b-45e2-bdde-60cad7a544df">
<gen:stringAttribute name="Flaeche">
<gen:value>120.953</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.747</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.707</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_7cddef9a-e30b-45e2-bdde-60cad7a544df_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692528.206 5335166.727 527.953 692529.812 5335166.84 529.595 692529.922 5335166.847 529.707 692535.401 5335167.231 524.107 692535.599 5335167.245 523.904 692535.599 5335167.245 510.96 692535.401 5335167.231 510.96 692529.922 5335166.847 510.96 692529.812 5335166.84 510.96 692528.206 5335166.727 510.96 692528.206 5335166.727 527.953</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006492_9c0e2b89-3bac-46b4-b61d-a4483c549b78">
<gen:stringAttribute name="Flaeche">
<gen:value>41.294</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.022</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.982</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_9c0e2b89-3bac-46b4-b61d-a4483c549b78_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692535.599 5335167.245 510.96 692535.599 5335167.245 523.904 692536.162 5335164.115 523.982 692536.162 5335164.115 510.96 692535.599 5335167.245 510.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006492_abb72588-9bb9-430d-9352-1ed149efeb3d">
<gen:stringAttribute name="Flaeche">
<gen:value>10.608</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.993</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.953</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_abb72588-9bb9-430d-9352-1ed149efeb3d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692524.494 5335166.462 510.96 692524.494 5335166.462 524.158 692525.272 5335166.513 524.953 692525.272 5335166.513 510.96 692524.494 5335166.462 510.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006492_cff73013-30ab-4fa7-9ad5-fa81cc0aa530">
<gen:stringAttribute name="Flaeche">
<gen:value>45.576</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.993</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.953</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_cff73013-30ab-4fa7-9ad5-fa81cc0aa530_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692525.272 5335166.513 510.96 692525.272 5335166.513 524.953 692528.206 5335166.727 527.953 692528.206 5335166.727 510.96 692525.272 5335166.513 510.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006492_dd2c9321-da05-4ad2-8762-45b39b8dc0e5">
<gen:stringAttribute name="Flaeche">
<gen:value>216.706</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.324</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.284</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_dd2c9321-da05-4ad2-8762-45b39b8dc0e5_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692535.31 5335163.922 510.96 692535.31 5335163.922 524.882 692538.001 5335148.814 525.284 692538.001 5335148.814 510.96 692535.31 5335163.922 510.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006492_e3c2f584-7cf2-4503-92cc-11308f909fe3">
<gen:stringAttribute name="Flaeche">
<gen:value>60.621</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.448</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.408</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_e3c2f584-7cf2-4503-92cc-11308f909fe3_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.86 5335147.468 510.96 692531.168 5335147.686 510.96 692533.468 5335148.068 510.96 692533.468 5335148.068 529.408 692531.168 5335147.686 527.011 692529.86 5335147.468 525.648 692529.86 5335147.468 510.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006492_7fd21dc6-0149-4813-b54a-33cfa323cc3d">
<gen:stringAttribute name="Dachneigung">
<gen:value>44.202</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>260.672</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>149.939</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.747</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.707</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>13.198</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>524.158</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_7fd21dc6-0149-4813-b54a-33cfa323cc3d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692528.378 5335147.49 524.158 692528.428 5335147.242 524.158 692529.86 5335147.468 525.648 692531.168 5335147.686 527.011 692533.468 5335148.068 529.408 692533.756 5335148.115 529.707 692529.922 5335166.847 529.707 692529.812 5335166.84 529.595 692528.206 5335166.727 527.953 692525.272 5335166.513 524.953 692524.494 5335166.462 524.158 692528.378 5335147.49 524.158</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006492_87fbd2a7-1f38-46a3-adaf-463fe7422eea">
<gen:stringAttribute name="Dachneigung">
<gen:value>44.203</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>80.672</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>127.156</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.747</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.707</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>12.944</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.904</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006492_87fbd2a7-1f38-46a3-adaf-463fe7422eea_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692533.756 5335148.115 529.707 692538.001 5335148.814 525.284 692535.31 5335163.922 524.882 692536.044 5335164.088 524.107 692536.162 5335164.115 523.982 692535.599 5335167.245 523.904 692535.401 5335167.231 524.107 692529.922 5335166.847 529.707 692533.756 5335148.115 529.707</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>St.-Anna-Platz 7</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006493">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfntH</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>529.030</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>510.979</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>525.040</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_1000</bldg:function>
<bldg:roofType>3100</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">18.051</bldg:measuredHeight>
<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_7ce93242-ee7f-4322-bc80-c3b3c8483e21_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_1541cffc-13b2-4b05-b8b7-5adddcacbf65_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_1f765b64-3397-4495-8683-79fdd18f55f8_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_3529c0b7-34da-44fb-ba9f-cf678f5691e1_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_45537ccf-8185-4534-8ca6-bb64951209f0_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_543d5265-a353-4390-94a9-84ea050bd7b8_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_7727b90b-12bd-4ca4-adb7-01887def60f4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_91a5342d-c744-47b6-bebf-93223d070cb4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_98e530cb-48ea-4bb3-a614-55103e0ac878_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_996f2efb-1956-4492-8299-0a4e234001ca_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_b9dd59bb-df33-4934-aa1d-a463e9504ef3_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_c036357a-d176-4e87-9804-2809aac7557e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_c1972582-4440-482c-82f2-b2f4295712dd_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_d31921c3-4ffe-4d0b-9b00-ccf192082759_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_f12c0f0e-de7b-4534-b55f-2b65f3820deb_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_f942054c-d4d8-4d3a-8301-e2fdd85c062e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_1e5c8a07-66de-4be4-b6ce-163a0cdadbbd_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_23e97aca-fdd0-4fa8-a4b1-bfc0eb914ffa_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_27f8d9df-10f1-4137-95b8-4c5fdb85ee37_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_3ef757d8-7c94-45fa-b9d0-a54706d17f75_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_3f9e3ec8-89b9-401e-831b-afa19161df1b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_40445aa6-df43-4bbf-94ad-700fe68d320a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_49169c74-d322-45d9-b7be-a5f486fd5706_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_49fcd0aa-27fd-4ba2-bc8e-da66e7d89727_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_51eb0036-a35d-44d7-95d9-aa988fb51b71_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_5274fe78-5e20-4bb7-9f7d-62296d27bbc9_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_56250d1f-a735-4570-bd7b-1c072ea77ae1_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_5ed27b3d-4f14-479d-9a72-b4c6ba131afc_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_8717d2a8-84c2-4576-bb4c-e9f5d4e63dea_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_9ccba91a-da95-4410-87b9-0f45356db3fd_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_d0032240-9b2b-48e0-b20f-ed523c5f4bbf_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006493_f28f6d69-ac3e-4118-92ff-c0ef38a3fb81_2_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006493_7ce93242-ee7f-4322-bc80-c3b3c8483e21_2">
<gen:stringAttribute name="Flaeche">
<gen:value>237.834</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_7ce93242-ee7f-4322-bc80-c3b3c8483e21_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692559.01 5335124.22 510.98 692546.91 5335126.4 510.98 692544.63 5335126.77 510.98 692544.91 5335128.49 510.98 692545 5335129 510.98 692545.64 5335133.24 510.98 692546.02 5335135.9 510.98 692546.33 5335137.98 510.98 692550.03 5335137.27 510.98 692550.67 5335143.65 510.98 692561.95 5335141.77 510.98 692559.01 5335124.22 510.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_1541cffc-13b2-4b05-b8b7-5adddcacbf65_2">
<gen:stringAttribute name="Flaeche">
<gen:value>8.746</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.953</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.933</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_1541cffc-13b2-4b05-b8b7-5adddcacbf65_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692544.91 5335128.49 510.98 692544.91 5335128.49 527.804 692545 5335129 527.933 692545 5335129 510.98 692544.91 5335128.49 510.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_1f765b64-3397-4495-8683-79fdd18f55f8_2">
<gen:stringAttribute name="Flaeche">
<gen:value>2.728</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.560</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.181</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.160</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_1f765b64-3397-4495-8683-79fdd18f55f8_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692559.81 5335128.993 525.16 692558.788 5335129.163 527.65 692555.104 5335129.777 528.56 692559.09 5335129.113 528.56 692559.81 5335128.993 525.266 692559.81 5335128.993 525.16</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_3529c0b7-34da-44fb-ba9f-cf678f5691e1_2">
<gen:stringAttribute name="Flaeche">
<gen:value>32.860</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.264</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.243</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_3529c0b7-34da-44fb-ba9f-cf678f5691e1_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692546.91 5335126.4 510.98 692546.91 5335126.4 525.243 692544.63 5335126.77 525.169 692544.63 5335126.77 510.98 692546.91 5335126.4 510.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_45537ccf-8185-4534-8ca6-bb64951209f0_2">
<gen:stringAttribute name="Flaeche">
<gen:value>175.723</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.407</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.386</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_45537ccf-8185-4534-8ca6-bb64951209f0_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692546.91 5335126.4 510.98 692559.01 5335124.22 510.98 692559.01 5335124.22 525.265 692559.01 5335124.22 525.322 692554.315 5335125.066 525.386 692554.315 5335125.066 525.198 692546.91 5335126.4 525.243 692546.91 5335126.4 510.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_543d5265-a353-4390-94a9-84ea050bd7b8_2">
<gen:stringAttribute name="Flaeche">
<gen:value>252.840</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.286</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.266</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_543d5265-a353-4390-94a9-84ea050bd7b8_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692559.01 5335124.22 510.98 692561.95 5335141.77 510.98 692561.95 5335141.77 525.136 692561.95 5335141.77 525.16 692559.81 5335128.993 525.16 692559.81 5335128.993 525.266 692559.01 5335124.22 525.265 692559.01 5335124.22 510.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_7727b90b-12bd-4ca4-adb7-01887def60f4_2">
<gen:stringAttribute name="Flaeche">
<gen:value>0.020</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.671</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.157</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.136</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_7727b90b-12bd-4ca4-adb7-01887def60f4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692560.713 5335140.655 527.65 692561.95 5335141.77 525.16 692561.95 5335141.77 525.136 692560.713 5335140.655 527.65</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_91a5342d-c744-47b6-bebf-93223d070cb4_2">
<gen:stringAttribute name="Flaeche">
<gen:value>27.707</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.825</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.804</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_91a5342d-c744-47b6-bebf-93223d070cb4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692544.91 5335128.49 510.98 692544.63 5335126.77 510.98 692544.63 5335126.77 525.169 692544.81 5335127.877 527.65 692544.91 5335128.49 527.804 692544.91 5335128.49 510.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_98e530cb-48ea-4bb3-a614-55103e0ac878_2">
<gen:stringAttribute name="Flaeche">
<gen:value>0.028</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.560</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.286</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.265</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_98e530cb-48ea-4bb3-a614-55103e0ac878_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692558.401 5335125.005 528.56 692559.01 5335124.22 525.322 692559.01 5335124.22 525.265 692558.401 5335125.005 528.56</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_996f2efb-1956-4492-8299-0a4e234001ca_2">
<gen:stringAttribute name="Flaeche">
<gen:value>74.708</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.761</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.740</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_996f2efb-1956-4492-8299-0a4e234001ca_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692545.486 5335132.223 528.74 692545.64 5335133.24 528.485 692545.64 5335133.24 510.98 692545 5335129 510.98 692545 5335129 527.933 692545.486 5335132.223 528.74</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_b9dd59bb-df33-4934-aa1d-a463e9504ef3_2">
<gen:stringAttribute name="Flaeche">
<gen:value>161.885</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.157</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.136</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_b9dd59bb-df33-4934-aa1d-a463e9504ef3_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692561.95 5335141.77 510.98 692550.67 5335143.65 510.98 692550.67 5335143.65 525.04 692550.723 5335143.641 525.136 692561.95 5335141.77 525.136 692561.95 5335141.77 510.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_c036357a-d176-4e87-9804-2809aac7557e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>53.279</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.823</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.803</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_c036357a-d176-4e87-9804-2809aac7557e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692550.03 5335137.27 510.98 692546.33 5335137.98 510.98 692546.33 5335137.98 525.04 692549.662 5335137.341 525.128 692550.03 5335137.27 525.803 692550.03 5335137.27 510.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_c1972582-4440-482c-82f2-b2f4295712dd_2">
<gen:stringAttribute name="Flaeche">
<gen:value>3.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.560</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.218</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.198</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_c1972582-4440-482c-82f2-b2f4295712dd_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692554.423 5335125.71 528.56 692555.104 5335129.777 528.56 692554.498 5335126.159 527.65 692554.315 5335125.066 525.198 692554.315 5335125.066 525.386 692554.423 5335125.71 528.56</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_d31921c3-4ffe-4d0b-9b00-ccf192082759_2">
<gen:stringAttribute name="Flaeche">
<gen:value>46.142</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.506</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.485</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_d31921c3-4ffe-4d0b-9b00-ccf192082759_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692545.64 5335133.24 510.98 692545.64 5335133.24 528.485 692546.02 5335135.9 527.819 692546.02 5335135.9 510.98 692545.64 5335133.24 510.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_f12c0f0e-de7b-4534-b55f-2b65f3820deb_2">
<gen:stringAttribute name="Flaeche">
<gen:value>33.262</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.840</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.819</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_f12c0f0e-de7b-4534-b55f-2b65f3820deb_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692546.33 5335137.98 510.98 692546.02 5335135.9 510.98 692546.02 5335135.9 527.819 692546.121 5335136.576 527.65 692546.33 5335137.98 525.04 692546.33 5335137.98 510.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006493_f942054c-d4d8-4d3a-8301-e2fdd85c062e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>92.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.823</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.803</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.001</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.980</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_f942054c-d4d8-4d3a-8301-e2fdd85c062e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692550.03 5335137.27 510.98 692550.03 5335137.27 525.803 692550.67 5335143.65 525.04 692550.67 5335143.65 510.98 692550.03 5335137.27 510.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_1e5c8a07-66de-4be4-b6ce-163a0cdadbbd_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>29.012</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>279.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>16.409</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.671</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.061</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.040</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_1e5c8a07-66de-4be4-b6ce-163a0cdadbbd_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692550.813 5335135.744 527.65 692551.883 5335142.127 527.65 692550.723 5335143.641 525.136 692550.67 5335143.65 525.04 692550.03 5335137.27 525.803 692549.662 5335137.341 525.128 692550.813 5335135.744 527.65</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_23e97aca-fdd0-4fa8-a4b1-bfc0eb914ffa_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>76.903</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>99.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>4.321</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.051</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.030</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>528.560</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_23e97aca-fdd0-4fa8-a4b1-bfc0eb914ffa_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692558.401 5335125.005 528.56 692559.09 5335129.113 528.56 692556.755 5335127.401 529.03 692558.401 5335125.005 528.56</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_27f8d9df-10f1-4137-95b8-4c5fdb85ee37_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>76.078</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>190.060</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>44.381</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.761</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.740</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.671</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.650</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_27f8d9df-10f1-4137-95b8-4c5fdb85ee37_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692545.486 5335132.223 528.74 692545 5335129 527.933 692544.91 5335128.49 527.804 692544.81 5335127.877 527.65 692554.498 5335126.159 527.65 692555.104 5335129.777 528.56 692554.494 5335130.625 528.74 692545.486 5335132.223 528.74</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_3ef757d8-7c94-45fa-b9d0-a54706d17f75_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>12.492</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>99.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>15.194</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.560</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.286</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.265</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_3ef757d8-7c94-45fa-b9d0-a54706d17f75_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692559.01 5335124.22 525.265 692559.81 5335128.993 525.266 692559.09 5335129.113 528.56 692558.401 5335125.005 528.56 692559.01 5335124.22 525.265</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_3f9e3ec8-89b9-401e-831b-afa19161df1b_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>77.222</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>190.056</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>4.293</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.051</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.030</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>528.560</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_3f9e3ec8-89b9-401e-831b-afa19161df1b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692558.401 5335125.005 528.56 692556.755 5335127.401 529.03 692554.423 5335125.71 528.56 692558.401 5335125.005 528.56</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_40445aa6-df43-4bbf-94ad-700fe68d320a_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>76.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>9.462</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>20.171</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.761</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.740</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.671</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.650</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_40445aa6-df43-4bbf-94ad-700fe68d320a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692560.713 5335140.655 527.65 692551.883 5335142.127 527.65 692555.576 5335137.079 528.74 692560.713 5335140.655 527.65</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_49169c74-d322-45d9-b7be-a5f486fd5706_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>76.314</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>99.503</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>43.330</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.761</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.740</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.671</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.650</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_49169c74-d322-45d9-b7be-a5f486fd5706_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692560.713 5335140.655 527.65 692555.576 5335137.079 528.74 692554.494 5335130.625 528.74 692555.104 5335129.777 528.56 692558.788 5335129.163 527.65 692560.713 5335140.655 527.65</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_49fcd0aa-27fd-4ba2-bc8e-da66e7d89727_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>28.528</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>10.056</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>11.878</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.671</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.061</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.040</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_49fcd0aa-27fd-4ba2-bc8e-da66e7d89727_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692550.813 5335135.744 527.65 692549.662 5335137.341 525.128 692546.33 5335137.98 525.04 692546.121 5335136.576 527.65 692550.813 5335135.744 527.65</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_51eb0036-a35d-44d7-95d9-aa988fb51b71_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>76.903</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>279.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>4.277</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.051</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.030</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>528.560</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_51eb0036-a35d-44d7-95d9-aa988fb51b71_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692554.423 5335125.71 528.56 692556.755 5335127.401 529.03 692555.104 5335129.777 528.56 692554.423 5335125.71 528.56</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_5274fe78-5e20-4bb7-9f7d-62296d27bbc9_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>24.314</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>190.056</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>26.260</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.671</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.189</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.169</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_5274fe78-5e20-4bb7-9f7d-62296d27bbc9_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692554.498 5335126.159 527.65 692544.81 5335127.877 527.65 692544.63 5335126.77 525.169 692546.91 5335126.4 525.243 692554.315 5335125.066 525.198 692554.498 5335126.159 527.65</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_56250d1f-a735-4570-bd7b-1c072ea77ae1_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>27.397</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>9.462</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>28.785</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.671</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.157</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.136</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_56250d1f-a735-4570-bd7b-1c072ea77ae1_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692551.883 5335142.127 527.65 692560.713 5335140.655 527.65 692561.95 5335141.77 525.136 692550.723 5335143.641 525.136 692551.883 5335142.127 527.65</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_5ed27b3d-4f14-479d-9a72-b4c6ba131afc_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>76.078</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>10.056</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>31.512</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.761</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.740</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.671</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.650</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_5ed27b3d-4f14-479d-9a72-b4c6ba131afc_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692554.494 5335130.625 528.74 692550.813 5335135.744 527.65 692546.121 5335136.576 527.65 692546.02 5335135.9 527.819 692545.64 5335133.24 528.485 692545.486 5335132.223 528.74 692554.494 5335130.625 528.74</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_8717d2a8-84c2-4576-bb4c-e9f5d4e63dea_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>11.627</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>190.056</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>14.407</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.560</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.343</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.322</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_8717d2a8-84c2-4576-bb4c-e9f5d4e63dea_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692559.01 5335124.22 525.322 692558.401 5335125.005 528.56 692554.423 5335125.71 528.56 692554.315 5335125.066 525.386 692559.01 5335124.22 525.322</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_9ccba91a-da95-4410-87b9-0f45356db3fd_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>76.315</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>279.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>29.983</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.761</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.740</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>16.671</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.650</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_9ccba91a-da95-4410-87b9-0f45356db3fd_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692554.494 5335130.625 528.74 692555.576 5335137.079 528.74 692551.883 5335142.127 527.65 692550.813 5335135.744 527.65 692554.494 5335130.625 528.74</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_d0032240-9b2b-48e0-b20f-ed523c5f4bbf_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>22.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>99.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>33.176</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.671</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.181</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.160</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_d0032240-9b2b-48e0-b20f-ed523c5f4bbf_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692559.81 5335128.993 525.16 692561.95 5335141.77 525.16 692560.713 5335140.655 527.65 692558.788 5335129.163 527.65 692559.81 5335128.993 525.16</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006493_f28f6d69-ac3e-4118-92ff-c0ef38a3fb81_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>77.223</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>9.462</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>4.293</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.051</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.030</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>17.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>528.560</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006493_f28f6d69-ac3e-4118-92ff-c0ef38a3fb81_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692555.104 5335129.777 528.56 692556.755 5335127.401 529.03 692559.09 5335129.113 528.56 692555.104 5335129.777 528.56</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>Triftstraße 5</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006494">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfntY</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>529.760</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.133</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>523.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_1000</bldg:function>
<bldg:roofType>3100</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">18.627</bldg:measuredHeight>
<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_7e57afe8-18d5-4ce1-a3ab-93f2e6107a60_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_03f9e859-57e2-46ea-832a-d1e053166a8d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_0591d0fa-1b2d-478a-abbc-1a725bcf6248_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_0ab34029-216e-4148-880d-6bbce8b86874_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_2079e55c-7163-4f47-baa8-3c54af635a29_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_2b60ccc6-07a8-4a45-bd14-8cc896fe90ce_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_31c6d970-bc8d-45a4-831a-edac351d551c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_4b6e9539-88f0-40d8-bae3-1542e7404e20_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_75da8044-355f-4c30-88b0-f4c7ed210c4f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_7fd05067-2c99-4499-9500-6d141ba76eb9_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_863cc0f6-91a2-45a2-836a-55b159134d55_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_8e08ad20-3dc2-48fb-b52e-56c2471cb2e7_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_965bb55d-dffb-408a-9cf0-4dbc126b0cf6_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_b3be7276-60a1-4132-af59-008ade9583e6_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_ba645b4f-3749-48ce-a9f1-a842a5b0dc4e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_bb23f8b6-7099-4056-9f13-a92eb5503566_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_c9d54e4d-37d3-4a79-a4a0-a725a19044c3_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_cefc2b59-de74-4c40-93f0-a9af99743bb8_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_d12d88ba-4cfa-4547-98e3-814125bc8bd8_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_ee8cebcc-8e60-49e7-b6cf-4ef519436acf_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_fb876a09-add7-41b2-aab3-7dff20696eb7_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_0db3a86b-e9ab-4dde-a7b1-027d7fe6c098_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_2965467d-f445-4d8b-8a6c-8b266a7ed781_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_8073d2ac-03d7-4bd7-90a0-32a85c5c06a0_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_860e729c-94e7-4565-bc3a-fbe0f1ed0c25_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_942f7129-e94e-40b6-ac71-14255242bb48_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006494_9f25cbdd-3af5-4767-a64c-b04b22bfe475_2_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006494_7e57afe8-18d5-4ce1-a3ab-93f2e6107a60_2">
<gen:stringAttribute name="Flaeche">
<gen:value>250.920</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_7e57afe8-18d5-4ce1-a3ab-93f2e6107a60_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692545.64 5335133.24 511.13 692545 5335129 511.13 692544.91 5335128.49 511.13 692544.63 5335126.77 511.13 692532.72 5335128.65 511.13 692531.63 5335133.38 511.13 692530.98 5335136.15 511.13 692529.36 5335143.18 511.13 692528.56 5335146.58 511.13 692528.43 5335147.24 511.13 692529.86 5335147.47 511.13 692533.47 5335148.07 511.13 692538 5335148.81 511.13 692538.49 5335148.89 511.13 692538.63 5335148.36 511.13 692540.75 5335139.69 511.13 692541.81 5335138.67 511.13 692546.33 5335137.98 511.13 692546.02 5335135.9 511.13 692545.64 5335133.24 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_03f9e859-57e2-46ea-832a-d1e053166a8d_2">
<gen:stringAttribute name="Flaeche">
<gen:value>18.423</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.569</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.702</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_03f9e859-57e2-46ea-832a-d1e053166a8d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.86 5335147.47 511.13 692528.43 5335147.24 511.13 692528.43 5335147.24 523.27 692529.492 5335147.411 523.27 692529.492 5335147.411 525.35 692529.86 5335147.47 525.702 692529.86 5335147.47 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_0591d0fa-1b2d-478a-abbc-1a725bcf6248_2">
<gen:stringAttribute name="Flaeche">
<gen:value>59.669</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.034</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.168</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_0591d0fa-1b2d-478a-abbc-1a725bcf6248_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.86 5335147.47 511.13 692529.86 5335147.47 525.702 692533.47 5335148.07 529.168 692533.47 5335148.07 511.13 692529.86 5335147.47 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_0ab34029-216e-4148-880d-6bbce8b86874_2">
<gen:stringAttribute name="Flaeche">
<gen:value>34.541</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.137</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_0ab34029-216e-4148-880d-6bbce8b86874_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692531.63 5335133.38 511.13 692531.63 5335133.38 523.27 692530.98 5335136.15 523.27 692530.98 5335136.15 511.13 692531.63 5335133.38 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_2079e55c-7163-4f47-baa8-3c54af635a29_2">
<gen:stringAttribute name="Flaeche">
<gen:value>21.296</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.276</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.409</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_2079e55c-7163-4f47-baa8-3c54af635a29_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692544.63 5335126.77 511.13 692544.91 5335128.49 511.13 692544.91 5335128.49 525.409 692544.899 5335128.424 525.35 692544.899 5335128.424 523.27 692544.63 5335126.77 523.27 692544.63 5335126.77 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_2b60ccc6-07a8-4a45-bd14-8cc896fe90ce_2">
<gen:stringAttribute name="Flaeche">
<gen:value>87.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.137</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_2b60ccc6-07a8-4a45-bd14-8cc896fe90ce_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692530.98 5335136.15 511.13 692530.98 5335136.15 523.27 692529.36 5335143.18 523.27 692529.36 5335143.18 511.13 692530.98 5335136.15 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_31c6d970-bc8d-45a4-831a-edac351d551c_2">
<gen:stringAttribute name="Flaeche">
<gen:value>32.378</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.327</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.460</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_31c6d970-bc8d-45a4-831a-edac351d551c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692546.33 5335137.98 511.13 692546.33 5335137.98 525.593 692546.02 5335135.9 527.46 692546.02 5335135.9 511.13 692546.33 5335137.98 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_4b6e9539-88f0-40d8-bae3-1542e7404e20_2">
<gen:stringAttribute name="Flaeche">
<gen:value>146.378</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.137</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_4b6e9539-88f0-40d8-bae3-1542e7404e20_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692544.63 5335126.77 511.13 692544.63 5335126.77 523.27 692532.72 5335128.65 523.27 692532.72 5335128.65 511.13 692544.63 5335126.77 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_75da8044-355f-4c30-88b0-f4c7ed210c4f_2">
<gen:stringAttribute name="Flaeche">
<gen:value>71.361</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.542</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.675</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_75da8044-355f-4c30-88b0-f4c7ed210c4f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692545.64 5335133.24 511.13 692545.64 5335133.24 529.675 692545 5335129 525.869 692545 5335129 511.13 692545.64 5335133.24 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_7fd05067-2c99-4499-9500-6d141ba76eb9_2">
<gen:stringAttribute name="Flaeche">
<gen:value>127.946</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.387</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.520</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_7fd05067-2c99-4499-9500-6d141ba76eb9_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692538.63 5335148.36 511.13 692538.63 5335148.36 525.52 692540.75 5335139.69 525.41 692540.75 5335139.69 511.13 692538.63 5335148.36 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_863cc0f6-91a2-45a2-836a-55b159134d55_2">
<gen:stringAttribute name="Flaeche">
<gen:value>85.156</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.627</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.760</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_863cc0f6-91a2-45a2-836a-55b159134d55_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692538.49 5335148.89 525.536 692538.49 5335148.89 511.13 692538 5335148.81 511.13 692533.47 5335148.07 511.13 692533.47 5335148.07 529.168 692534.087 5335148.171 529.76 692538.49 5335148.89 525.536</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_8e08ad20-3dc2-48fb-b52e-56c2471cb2e7_2">
<gen:stringAttribute name="Flaeche">
<gen:value>24.094</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.350</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>12.137</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.270</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_8e08ad20-3dc2-48fb-b52e-56c2471cb2e7_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692533.457 5335130.23 525.35 692533.457 5335130.23 523.27 692544.899 5335128.424 523.27 692544.899 5335128.424 525.35 692533.457 5335130.23 525.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_965bb55d-dffb-408a-9cf0-4dbc126b0cf6_2">
<gen:stringAttribute name="Flaeche">
<gen:value>20.990</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.480</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.614</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_965bb55d-dffb-408a-9cf0-4dbc126b0cf6_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692541.81 5335138.67 511.13 692540.75 5335139.69 511.13 692540.75 5335139.69 525.41 692540.833 5335139.61 525.35 692541.436 5335139.03 525.35 692541.81 5335138.67 525.614 692541.81 5335138.67 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_b3be7276-60a1-4132-af59-008ade9583e6_2">
<gen:stringAttribute name="Flaeche">
<gen:value>58.927</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.137</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_b3be7276-60a1-4132-af59-008ade9583e6_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692532.72 5335128.65 511.13 692532.72 5335128.65 523.27 692531.63 5335133.38 523.27 692531.63 5335133.38 511.13 692532.72 5335128.65 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_ba645b4f-3749-48ce-a9f1-a842a5b0dc4e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>8.166</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.137</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_ba645b4f-3749-48ce-a9f1-a842a5b0dc4e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692528.56 5335146.58 511.13 692528.56 5335146.58 523.27 692528.43 5335147.24 523.27 692528.43 5335147.24 511.13 692528.56 5335146.58 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_bb23f8b6-7099-4056-9f13-a92eb5503566_2">
<gen:stringAttribute name="Flaeche">
<gen:value>47.075</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.627</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.760</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_bb23f8b6-7099-4056-9f13-a92eb5503566_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692545.64 5335133.24 511.13 692546.02 5335135.9 511.13 692546.02 5335135.9 527.46 692545.654 5335133.335 529.76 692545.64 5335133.24 529.675 692545.64 5335133.24 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_c9d54e4d-37d3-4a79-a4a0-a725a19044c3_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.514</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.736</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.869</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_c9d54e4d-37d3-4a79-a4a0-a725a19044c3_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692545 5335129 511.13 692545 5335129 525.869 692544.91 5335128.49 525.409 692544.91 5335128.49 511.13 692545 5335129 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_cefc2b59-de74-4c40-93f0-a9af99743bb8_2">
<gen:stringAttribute name="Flaeche">
<gen:value>42.403</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.137</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_cefc2b59-de74-4c40-93f0-a9af99743bb8_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.36 5335143.18 511.13 692529.36 5335143.18 523.27 692528.56 5335146.58 523.27 692528.56 5335146.58 511.13 692529.36 5335143.18 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_d12d88ba-4cfa-4547-98e3-814125bc8bd8_2">
<gen:stringAttribute name="Flaeche">
<gen:value>66.178</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.480</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.614</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_d12d88ba-4cfa-4547-98e3-814125bc8bd8_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692541.81 5335138.67 511.13 692541.81 5335138.67 525.614 692546.33 5335137.98 525.593 692546.33 5335137.98 511.13 692541.81 5335138.67 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_ee8cebcc-8e60-49e7-b6cf-4ef519436acf_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.893</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.403</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.536</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_ee8cebcc-8e60-49e7-b6cf-4ef519436acf_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692538.49 5335148.89 511.13 692538.49 5335148.89 525.536 692538.63 5335148.36 525.52 692538.63 5335148.36 511.13 692538.49 5335148.89 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006494_fb876a09-add7-41b2-aab3-7dff20696eb7_2">
<gen:stringAttribute name="Flaeche">
<gen:value>36.675</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.350</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>12.137</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.270</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_fb876a09-add7-41b2-aab3-7dff20696eb7_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.492 5335147.411 525.35 692529.492 5335147.411 523.27 692533.457 5335130.23 523.27 692533.457 5335130.23 525.35 692529.492 5335147.411 525.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006494_0db3a86b-e9ab-4dde-a7b1-027d7fe6c098_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.506</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>257.005</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>100.879</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.627</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.760</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_0db3a86b-e9ab-4dde-a7b1-027d7fe6c098_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.203 5335134.669 529.76 692534.087 5335148.171 529.76 692533.47 5335148.07 529.168 692529.86 5335147.47 525.702 692529.492 5335147.411 525.35 692533.457 5335130.23 525.35 692537.203 5335134.669 529.76</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006494_2965467d-f445-4d8b-8a6c-8b266a7ed781_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>39.639</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.137</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>12.137</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.270</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_2965467d-f445-4d8b-8a6c-8b266a7ed781_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692533.457 5335130.23 523.27 692529.492 5335147.411 523.27 692528.43 5335147.24 523.27 692528.56 5335146.58 523.27 692529.36 5335143.18 523.27 692530.98 5335136.15 523.27 692531.63 5335133.38 523.27 692532.72 5335128.65 523.27 692544.63 5335126.77 523.27 692544.899 5335128.424 523.27 692533.457 5335130.23 523.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006494_8073d2ac-03d7-4bd7-90a0-32a85c5c06a0_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>48.405</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>188.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>66.932</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.627</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.760</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_8073d2ac-03d7-4bd7-90a0-32a85c5c06a0_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692545.654 5335133.335 529.76 692537.203 5335134.669 529.76 692533.457 5335130.23 525.35 692544.899 5335128.424 525.35 692544.91 5335128.49 525.409 692545 5335129 525.869 692545.64 5335133.24 529.675 692545.654 5335133.335 529.76</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006494_860e729c-94e7-4565-bc3a-fbe0f1ed0c25_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.506</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>77.005</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>75.029</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.627</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.760</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_860e729c-94e7-4565-bc3a-fbe0f1ed0c25_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.203 5335134.669 529.76 692540.949 5335139.107 525.35 692540.833 5335139.61 525.35 692540.75 5335139.69 525.41 692538.63 5335148.36 525.52 692538.49 5335148.89 525.536 692534.087 5335148.171 529.76 692537.203 5335134.669 529.76</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006494_942f7129-e94e-40b6-ac71-14255242bb48_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>0.118</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.350</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_942f7129-e94e-40b6-ac71-14255242bb48_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692540.949 5335139.107 525.35 692541.436 5335139.03 525.35 692540.833 5335139.61 525.35 692540.949 5335139.107 525.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006494_9f25cbdd-3af5-4767-a64c-b04b22bfe475_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>48.405</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>8.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>44.789</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.627</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.760</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006494_9f25cbdd-3af5-4767-a64c-b04b22bfe475_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692545.654 5335133.335 529.76 692546.02 5335135.9 527.46 692546.33 5335137.98 525.593 692541.81 5335138.67 525.614 692541.436 5335139.03 525.35 692540.949 5335139.107 525.35 692537.203 5335134.669 529.76 692545.654 5335133.335 529.76</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>St.-Anna-Platz 6</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006496">
<creationDate>2015-09-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfnoF</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>530.291</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>526.130</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_9998</bldg:function>
<bldg:roofType>3200</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">19.161</bldg:measuredHeight>
<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_4ade534a-9499-4f19-a68c-d57fbe6e6f1f_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_3da729e8-d4f0-46a3-8fff-f4ed19d9a6af_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_516d62a6-4fec-42cc-8bfa-104d895f615c_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_90878a84-7f76-454e-9f5c-5fbda0c37acd_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_9ae1a738-ea72-4a2e-9f4a-a3c6e9ef893a_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_a16170d9-4ebe-49ab-9046-50ff4c85afea_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_ad4b96b0-53ec-4ce4-a4f6-a5492677d493_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_c223a6c0-ce43-46da-9fdb-832924dad178_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_ea4bc2a3-e40d-466b-ad88-a3d2e64297b7_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_ed6ec638-d025-4ae3-881d-367d6258adca_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_30c2f663-9840-4723-b028-4e364a273a2c_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_3b8e8047-446b-4238-ae5d-bef084f9c378_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_82644857-94be-486a-b76d-b21cd8b0037f_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_ac3cf335-bbe7-450e-9c3d-1fb0ec548b52_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_bdfd53d1-a2e6-4487-b597-2b86e859d062_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006496_df4d1ddf-2d85-4a90-8c51-9e31fa828741_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006496_4ade534a-9499-4f19-a68c-d57fbe6e6f1f">
<gen:stringAttribute name="Flaeche">
<gen:value>313.754</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_4ade534a-9499-4f19-a68c-d57fbe6e6f1f_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692556.115 5335099.681 511.13 692555.458 5335086.409 511.13 692555.278 5335086.422 511.13 692543.424 5335086.978 511.13 692544.167 5335101.788 511.13 692544.114 5335101.797 511.13 692541.296 5335102.266 511.13 692540.943 5335102.322 511.13 692540.951 5335102.357 511.13 692540.97 5335102.454 511.13 692541.649 5335105.782 511.13 692542.906 5335111.975 511.13 692542.916 5335112.025 511.13 692544.605 5335111.727 511.13 692556.604 5335109.609 511.13 692556.115 5335099.681 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006496_3da729e8-d4f0-46a3-8fff-f4ed19d9a6af">
<gen:stringAttribute name="Flaeche">
<gen:value>96.307</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.116</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.246</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_3da729e8-d4f0-46a3-8fff-f4ed19d9a6af_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692541.649 5335105.782 526.246 692542.906 5335111.975 526.244 692542.916 5335112.025 526.202 692542.916 5335112.025 511.13 692542.906 5335111.975 511.13 692541.649 5335105.782 511.13 692541.649 5335105.782 526.246</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006496_516d62a6-4fec-42cc-8bfa-104d895f615c">
<gen:stringAttribute name="Flaeche">
<gen:value>2.728</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.065</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.195</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_516d62a6-4fec-42cc-8bfa-104d895f615c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692555.458 5335086.409 511.13 692555.458 5335086.409 526.192 692555.278 5335086.422 526.195 692555.278 5335086.422 511.13 692555.458 5335086.409 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006496_90878a84-7f76-454e-9f5c-5fbda0c37acd">
<gen:stringAttribute name="Flaeche">
<gen:value>209.458</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.072</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.203</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_90878a84-7f76-454e-9f5c-5fbda0c37acd_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692544.605 5335111.727 526.203 692556.604 5335109.609 526.203 692556.604 5335109.609 511.13 692544.605 5335111.727 511.13 692542.916 5335112.025 511.13 692542.916 5335112.025 526.202 692544.605 5335111.727 526.203</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006496_9ae1a738-ea72-4a2e-9f4a-a3c6e9ef893a">
<gen:stringAttribute name="Flaeche">
<gen:value>223.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.066</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.196</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_9ae1a738-ea72-4a2e-9f4a-a3c6e9ef893a_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692543.424 5335086.978 511.13 692543.424 5335086.978 526.189 692544.167 5335101.788 526.196 692544.167 5335101.788 511.13 692543.424 5335086.978 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006496_a16170d9-4ebe-49ab-9046-50ff4c85afea">
<gen:stringAttribute name="Flaeche">
<gen:value>349.982</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.072</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.203</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_a16170d9-4ebe-49ab-9046-50ff4c85afea_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692555.458 5335086.409 511.13 692556.115 5335099.681 511.13 692556.604 5335109.609 511.13 692556.604 5335109.609 526.203 692556.115 5335099.681 526.195 692555.458 5335086.409 526.192 692555.458 5335086.409 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006496_ad4b96b0-53ec-4ce4-a4f6-a5492677d493">
<gen:stringAttribute name="Flaeche">
<gen:value>5.355</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.005</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.135</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_ad4b96b0-53ec-4ce4-a4f6-a5492677d493_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692541.296 5335102.266 511.13 692541.296 5335102.266 526.135 692540.943 5335102.322 526.13 692540.943 5335102.322 511.13 692541.296 5335102.266 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006496_c223a6c0-ce43-46da-9fdb-832924dad178">
<gen:stringAttribute name="Flaeche">
<gen:value>178.690</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.065</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.195</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_c223a6c0-ce43-46da-9fdb-832924dad178_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692555.278 5335086.422 511.13 692555.278 5335086.422 526.195 692543.424 5335086.978 526.189 692543.424 5335086.978 511.13 692555.278 5335086.422 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006496_ea4bc2a3-e40d-466b-ad88-a3d2e64297b7">
<gen:stringAttribute name="Flaeche">
<gen:value>43.709</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.066</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.196</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_ea4bc2a3-e40d-466b-ad88-a3d2e64297b7_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692544.114 5335101.797 511.13 692544.167 5335101.788 511.13 692544.167 5335101.788 526.196 692544.114 5335101.797 526.159 692541.296 5335102.266 526.135 692541.296 5335102.266 511.13 692544.114 5335101.797 511.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006496_ed6ec638-d025-4ae3-881d-367d6258adca">
<gen:stringAttribute name="Flaeche">
<gen:value>53.367</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.116</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.246</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_ed6ec638-d025-4ae3-881d-367d6258adca_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692540.943 5335102.322 526.13 692540.951 5335102.357 526.16 692540.97 5335102.454 526.242 692541.649 5335105.782 526.246 692541.649 5335105.782 511.13 692540.97 5335102.454 511.13 692540.951 5335102.357 511.13 692540.943 5335102.322 511.13 692540.943 5335102.322 526.13</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006496_30c2f663-9840-4723-b028-4e364a273a2c">
<gen:stringAttribute name="Dachneigung">
<gen:value>31.290</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>283.721</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>22.991</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.160</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.291</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.112</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.242</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_30c2f663-9840-4723-b028-4e364a273a2c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692544.362 5335106.787 530.291 692542.906 5335111.975 526.244 692541.649 5335105.782 526.246 692540.97 5335102.454 526.242 692544.362 5335106.787 530.291</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006496_3b8e8047-446b-4238-ae5d-bef084f9c378">
<gen:stringAttribute name="Dachneigung">
<gen:value>55.765</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>95.088</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>131.949</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.160</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.291</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.062</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.192</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_3b8e8047-446b-4238-ae5d-bef084f9c378_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692555.458 5335086.409 526.192 692556.115 5335099.681 526.195 692556.604 5335109.609 526.203 692550.385 5335105.724 530.291 692550.138 5335100.734 530.291 692549.743 5335092.718 530.291 692555.458 5335086.409 526.192</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006496_82644857-94be-486a-b76d-b21cd8b0037f">
<gen:stringAttribute name="Dachneigung">
<gen:value>55.793</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>184.976</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>43.892</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.160</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.291</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.058</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.189</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_82644857-94be-486a-b76d-b21cd8b0037f_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692555.278 5335086.422 526.195 692555.458 5335086.409 526.192 692549.743 5335092.718 530.291 692543.424 5335086.978 526.189 692555.278 5335086.422 526.195</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006496_ac3cf335-bbe7-450e-9c3d-1fb0ec548b52">
<gen:stringAttribute name="Dachneigung">
<gen:value>55.760</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>275.067</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>101.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.160</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.291</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.029</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.159</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_ac3cf335-bbe7-450e-9c3d-1fb0ec548b52_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692549.743 5335092.718 530.291 692550.138 5335100.734 530.291 692550.385 5335105.724 530.291 692544.114 5335101.797 526.159 692544.167 5335101.788 526.196 692543.424 5335086.978 526.189 692549.743 5335092.718 530.291</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006496_bdfd53d1-a2e6-4487-b597-2b86e859d062">
<gen:stringAttribute name="Dachneigung">
<gen:value>50.202</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>192.262</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>30.335</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.160</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.291</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.130</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_bdfd53d1-a2e6-4487-b597-2b86e859d062_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692541.296 5335102.266 526.135 692544.114 5335101.797 526.159 692550.385 5335105.724 530.291 692544.362 5335106.787 530.291 692540.97 5335102.454 526.242 692540.951 5335102.357 526.16 692540.943 5335102.322 526.13 692541.296 5335102.266 526.135</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006496_df4d1ddf-2d85-4a90-8c51-9e31fa828741">
<gen:stringAttribute name="Dachneigung">
<gen:value>50.203</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>12.253</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>63.989</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.160</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.291</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.072</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.202</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006496_df4d1ddf-2d85-4a90-8c51-9e31fa828741_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692544.362 5335106.787 530.291 692550.385 5335105.724 530.291 692556.604 5335109.609 526.203 692544.605 5335111.727 526.203 692542.916 5335112.025 526.202 692542.906 5335111.975 526.244 692544.362 5335106.787 530.291</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>Triftstraße 1</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006497">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfnln</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>529.110</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>523.539</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_1000</bldg:function>
<bldg:roofType>3100</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">17.92</bldg:measuredHeight>
<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_3f8c21de-a06e-4e3d-8274-6b4a1d17ba94_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_0aeeb1e8-0e4b-4ef4-879d-18108d543dcc_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_0f5803ab-b7ad-484b-a213-155718f4d960_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_5440df52-3b79-46e4-b0a2-24806e7d4a51_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_58549d73-d973-46e1-b7ee-f6901c4ad812_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_77ac41bc-98bb-4693-8ab8-06c1940bb316_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_7ea0ecdc-75ad-4ea1-af3b-a94f835fe264_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_897241a2-82ae-415c-996d-6535ef3ba45d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_969eba03-90e0-4b00-80ed-7e3d755e8b8f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_a1b09d61-d9f8-4302-ba6a-061e9f76ab10_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_c0a3db0c-7265-4720-89a0-9b449ffd3f48_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_c63b7ba1-3ad7-42a1-ac25-f0b60f677ef0_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_32869505-7030-4d94-86e7-694c0f86d79b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_46ee364b-4a46-4e39-b2ce-ed77773a45bd_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_5f729cb8-ea9a-4e1d-bf3a-132deba38ed0_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_770b6eb7-3a6d-4ac7-b17b-5f109fde5ef4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_c6bfe749-d75e-4d14-b013-e93b237f5179_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_d287742a-ce0f-4429-81c0-6cc1cb594eb3_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006497_e5adf5ae-5680-4398-9d6b-fa84446f21cc_2_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006497_3f8c21de-a06e-4e3d-8274-6b4a1d17ba94_2">
<gen:stringAttribute name="Flaeche">
<gen:value>133.269</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_3f8c21de-a06e-4e3d-8274-6b4a1d17ba94_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692541.65 5335105.78 511.19 692540.95 5335102.32 511.19 692541.3 5335102.27 511.19 692540.82 5335100.04 511.19 692532.65 5335101.54 511.19 692532.26 5335101.61 511.19 692531.11 5335106.29 511.19 692530.95 5335106.89 511.19 692529.47 5335112.76 511.19 692533.5 5335113.68 511.19 692542.92 5335112.03 511.19 692541.65 5335105.78 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006497_0aeeb1e8-0e4b-4ef4-879d-18108d543dcc_2">
<gen:stringAttribute name="Flaeche">
<gen:value>4.935</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.457</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.647</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_0aeeb1e8-0e4b-4ef4-879d-18108d543dcc_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692532.65 5335101.54 511.19 692532.65 5335101.54 523.644 692532.26 5335101.61 523.647 692532.26 5335101.61 511.19 692532.65 5335101.54 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006497_0f5803ab-b7ad-484b-a213-155718f4d960_2">
<gen:stringAttribute name="Flaeche">
<gen:value>5.608</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.869</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.059</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_0f5803ab-b7ad-484b-a213-155718f4d960_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692540.95 5335102.32 511.19 692540.95 5335102.32 527.042 692541.3 5335102.27 527.059 692541.3 5335102.27 511.19 692540.95 5335102.32 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006497_5440df52-3b79-46e4-b0a2-24806e7d4a51_2">
<gen:stringAttribute name="Flaeche">
<gen:value>118.835</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.426</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.616</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_5440df52-3b79-46e4-b0a2-24806e7d4a51_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692533.5 5335113.68 511.19 692533.5 5335113.68 523.616 692542.92 5335112.03 523.616 692542.92 5335112.03 511.19 692533.5 5335113.68 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006497_58549d73-d973-46e1-b7ee-f6901c4ad812_2">
<gen:stringAttribute name="Flaeche">
<gen:value>103.346</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.920</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.110</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_58549d73-d973-46e1-b7ee-f6901c4ad812_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692541.65 5335105.78 511.19 692542.92 5335112.03 511.19 692542.92 5335112.03 523.616 692542.56 5335110.257 527.09 692541.756 5335106.304 529.11 692541.65 5335105.78 528.842 692541.65 5335105.78 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006497_77ac41bc-98bb-4693-8ab8-06c1940bb316_2">
<gen:stringAttribute name="Flaeche">
<gen:value>59.194</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.652</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.842</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_77ac41bc-98bb-4693-8ab8-06c1940bb316_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692540.95 5335102.32 511.19 692541.65 5335105.78 511.19 692541.65 5335105.78 528.842 692540.956 5335102.35 527.09 692540.95 5335102.32 527.042 692540.95 5335102.32 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006497_7ea0ecdc-75ad-4ea1-af3b-a94f835fe264_2">
<gen:stringAttribute name="Flaeche">
<gen:value>98.296</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.920</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.110</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_7ea0ecdc-75ad-4ea1-af3b-a94f835fe264_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.47 5335112.76 511.19 692530.95 5335106.89 511.19 692530.95 5335106.89 528.737 692530.785 5335107.544 529.11 692529.892 5335111.086 527.09 692529.47 5335112.76 523.749 692529.47 5335112.76 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006497_897241a2-82ae-415c-996d-6535ef3ba45d_2">
<gen:stringAttribute name="Flaeche">
<gen:value>32.184</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.869</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.059</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_897241a2-82ae-415c-996d-6535ef3ba45d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692541.3 5335102.27 511.19 692541.3 5335102.27 527.059 692540.82 5335100.04 523.539 692540.82 5335100.04 511.19 692541.3 5335102.27 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006497_969eba03-90e0-4b00-80ed-7e3d755e8b8f_2">
<gen:stringAttribute name="Flaeche">
<gen:value>103.016</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.454</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.644</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_969eba03-90e0-4b00-80ed-7e3d755e8b8f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692540.82 5335100.04 511.19 692540.82 5335100.04 523.539 692532.65 5335101.54 523.644 692532.65 5335101.54 511.19 692540.82 5335100.04 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006497_a1b09d61-d9f8-4302-ba6a-061e9f76ab10_2">
<gen:stringAttribute name="Flaeche">
<gen:value>10.790</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.547</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.737</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_a1b09d61-d9f8-4302-ba6a-061e9f76ab10_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692531.11 5335106.29 511.19 692531.11 5335106.29 528.394 692530.95 5335106.89 528.737 692530.95 5335106.89 511.19 692531.11 5335106.29 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006497_c0a3db0c-7265-4720-89a0-9b449ffd3f48_2">
<gen:stringAttribute name="Flaeche">
<gen:value>52.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.645</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.835</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_c0a3db0c-7265-4720-89a0-9b449ffd3f48_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692533.5 5335113.68 511.19 692529.47 5335112.76 511.19 692529.47 5335112.76 523.749 692533.213 5335113.615 523.835 692533.5 5335113.68 523.616 692533.5 5335113.68 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006497_c63b7ba1-3ad7-42a1-ac25-f0b60f677ef0_2">
<gen:stringAttribute name="Flaeche">
<gen:value>73.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.204</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>528.394</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.190</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_c63b7ba1-3ad7-42a1-ac25-f0b60f677ef0_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692531.11 5335106.29 511.19 692532.26 5335101.61 511.19 692532.26 5335101.61 523.647 692531.679 5335103.975 527.09 692531.642 5335104.125 527.161 692531.11 5335106.29 528.394 692531.11 5335106.29 511.19</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006497_32869505-7030-4d94-86e7-694c0f86d79b_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>61.055</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.480</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>10.700</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.920</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.110</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.900</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.090</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_32869505-7030-4d94-86e7-694c0f86d79b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692530.785 5335107.544 529.11 692532.425 5335107.938 529.11 692533.237 5335111.89 527.09 692529.892 5335111.086 527.09 692530.785 5335107.544 529.11</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006497_46ee364b-4a46-4e39-b2ce-ed77773a45bd_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>27.500</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>9.935</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>37.799</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.900</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.090</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>12.426</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.616</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_46ee364b-4a46-4e39-b2ce-ed77773a45bd_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692533.237 5335111.89 527.09 692542.56 5335110.257 527.09 692542.92 5335112.03 523.616 692533.5 5335113.68 523.616 692533.213 5335113.615 523.835 692533.237 5335111.89 527.09</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006497_5f729cb8-ea9a-4e1d-bf3a-132deba38ed0_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>63.392</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>189.935</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>42.745</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.920</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.110</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.900</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.090</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_5f729cb8-ea9a-4e1d-bf3a-132deba38ed0_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692531.679 5335103.975 527.09 692540.956 5335102.35 527.09 692541.65 5335105.78 528.842 692541.756 5335106.304 529.11 692532.425 5335107.938 529.11 692531.642 5335104.125 527.161 692531.679 5335103.975 527.09</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006497_770b6eb7-3a6d-4ac7-b17b-5f109fde5ef4_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>61.055</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.480</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.380</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.920</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.110</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.971</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.161</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_770b6eb7-3a6d-4ac7-b17b-5f109fde5ef4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692530.95 5335106.89 528.737 692531.11 5335106.29 528.394 692531.642 5335104.125 527.161 692532.425 5335107.938 529.11 692530.785 5335107.544 529.11 692530.95 5335106.89 528.737</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006497_c6bfe749-d75e-4d14-b013-e93b237f5179_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>32.924</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>189.935</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>38.426</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.900</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.090</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>12.349</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.539</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_c6bfe749-d75e-4d14-b013-e93b237f5179_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692532.26 5335101.61 523.647 692532.65 5335101.54 523.644 692540.82 5335100.04 523.539 692541.3 5335102.27 527.059 692540.95 5335102.32 527.042 692540.956 5335102.35 527.09 692531.679 5335103.975 527.09 692532.26 5335101.61 523.647</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006497_d287742a-ce0f-4429-81c0-6cc1cb594eb3_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>27.330</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.480</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>13.520</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.900</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.090</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>12.559</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.749</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_d287742a-ce0f-4429-81c0-6cc1cb594eb3_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.892 5335111.086 527.09 692533.237 5335111.89 527.09 692533.213 5335113.615 523.835 692529.47 5335112.76 523.749 692529.892 5335111.086 527.09</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006497_e5adf5ae-5680-4398-9d6b-fa84446f21cc_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>63.392</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>9.935</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>42.706</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>17.920</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.110</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.900</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>527.090</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006497_e5adf5ae-5680-4398-9d6b-fa84446f21cc_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692541.756 5335106.304 529.11 692542.56 5335110.257 527.09 692533.237 5335111.89 527.09 692532.425 5335107.938 529.11 692541.756 5335106.304 529.11</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>St.-Anna-Platz 4</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006498">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfnmQ</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>519.822</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>518.815</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_9998</bldg:function>
<bldg:roofType>9999</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">8.322</bldg:measuredHeight>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_d2847a2f-a698-401d-82ef-d83ca5c1172f_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_263dac9f-3a2d-4fa0-8212-2734094469ee_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_35a3c340-2c20-4066-b761-292c39a25add_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_3c0896da-4b9f-48f4-885c-878d861cc6d6_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_74721279-c7c5-45aa-b21a-7fca60db7c07_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_78ab9b4f-9c1a-41f4-a040-999198276674_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_808ce38f-7501-47af-92ab-610f14bdbd08_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_b8d3ad77-5038-4ac4-8049-568f7d592a08_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_c60c3f6f-badd-43af-840e-a7ad7a725cdc_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_f87a7774-8d8d-4781-9781-fb96f1e532f5_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_21b30cc5-edf9-42b7-bcf3-f3a9eedbee4d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006498_4f305ed2-7142-4898-b059-7e37699958d2_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006498_d2847a2f-a698-401d-82ef-d83ca5c1172f">
<gen:stringAttribute name="Flaeche">
<gen:value>318.479</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_d2847a2f-a698-401d-82ef-d83ca5c1172f_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692527.553 5335078.228 511.5 692527.527 5335078.222 511.5 692527.541 5335078.164 511.5 692527.549 5335078.134 511.5 692528.03 5335076.248 511.5 692530.107 5335068.096 511.5 692529.994 5335068.095 511.5 692518.975 5335067.931 511.5 692517.265 5335075.826 511.5 692517.021 5335076.952 511.5 692516.071 5335080.757 511.5 692514.194 5335088.185 511.5 692514.165 5335088.299 511.5 692524.565 5335090.635 511.5 692525.638 5335090.876 511.5 692530.489 5335091.965 511.5 692531.054 5335092.088 511.5 692533.891 5335079.731 511.5 692527.553 5335078.228 511.5</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006498_263dac9f-3a2d-4fa0-8212-2734094469ee">
<gen:stringAttribute name="Flaeche">
<gen:value>64.630</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.321</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.821</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_263dac9f-3a2d-4fa0-8212-2734094469ee_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692514.194 5335088.185 511.5 692516.071 5335080.757 511.5 692516.071 5335080.757 519.804 692514.194 5335088.185 519.812 692514.165 5335088.299 519.821 692514.165 5335088.299 511.5 692514.194 5335088.185 511.5</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006498_35a3c340-2c20-4066-b761-292c39a25add">
<gen:stringAttribute name="Flaeche">
<gen:value>47.974</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.338</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.838</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_35a3c340-2c20-4066-b761-292c39a25add_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692527.527 5335078.222 511.5 692527.553 5335078.228 511.5 692533.891 5335079.731 511.5 692533.891 5335079.731 518.838 692527.553 5335078.228 518.832 692527.527 5335078.222 518.832 692527.527 5335078.222 511.5</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006498_3c0896da-4b9f-48f4-885c-878d861cc6d6">
<gen:stringAttribute name="Flaeche">
<gen:value>139.218</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.322</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.822</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_3c0896da-4b9f-48f4-885c-878d861cc6d6_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692514.165 5335088.299 519.821 692524.565 5335090.635 519.821 692525.638 5335090.876 519.821 692530.489 5335091.965 519.822 692530.489 5335091.965 511.5 692525.638 5335090.876 511.5 692524.565 5335090.635 511.5 692514.165 5335088.299 511.5 692514.165 5335088.299 519.821</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006498_74721279-c7c5-45aa-b21a-7fca60db7c07">
<gen:stringAttribute name="Flaeche">
<gen:value>32.561</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.304</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.804</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_74721279-c7c5-45aa-b21a-7fca60db7c07_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692517.021 5335076.952 511.5 692517.021 5335076.952 519.801 692516.071 5335080.757 519.804 692516.071 5335080.757 511.5 692517.021 5335076.952 511.5</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006498_78ab9b4f-9c1a-41f4-a040-999198276674">
<gen:stringAttribute name="Flaeche">
<gen:value>4.812</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.322</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.822</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_78ab9b4f-9c1a-41f4-a040-999198276674_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692530.489 5335091.965 511.5 692530.489 5335091.965 519.822 692531.054 5335092.088 519.821 692531.054 5335092.088 511.5 692530.489 5335091.965 511.5</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006498_808ce38f-7501-47af-92ab-610f14bdbd08">
<gen:stringAttribute name="Flaeche">
<gen:value>87.033</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.820</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_808ce38f-7501-47af-92ab-610f14bdbd08_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.994 5335068.095 511.5 692530.107 5335068.096 511.5 692530.107 5335068.096 518.815 692529.994 5335068.095 518.825 692518.975 5335067.931 519.82 692518.975 5335067.931 511.5 692529.994 5335068.095 511.5</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006498_b8d3ad77-5038-4ac4-8049-568f7d592a08">
<gen:stringAttribute name="Flaeche">
<gen:value>76.504</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.332</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.832</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_b8d3ad77-5038-4ac4-8049-568f7d592a08_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692527.541 5335078.164 518.828 692527.549 5335078.134 518.828 692528.03 5335076.248 518.825 692530.107 5335068.096 518.815 692530.107 5335068.096 511.5 692528.03 5335076.248 511.5 692527.549 5335078.134 511.5 692527.541 5335078.164 511.5 692527.527 5335078.222 511.5 692527.527 5335078.222 518.832 692527.541 5335078.164 518.828</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006498_c60c3f6f-badd-43af-840e-a7ad7a725cdc">
<gen:stringAttribute name="Flaeche">
<gen:value>76.706</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.820</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_c60c3f6f-badd-43af-840e-a7ad7a725cdc_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692517.265 5335075.826 511.5 692518.975 5335067.931 511.5 692518.975 5335067.931 519.82 692517.265 5335075.826 519.803 692517.021 5335076.952 519.801 692517.021 5335076.952 511.5 692517.265 5335075.826 511.5</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006498_f87a7774-8d8d-4781-9781-fb96f1e532f5">
<gen:stringAttribute name="Flaeche">
<gen:value>99.266</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.321</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.821</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.500</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_f87a7774-8d8d-4781-9781-fb96f1e532f5_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692531.054 5335092.088 511.5 692531.054 5335092.088 519.821 692533.891 5335079.731 518.838 692533.891 5335079.731 511.5 692531.054 5335092.088 511.5</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006498_21b30cc5-edf9-42b7-bcf3-f3a9eedbee4d">
<gen:stringAttribute name="Dachneigung">
<gen:value>85.568</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>167.328</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>153.297</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.322</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.822</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.328</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.828</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_21b30cc5-edf9-42b7-bcf3-f3a9eedbee4d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692514.194 5335088.185 519.812 692527.541 5335078.164 518.828 692527.527 5335078.222 518.832 692527.553 5335078.228 518.832 692533.891 5335079.731 518.838 692531.054 5335092.088 519.821 692530.489 5335091.965 519.822 692525.638 5335090.876 519.821 692524.565 5335090.635 519.821 692514.165 5335088.299 519.821 692514.194 5335088.185 519.812</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006498_4f305ed2-7142-4898-b059-7e37699958d2">
<gen:stringAttribute name="Dachneigung">
<gen:value>84.712</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>76.483</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>166.348</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.820</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.315</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.815</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006498_4f305ed2-7142-4898-b059-7e37699958d2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692516.071 5335080.757 519.804 692517.021 5335076.952 519.801 692517.265 5335075.826 519.803 692518.975 5335067.931 519.82 692529.994 5335068.095 518.825 692530.107 5335068.096 518.815 692528.03 5335076.248 518.825 692527.549 5335078.134 518.828 692527.541 5335078.164 518.828 692514.194 5335088.185 519.812 692516.071 5335080.757 519.804</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006500">
<creationDate>2015-09-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfnip</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>530.507</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>525.904</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_9998</bldg:function>
<bldg:roofType>3100</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">19.217</bldg:measuredHeight>
<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_3731143a-3fea-4cde-8195-b819d406d255_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_15432578-f4bc-4da9-b1e1-dbce61af737c_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_2c32de4c-5f83-452e-906e-47ed448e0ee5_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_2cb61b3b-aea7-4960-a638-49d0dccfc4a9_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_2ebaa096-865d-4701-8d76-d261104ebd28_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_37680af1-e380-44c6-b983-debc9ed6178c_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_3b6ce67e-1145-4cab-b528-2454b6a2ddef_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_4072e919-e8ad-4b81-8f4b-6474ab975b72_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_759168c3-0f3a-4326-91f6-38035c783d4a_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_81562194-5d6c-4830-a4f8-51c4cbdad9ee_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_89f3c861-b948-4edb-90e0-63e5c4d82ae2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_8cfedb38-5869-455c-9e91-091127fc118b_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_b4394034-30fe-4f12-8e34-3b5491eb8979_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_bfc431dc-0748-4afa-8f24-4bfac8bdb1bd_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_bfcc9284-44dd-4b17-9117-2591e656261f_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_ca1db32d-dbc8-4c67-a90f-78cb8456ffa2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_d87baaf0-28b7-4c5e-9b1d-b131b88ee2b7_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_d96878ec-9d84-48a6-846f-71b1af08116a_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_fa524c0b-11bc-4bdc-8d2f-c15362afa6b3_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_fc441d8f-81ba-42bf-b1f1-480acae0813b_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_2f60a651-0a35-4873-b5b0-ebe6dc622e7a_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006500_55c1f683-6077-49a5-9e5d-85921986761a_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006500_3731143a-3fea-4cde-8195-b819d406d255">
<gen:stringAttribute name="Flaeche">
<gen:value>280.610</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_3731143a-3fea-4cde-8195-b819d406d255_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692524.447 5335097.815 511.29 692524.364 5335097.53 511.29 692524.297 5335097.299 511.29 692523.882 5335096.913 511.29 692523.42 5335096.705 511.29 692522.842 5335096.662 511.29 692522.257 5335096.78 511.29 692522.043 5335096.968 511.29 692521.832 5335097.154 511.29 692512.532 5335094.771 511.29 692511.093 5335100.641 511.29 692510.92 5335101.331 511.29 692510.879 5335101.493 511.29 692509.3 5335107.878 511.29 692526.629 5335112.142 511.29 692529.199 5335112.693 511.29 692529.467 5335112.763 511.29 692530.947 5335106.886 511.29 692531.1 5335106.291 511.29 692531.117 5335106.224 511.29 692532.254 5335101.612 511.29 692532.647 5335101.538 511.29 692533.037 5335100.012 511.29 692524.447 5335097.815 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_15432578-f4bc-4da9-b1e1-dbce61af737c">
<gen:stringAttribute name="Flaeche">
<gen:value>8.057</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.132</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.422</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_15432578-f4bc-4da9-b1e1-dbce61af737c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692524.364 5335097.53 526.263 692524.297 5335097.299 526.134 692524.297 5335097.299 511.29 692524.364 5335097.53 511.29 692524.447 5335097.815 511.29 692524.447 5335097.815 526.422 692524.364 5335097.53 526.263</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_2c32de4c-5f83-452e-906e-47ed448e0ee5">
<gen:stringAttribute name="Flaeche">
<gen:value>8.801</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.828</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.119</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_2c32de4c-5f83-452e-906e-47ed448e0ee5_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692522.842 5335096.662 511.29 692522.842 5335096.662 525.963 692522.257 5335096.78 526.119 692522.257 5335096.78 511.29 692522.842 5335096.662 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_2cb61b3b-aea7-4960-a638-49d0dccfc4a9">
<gen:stringAttribute name="Flaeche">
<gen:value>102.160</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.777</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.067</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_2cb61b3b-aea7-4960-a638-49d0dccfc4a9_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692512.532 5335094.771 511.29 692512.532 5335094.771 526.328 692511.093 5335100.641 530.067 692511.093 5335100.641 511.29 692512.532 5335094.771 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_2ebaa096-865d-4701-8d76-d261104ebd28">
<gen:stringAttribute name="Flaeche">
<gen:value>6.495</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.278</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.568</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_2ebaa096-865d-4701-8d76-d261104ebd28_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692532.254 5335101.612 511.29 692532.254 5335101.612 527.568 692532.647 5335101.538 527.466 692532.647 5335101.538 511.29 692532.254 5335101.612 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_37680af1-e380-44c6-b983-debc9ed6178c">
<gen:stringAttribute name="Flaeche">
<gen:value>24.708</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>16.176</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>527.466</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_37680af1-e380-44c6-b983-debc9ed6178c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692532.647 5335101.538 511.29 692532.647 5335101.538 527.466 692533.037 5335100.012 526.491 692533.037 5335100.012 511.29 692532.647 5335101.538 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_3b6ce67e-1145-4cab-b528-2454b6a2ddef">
<gen:stringAttribute name="Flaeche">
<gen:value>134.487</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.201</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.491</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_3b6ce67e-1145-4cab-b528-2454b6a2ddef_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692533.037 5335100.012 511.29 692533.037 5335100.012 526.491 692524.447 5335097.815 526.422 692524.447 5335097.815 511.29 692533.037 5335100.012 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_4072e919-e8ad-4b81-8f4b-6474ab975b72">
<gen:stringAttribute name="Flaeche">
<gen:value>85.619</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.507</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_4072e919-e8ad-4b81-8f4b-6474ab975b72_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692532.254 5335101.612 527.568 692532.254 5335101.612 511.29 692531.117 5335106.224 511.29 692531.1 5335106.291 511.29 692531.1 5335106.291 530.464 692531.117 5335106.224 530.507 692532.254 5335101.612 527.568</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_759168c3-0f3a-4326-91f6-38035c783d4a">
<gen:stringAttribute name="Flaeche">
<gen:value>268.241</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.044</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.334</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_759168c3-0f3a-4326-91f6-38035c783d4a_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692509.3 5335107.878 511.29 692509.3 5335107.878 526.334 692526.629 5335112.142 526.294 692526.629 5335112.142 511.29 692509.3 5335107.878 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_81562194-5d6c-4830-a4f8-51c4cbdad9ee">
<gen:stringAttribute name="Flaeche">
<gen:value>16.719</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.507</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_81562194-5d6c-4830-a4f8-51c4cbdad9ee_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692510.92 5335101.331 511.29 692511.093 5335100.641 511.29 692511.093 5335100.641 530.067 692510.92 5335101.331 530.507 692510.879 5335101.493 530.403 692510.879 5335101.493 511.29 692510.92 5335101.331 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_89f3c861-b948-4edb-90e0-63e5c4d82ae2">
<gen:stringAttribute name="Flaeche">
<gen:value>8.472</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.115</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.405</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_89f3c861-b948-4edb-90e0-63e5c4d82ae2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692522.043 5335096.968 511.29 692522.257 5335096.78 511.29 692522.257 5335096.78 526.119 692522.043 5335096.968 526.263 692521.832 5335097.154 526.405 692521.832 5335097.154 511.29 692522.043 5335096.968 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_8cfedb38-5869-455c-9e91-091127fc118b">
<gen:stringAttribute name="Flaeche">
<gen:value>4.161</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.047</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.337</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_8cfedb38-5869-455c-9e91-091127fc118b_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.199 5335112.693 511.29 692529.199 5335112.693 526.337 692529.467 5335112.763 526.334 692529.467 5335112.763 511.29 692529.199 5335112.693 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_b4394034-30fe-4f12-8e34-3b5491eb8979">
<gen:stringAttribute name="Flaeche">
<gen:value>112.306</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.113</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.403</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_b4394034-30fe-4f12-8e34-3b5491eb8979_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692510.879 5335101.493 511.29 692510.879 5335101.493 530.403 692509.3 5335107.878 526.334 692509.3 5335107.878 511.29 692510.879 5335101.493 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_bfc431dc-0748-4afa-8f24-4bfac8bdb1bd">
<gen:stringAttribute name="Flaeche">
<gen:value>39.499</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.047</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.337</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_bfc431dc-0748-4afa-8f24-4bfac8bdb1bd_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692526.629 5335112.142 511.29 692526.629 5335112.142 526.294 692529.199 5335112.693 526.337 692529.199 5335112.693 511.29 692526.629 5335112.142 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_bfcc9284-44dd-4b17-9117-2591e656261f">
<gen:stringAttribute name="Flaeche">
<gen:value>8.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.673</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.963</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_bfcc9284-44dd-4b17-9117-2591e656261f_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692523.42 5335096.705 511.29 692523.42 5335096.705 525.904 692522.842 5335096.662 525.963 692522.842 5335096.662 511.29 692523.42 5335096.705 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_ca1db32d-dbc8-4c67-a90f-78cb8456ffa2">
<gen:stringAttribute name="Flaeche">
<gen:value>8.372</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.844</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.134</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_ca1db32d-dbc8-4c67-a90f-78cb8456ffa2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692524.297 5335097.299 511.29 692524.297 5335097.299 526.134 692523.882 5335096.913 525.962 692523.882 5335096.913 511.29 692524.297 5335097.299 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_d87baaf0-28b7-4c5e-9b1d-b131b88ee2b7">
<gen:stringAttribute name="Flaeche">
<gen:value>7.423</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.672</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>525.962</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_d87baaf0-28b7-4c5e-9b1d-b131b88ee2b7_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692523.882 5335096.913 511.29 692523.882 5335096.913 525.962 692523.42 5335096.705 525.904 692523.42 5335096.705 511.29 692523.882 5335096.913 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_d96878ec-9d84-48a6-846f-71b1af08116a">
<gen:stringAttribute name="Flaeche">
<gen:value>11.655</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.174</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.464</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_d96878ec-9d84-48a6-846f-71b1af08116a_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692530.947 5335106.886 511.29 692530.947 5335106.886 530.084 692531.1 5335106.291 530.464 692531.1 5335106.291 511.29 692530.947 5335106.886 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_fa524c0b-11bc-4bdc-8d2f-c15362afa6b3">
<gen:stringAttribute name="Flaeche">
<gen:value>144.806</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>15.115</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.405</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_fa524c0b-11bc-4bdc-8d2f-c15362afa6b3_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692521.832 5335097.154 511.29 692521.832 5335097.154 526.405 692512.532 5335094.771 526.328 692512.532 5335094.771 511.29 692521.832 5335097.154 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006500_fc441d8f-81ba-42bf-b1f1-480acae0813b">
<gen:stringAttribute name="Flaeche">
<gen:value>102.534</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.794</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.084</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.290</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_fc441d8f-81ba-42bf-b1f1-480acae0813b_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692529.467 5335112.763 511.29 692529.467 5335112.763 526.334 692530.947 5335106.886 530.084 692530.947 5335106.886 511.29 692529.467 5335112.763 511.29</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006500_2f60a651-0a35-4873-b5b0-ebe6dc622e7a">
<gen:stringAttribute name="Dachneigung">
<gen:value>58.248</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>348.609</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>165.507</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.507</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>15.003</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.294</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_2f60a651-0a35-4873-b5b0-ebe6dc622e7a_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692510.879 5335101.493 530.403 692510.92 5335101.331 530.507 692531.117 5335106.224 530.507 692531.1 5335106.291 530.464 692530.947 5335106.886 530.084 692529.467 5335112.763 526.334 692529.199 5335112.693 526.337 692526.629 5335112.142 526.294 692509.3 5335107.878 526.334 692510.879 5335101.493 530.403</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006500_55c1f683-6077-49a5-9e5d-85921986761a">
<gen:stringAttribute name="Dachneigung">
<gen:value>58.248</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>168.609</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>164.491</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.217</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.507</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.614</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>525.904</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006500_55c1f683-6077-49a5-9e5d-85921986761a_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692511.093 5335100.641 530.067 692512.532 5335094.771 526.328 692521.832 5335097.154 526.405 692522.043 5335096.968 526.263 692522.257 5335096.78 526.119 692522.842 5335096.662 525.963 692523.42 5335096.705 525.904 692523.882 5335096.913 525.962 692524.297 5335097.299 526.134 692524.364 5335097.53 526.263 692524.447 5335097.815 526.422 692533.037 5335100.012 526.491 692532.647 5335101.538 527.466 692532.254 5335101.612 527.568 692531.117 5335106.224 530.507 692510.92 5335101.331 530.507 692511.093 5335100.641 530.067</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>St.-Anna-Platz 3</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006508">
<gml:name>St. Anna (Pfarrkirche)</gml:name>
<creationDate>2026-05-26</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfolR</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>548.950</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.462</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>515.863</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_3041</bldg:function>
<bldg:roofType>3100</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">37.488</bldg:measuredHeight>
<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_efa9f1eb-f56f-44fb-b27b-80ad5c12656e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_00283e8f-2cbd-41b1-bef3-eacc14ca790d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_0096158a-6be2-499c-8b02-ce132296efd4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_00ea6371-78c8-4ac1-80f2-202d2f24e98f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_01633891-3d20-430b-b435-df44daec3159_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_018de9de-ef56-40d7-bb8b-e495914bc54d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_04e76bdc-1378-4dd6-ac41-39fe80fe634a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_05760ab0-3e16-4002-bea3-e3fb4eb16155_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_05a44e33-5472-4a29-8199-fece660839c4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_0793b4ca-8466-4896-bec0-cea5c1e32f07_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_082d8e0d-f9f0-4cbf-8492-7e513d7ab506_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_11694623-d2c9-4d45-9c0e-66cef78e989e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_11e70205-6c35-4bf7-a8dc-e872c115be30_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_122abb77-f498-4c24-be53-11af710fbf0b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_12f4745e-28e4-4df9-bdc8-f57d02869323_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_13d6f20c-0348-4af9-baeb-43cb4cd12e54_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_1462fed7-08ff-40c4-b5a6-9a65f43cd5c7_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_1a83bec3-a9e6-497a-9e29-1dc32bb3f903_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_1c0819f5-8f1a-435c-9acb-d42d8d3ba3ba_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_1c14ff04-82da-42c5-a129-a29e920cc79c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_1cf9b786-d59e-4a00-a463-52f350f94110_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_1d159179-cb84-4258-a9b7-ef4d49f1f359_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_1f7c0fa7-836c-413c-a3bb-53ccf930e1d2_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_1fe41424-ceb3-4ae4-89f3-a2b5829fff77_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_2100aaf4-7dd8-4a7b-8dd9-b67aeb5c2979_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_220d63ab-11d9-4895-bf3f-f10d2735d90d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_26a9c7d8-549d-47f9-9823-42f2d9db0287_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_2b364a14-8d05-48b8-b38c-2d598c0e91a4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_2b41926d-c9e2-46c3-a16b-b7b3f9af3c65_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_2b80d4d5-660a-4111-9a98-fef0d9b5b65f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_2ea85659-ffc6-45f7-bc1d-4acd9710aabe_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_3225efbd-a217-4f35-b924-775193317c49_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_327b2842-9230-4802-aa9b-1277a8f3bb35_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_36b4287e-4224-4ae1-9482-7952bc6da8bc_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_370af134-4b4c-4243-9d9b-47cceac8f5ec_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_3712c236-718e-4713-96b8-ae54867c2eb0_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_3a719bfb-866c-4e9d-9c25-0269c968b9a2_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_3bcc7ef1-2d83-48b3-a5cd-45632ca77efe_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_3ef0be63-3181-466e-9423-97d87ddd8194_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_419e743c-c219-4a62-b789-b5d5b516e8cc_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_44fa8848-5e88-4e2f-8cdd-5c16b59f66f2_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_45326f16-6b63-41ad-85df-98c2066f8a0c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_46efeddb-3c7c-4ed4-9108-d70ab9c8668c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_485e96cb-3add-4f82-8efb-242964368350_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_48899b99-cb4a-4b21-b8e1-0328a41b2427_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_49b807b5-0e46-45e3-a2a7-b945159154e3_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_4f1ed6d1-f241-4134-a611-6b03b45969d5_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_4ff2db9b-9a2d-4a24-b10f-8a366a6248c9_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_50bc729a-6a36-4bea-8ebd-f0533fa84ea4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_54befabf-bc4e-4434-baf4-5fbe24c34afd_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_54d65c82-d0cd-4923-b35f-8eb0a7988a22_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_55bc9188-225c-4c4d-b3b3-10722e31ec3c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_57bfed54-78bc-42f2-8edb-8344870e72cd_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_594c5a33-d28f-4389-bc1b-3cbe38af64bc_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_5b471bb6-74fc-48d3-83fd-a1e16bd977f2_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_5d87d100-a21f-42ef-b916-04036536d088_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_5f21e4e7-8a62-4d3c-ae3c-6cb0ea2244c9_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_6006558f-31e6-43b0-9a93-b56d2433654d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_61c46311-1a99-43f7-ba01-0db341abe45c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_6685c0a6-b56a-4c2d-9d88-a2d1f0bce083_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_6a0e37aa-ab59-4111-beae-db77c8ac301c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_6c08a0e2-3899-4f62-98c7-a10b8c58c428_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_6cda9d25-84da-4f50-b9b3-4d88cab1e1e5_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_7183b68d-526b-493d-966e-150d754a06c3_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_71c07642-44df-486a-8b47-3d7889fa258f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_72fd0baf-e7e6-4b80-8401-e52f4cdb23b5_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_7397367d-21e0-439b-96cb-4514b531a386_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_7471c36e-9889-43c4-84cd-622f460e2521_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_7eeda2e4-f70d-45b1-9a85-7115b945db54_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_7ef4e683-6246-4e18-882b-98d129a8f90f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_82425164-36b1-4cba-9f2e-c9b6097f1318_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_828c3427-3f68-476b-a7eb-cabda0d71698_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_84faeda3-299c-4bbe-a344-fa0c1b19ada1_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_89d5452c-edd6-463c-b02f-f171abd1fd9a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_8b23a162-2652-4c52-9daf-f71757252869_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_8b3b9a3a-bdb5-462d-9c5d-f0d6dfee5411_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_8e1cd80d-e1d6-42fb-9d06-18b58dfe76fb_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_8f067821-8f3e-40fd-93d6-7c4879c522f7_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_95d280e1-ac64-451e-9c2a-4e1306e49e8b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_9608e903-1cd0-4685-b980-c502dca56f3a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_967b25f1-198b-4b02-94fa-12b62d1ac36e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_970ace7c-a366-4bb9-852c-f19982b4e764_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_989be770-853b-49cb-a5a6-4d5644676ab2_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_9da27cab-b31a-43ba-b311-acf03b3fe644_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_a0118ed4-8371-4836-8d95-44444dc8d4f5_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_a1d5ba4c-04e7-42be-987b-2cf301042cc9_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_a546f6b4-57f1-4176-affd-c6d3e0219440_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_a559d80b-b13c-46a7-a4e9-10ba38d78660_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_a592b224-c32a-4cbe-b434-22038b82d531_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_a5cb4bfb-ff8b-4c03-893a-1b2ea62b2532_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_ab87c2dc-0881-4130-8bf3-fff6343e9473_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_ad53be12-fb0a-4163-ab71-dd6a8b98ef0f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_b07db88b-067b-43c4-925d-99583d76bc4c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_b34af73f-da19-4908-b58a-1f660eb7161a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_b36973f7-9b0d-448a-b2d9-ca3f74d808ff_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_b5e252d5-ec7c-4806-9784-b9835f30ebfe_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_b7211cd7-3bb7-429f-8628-4b3dd1237f95_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_b72c1644-f626-41f8-833c-5495d82cbde5_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_b8b923d8-a1e9-40a0-a485-5eb31dbbb166_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_bccbfacb-fcc3-4e5c-aa5e-936cb781659e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_bd38e6b4-a45d-4c2a-bc05-445cafae3df9_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_c0f68b81-a171-489b-80c9-ee897c2d8008_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_c0f7ae63-f149-47e3-bfee-247cb5a449b4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_c2b370d5-ae17-44be-a620-a19b88ca5577_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_c2e9003a-5140-4bec-aa0c-aea9b1fbf9b9_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_c622f18f-e139-4725-961a-c505689b5d5a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_c7101198-8ab7-410a-8fee-16f92f071c11_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_c745da01-8c6c-4280-a89c-3918b2ff188d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_cb389c11-da5c-449a-aa5c-3af3e1f3675b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_cb89fb05-48b6-45b7-9398-7b00b43e0414_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_cbb1d83f-5daf-4f89-a083-b0abad57ae1c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_cc860c65-f4b7-4bbb-8375-d55de82630c5_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_cd33858e-61e5-40af-818b-1b2c2da0377e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_d3c48867-28bc-4d75-bed1-5e860853a073_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_da899b95-e40d-453f-8f49-120273554631_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_dca2ca21-61c2-4211-9b8a-e407baac9d70_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_dd3fce78-f55f-4bad-aa97-9805ee17ce2d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_dd714693-63eb-4a1f-9169-ceb73e7decea_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_df9841b6-6314-455a-b6b7-7cc64907e098_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_dfb526a6-7272-4100-a82f-c41efc3ddc3a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_dff65b12-5484-4371-b5d8-896960f71c53_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_e149b81b-f97a-4aa7-96b1-b73709bf1916_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_e2e9aaff-a0a5-454e-a312-72d4a7fb3077_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_e4a490ca-44b1-4204-bf08-ae4bfb5b298e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_e6fcd242-aa01-4190-a532-35717d6c9aac_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_e8e4ed0a-afe8-4bff-9cd6-b2623fd85ade_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_ed16a6e7-1032-49e3-b656-7e31b54d0b4b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_eeea9620-c987-412a-8960-06d625d125e1_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_ef460dd0-d8d0-4254-b00d-47d8c9620348_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_f08dcb06-4f10-461c-ac9e-4f2224412e47_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_f1b19d23-04db-4e56-b5c3-0262c9a05747_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_f1cb0770-1382-4617-b484-0a799a4b5279_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_f3b2f5ae-ee3f-4234-8bba-7c77d58c1b02_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_f5f242db-e2c1-43c7-9084-d33cff426efc_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_fae36168-ac2d-4528-a9aa-f2047ea5852e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_040e8515-e095-4ca3-9db2-5f437e0c198a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_07cef253-ef32-46cf-be90-14606da8515a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_0859f3f6-c871-4329-8235-bcc8298db3dd_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_0a30c205-4f46-442e-aabb-33df51653461_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_0e93a3b9-ab67-46c4-aabf-0b58b1ee5c36_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_16b2535d-9ad7-4436-9055-652a84423c14_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_17e9e09e-2dca-49e9-ae17-a19a16d8d8c7_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_182a36d9-3382-4eb7-a868-995db368666c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_1b66eaa5-e3c1-4e5c-95fd-864debcb3007_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_1d15e50d-bf78-4227-94f6-c31ecba923df_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_1fe8f35f-12f2-4426-a818-0887153eeed6_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_222e12dd-dc30-4c71-bbc0-01d2a05fccff_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_263d2faa-ec15-4957-b3bc-2c48dcf47f17_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_275e544a-af76-4e40-a3f0-bb07bd0d7511_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_27741fdb-82b8-4e1e-ba87-3f7df4345b0b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_2eeb2550-2eee-4132-a7e6-fd03a9e2378b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_2f81174c-3fb0-4abc-ba8d-86b7cc2ed522_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_2fc33383-ce57-4e53-8190-b743dcde2618_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_3673c990-b43b-4ab6-8915-cdc336b3d0b0_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_3691a00f-a8cf-44a2-97e9-bc25c216c434_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_381396e1-aef9-4025-b544-9396410c46f7_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_38ed53ea-20ea-470b-9ac3-3be3d3942e4a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_3fbb2a54-e358-448e-a1bb-424004c9c34c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_40fa304e-0463-4ea1-82d8-c6e17e4d8bd8_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_42b69ebe-20c9-49b3-a82c-903aad2924c9_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_439a507a-1469-40d8-8cd5-76efb9839c8a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_44d61b0a-3dca-4655-9aec-aa0f50cf827a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_47950fef-80b7-4626-9e97-4313bdc18a3e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_498f742d-9720-4e8e-8122-a787e14346d4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_4ca207e3-4491-4a24-a911-7817c34e0eb9_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_4f5f9f51-604b-47d5-b1fa-ae6df9928244_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_52ccc7ce-0f28-4ab7-82d1-5ced6ad212b5_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_539ce256-6fbe-4fc1-ad49-29c279176760_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_54407ccc-ceff-430a-9feb-7ff0c3f08242_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_560d6b42-1597-402d-8601-2bdcab7922f8_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_575f6d4e-a4b5-4aa6-8e68-767bbf4c670d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_5859e9ef-adcb-4b34-a673-c1092e9c9314_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_58ffb4a7-5f01-4fcc-b7db-2c0ce3f5c60a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_5a361215-2458-4995-873a-db48ee36fc3e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_625a8257-b160-4150-bbbb-a651d7e302cf_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_68c077dc-3164-4cfb-918e-968900651d71_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_73033c50-b087-4273-bb96-4737d27b7b71_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_73d5596d-c108-4b1c-86c6-9c23b3e2e023_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_73f8cfd6-8518-4c50-b7d3-dc479045d3be_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_757ddf5a-5387-421d-bde1-f3691306522b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_773bc449-71a1-4666-985d-d1c4c6946958_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_78a90eca-c767-483c-b188-20d08dbc492e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_7a5d0f89-9eae-464a-aa55-81f807537daa_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_7ae50019-e5df-415b-b2e7-4254a0c4dac0_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_7bdef18a-bfa9-4310-bbcd-3311233ea431_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_7cea64e6-e39d-4bd7-b8c2-86f802cab4dd_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_7d06fc10-ee8f-4f94-bb58-9e5e782f4389_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_7fc5558c-76cd-4b38-8185-d8ef819928f8_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_819ab0c5-5956-41ea-bfe5-71f99211a9ad_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_840239f8-afbe-4f5e-af33-0eeb71157811_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_844c62d1-3c7d-490b-8510-60981f698b48_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_86660993-e307-4ef9-8b69-0dd312934e0a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_89630b02-160d-4fb3-92d8-68114d37ba2f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_8ca620fa-d418-42d1-b99e-d9e5fe188531_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_90f836b7-238a-46a7-b478-8f18d891b3b5_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_9506147c-32f6-42c2-924b-9fcc69740faa_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_9ada6dc3-f320-4c8b-b622-a1b7a5d20db6_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_9c817bf5-6bbd-4eeb-9fce-3cff8542902f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_9e678d6f-da3b-48c7-8505-414ff2609543_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_a5fa3d38-0834-42b6-93d1-0fcd5b342033_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_ab966bc8-480e-425c-80f6-1e5517b9ee7f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_ac6fcea9-c430-43c4-86bd-707e682a269d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_ad7b11ec-b70c-4c25-8b60-ee201e5cb893_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_b21a7223-2999-4e06-88bf-bebc4da7b2f1_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_b4116bb2-b4fe-486a-9c40-60bd6458186f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_b447bf90-1b2d-43cd-95b2-72d85ad4a15f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_b4c13952-c37e-4288-83fe-652a2ecd7cee_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_ba3c503e-15a4-4073-9072-b7dc0e500af3_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_bb0420e2-971a-428f-9eb3-979e6089bdfd_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_bc23953d-86c0-4302-ad32-d10b7489bc51_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_bdae1ae2-cb3e-478d-98ae-e31d5b953f38_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_c41411a4-3eb6-44a9-8751-3af37f196121_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_c7733056-c3c5-4336-9d6e-ff4791626ac5_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_c8e7a891-7a09-4645-b432-c9faf8946af4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_ce3caa41-1dd1-4788-9fa7-199fc326373d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_daa3a916-e599-4255-93a6-030686eedfc0_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_db3fb65f-6246-42b8-8204-8c9602ee9c0e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_db828987-0df4-44fd-b9f9-9344d7b1e107_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_e075b1a1-37dd-44e4-bf04-a652decaad90_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_e075dbdf-2351-41be-b448-4ffbe6df9af8_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_e8b50866-0f53-48b0-8bf2-67f6e16dfcfd_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_ecc3ff64-ead3-42b1-80c4-2c9afacc8d4b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_f09df779-6084-44df-9521-96c397eaaba2_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_f1222130-c1ba-47bb-a965-1a3a61c61665_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_f3b5c47d-25e9-4d90-9485-ca2628de2ade_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_f4fe5448-f446-4099-9a1d-3f7ea63b38f7_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_fbef0479-4636-4676-8335-036fd878902f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006508_fd50813b-953f-4b9c-9c47-81f7e5df788a_2_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006508_efa9f1eb-f56f-44fb-b27b-80ad5c12656e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>1444.342</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_efa9f1eb-f56f-44fb-b27b-80ad5c12656e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692512.24 5335140.94 511.46 692511.27 5335138.39 511.46 692509.88 5335136.38 511.46 692508.53 5335135.23 511.46 692510.26 5335133.65 511.46 692510.93 5335130.65 511.46 692507.08 5335128.4 511.46 692506.71 5335128.33 511.46 692504.58 5335130.65 511.46 692503.39 5335130.3 511.46 692503.49 5335129.05 511.46 692502.86 5335128.15 511.46 692502.65 5335128.1 511.46 692502.75 5335127.52 511.46 692501.78 5335127.24 511.46 692500.67 5335126.92 511.46 692500.57 5335127.35 511.46 692500.05 5335127.17 511.46 692499.66 5335127.03 511.46 692499.43 5335128.05 511.46 692498.57 5335127.88 511.46 692497.77 5335125.84 511.46 692496.93 5335125.08 511.46 692495.51 5335124.67 511.46 692495.09 5335124.55 511.46 692493.83 5335124.74 511.46 692492.88 5335125.17 511.46 692491.82 5335126.1 511.46 692490.88 5335125.92 511.46 692491 5335124.98 511.46 692489.46 5335124.63 511.46 692489.28 5335125.48 511.46 692488.59 5335125.35 511.46 692488.32 5335126.66 511.46 692488.97 5335126.8 511.46 692488.37 5335129.04 511.46 692471.23 5335124.84 511.46 692466.77 5335123.75 511.46 692457.6 5335121.49 511.46 692456.37 5335126.8 511.46 692455 5335132.71 511.46 692453.81 5335137.85 511.46 692453.74 5335138.17 511.46 692452.47 5335143.63 511.46 692461.76 5335145.92 511.46 692466.59 5335147.12 511.46 692483.05 5335151.15 511.46 692482.56 5335153.23 511.46 692481.95 5335153.12 511.46 692481.69 5335154.19 511.46 692482.29 5335154.43 511.46 692482.13 5335155.27 511.46 692483.64 5335155.63 511.46 692483.94 5335154.76 511.46 692484.45 5335154.92 511.46 692484.54 5335155.64 511.46 692484.77 5335156.36 511.46 692485.14 5335157 511.46 692485.62 5335157.56 511.46 692486.31 5335158.08 511.46 692487 5335158.39 511.46 692487.25 5335158.45 511.46 692487.75 5335158.56 511.46 692488.92 5335158.58 511.46 692490.43 5335157.8 511.46 692491.5 5335156.54 511.46 692492.16 5335156.77 511.46 692491.97 5335157.78 511.46 692493.28 5335158.06 511.46 692493.58 5335157.26 511.46 692494.54 5335157.4 511.46 692494.71 5335156.76 511.46 692495.55 5335156.75 511.46 692496.42 5335156.45 511.46 692497.29 5335155.89 511.46 692497.96 5335155.02 511.46 692498.34 5335154.17 511.46 692499.42 5335154.35 511.46 692500.95 5335154.5 511.46 692502.49 5335154.51 511.46 692504.16 5335154.28 511.46 692505.54 5335153.86 511.46 692506.73 5335153.4 511.46 692507.77 5335152.79 511.46 692508.75 5335151.99 511.46 692509.61 5335151.08 511.46 692510.52 5335149.83 511.46 692511.15 5335148.8 511.46 692511.84 5335147.33 511.46 692512.2 5335146.13 511.46 692512.54 5335143.91 511.46 692512.24 5335140.94 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_00283e8f-2cbd-41b1-bef3-eacc14ca790d_2">
<gen:stringAttribute name="Flaeche">
<gen:value>3.313</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.120</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.582</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_00283e8f-2cbd-41b1-bef3-eacc14ca790d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692502.75 5335127.52 511.46 692502.65 5335128.1 511.46 692502.65 5335128.1 532.582 692502.656 5335128.065 532.53 692502.656 5335128.065 516.35 692502.75 5335127.52 515.863 692502.75 5335127.52 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_0096158a-6be2-499c-8b02-ce132296efd4_2">
<gen:stringAttribute name="Flaeche">
<gen:value>4.365</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_0096158a-6be2-499c-8b02-ce132296efd4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.54 5335145.131 526.21 692507.54 5335145.131 529.96 692507.721 5335143.981 529.96 692507.721 5335143.981 526.21 692507.54 5335145.131 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_00ea6371-78c8-4ac1-80f2-202d2f24e98f_2">
<gen:stringAttribute name="Flaeche">
<gen:value>3.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_00ea6371-78c8-4ac1-80f2-202d2f24e98f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.305 5335146.154 526.21 692507.305 5335146.154 529.96 692507.54 5335145.131 529.96 692507.54 5335145.131 526.21 692507.305 5335146.154 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_01633891-3d20-430b-b435-df44daec3159_2">
<gen:stringAttribute name="Flaeche">
<gen:value>4.689</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.737</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.200</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_01633891-3d20-430b-b435-df44daec3159_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692495.09 5335124.55 511.46 692495.51 5335124.67 511.46 692495.51 5335124.67 522.2 692495.186 5335124.577 522.2 692495.09 5335124.55 522.16 692495.09 5335124.55 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_018de9de-ef56-40d7-bb8b-e495914bc54d_2">
<gen:stringAttribute name="Flaeche">
<gen:value>14.255</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.284</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.747</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_018de9de-ef56-40d7-bb8b-e495914bc54d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.77 5335152.79 511.46 692507.77 5335152.79 522.747 692508.75 5335151.99 522.709 692508.75 5335151.99 511.46 692507.77 5335152.79 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_04e76bdc-1378-4dd6-ac41-39fe80fe634a_2">
<gen:stringAttribute name="Flaeche">
<gen:value>6.603</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_04e76bdc-1378-4dd6-ac41-39fe80fe634a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692505.325 5335148.602 526.21 692505.325 5335148.602 529.96 692506.643 5335147.434 529.96 692506.643 5335147.434 526.21 692505.325 5335148.602 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_05760ab0-3e16-4002-bea3-e3fb4eb16155_2">
<gen:stringAttribute name="Flaeche">
<gen:value>16.660</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.568</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.031</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_05760ab0-3e16-4002-bea3-e3fb4eb16155_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692491 5335124.98 511.46 692491 5335124.98 521.987 692489.46 5335124.63 522.031 692489.46 5335124.63 511.46 692491 5335124.98 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_05a44e33-5472-4a29-8199-fece660839c4_2">
<gen:stringAttribute name="Flaeche">
<gen:value>42.040</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.968</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.430</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.582</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.045</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_05a44e33-5472-4a29-8199-fece660839c4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692484.275 5335145.399 524.51 692484.275 5335145.399 530.43 692482.961 5335151.128 530.43 692482.961 5335151.128 522.045 692484.275 5335145.399 524.51</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_0793b4ca-8466-4896-bec0-cea5c1e32f07_2">
<gen:stringAttribute name="Flaeche">
<gen:value>9.131</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.158</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.620</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>9.318</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>520.780</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_0793b4ca-8466-4896-bec0-cea5c1e32f07_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692505.489 5335133.128 522.62 692499.524 5335131.667 522.62 692499.524 5335131.667 521.91 692501.389 5335132.124 521.91 692501.389 5335132.124 520.78 692505.489 5335133.128 520.78 692505.489 5335133.128 522.62</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_082d8e0d-f9f0-4cbf-8492-7e513d7ab506_2">
<gen:stringAttribute name="Flaeche">
<gen:value>3.287</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>530.950</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_082d8e0d-f9f0-4cbf-8492-7e513d7ab506_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692500.336 5335128.127 530.95 692500.336 5335128.127 532.53 692499.871 5335130.155 532.53 692499.871 5335130.155 530.95 692500.336 5335128.127 530.95</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_11694623-d2c9-4d45-9c0e-66cef78e989e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>11.642</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>20.653</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.116</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_11694623-d2c9-4d45-9c0e-66cef78e989e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692491 5335124.98 511.46 692490.88 5335125.92 511.46 692490.88 5335125.92 532.116 692490.894 5335125.813 532.106 692490.894 5335125.813 523.36 692491 5335124.98 521.987 692491 5335124.98 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_11e70205-6c35-4bf7-a8dc-e872c115be30_2">
<gen:stringAttribute name="Flaeche">
<gen:value>17.351</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.320</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.782</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_11e70205-6c35-4bf7-a8dc-e872c115be30_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692500.95 5335154.5 511.46 692499.42 5335154.35 511.46 692499.42 5335154.35 522.721 692500.04 5335154.411 522.782 692500.95 5335154.5 522.704 692500.95 5335154.5 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_122abb77-f498-4c24-be53-11af710fbf0b_2">
<gen:stringAttribute name="Flaeche">
<gen:value>13.795</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.454</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_122abb77-f498-4c24-be53-11af710fbf0b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692510.52 5335149.83 511.46 692510.52 5335149.83 522.916 692511.15 5335148.8 522.854 692511.15 5335148.8 511.46 692510.52 5335149.83 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_12f4745e-28e4-4df9-bdc8-f57d02869323_2">
<gen:stringAttribute name="Flaeche">
<gen:value>65.987</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.945</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.407</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_12f4745e-28e4-4df9-bdc8-f57d02869323_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692453.74 5335138.17 511.46 692453.74 5335138.17 524.407 692452.47 5335143.63 522.056 692452.47 5335143.63 511.46 692453.74 5335138.17 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_13d6f20c-0348-4af9-baeb-43cb4cd12e54_2">
<gen:stringAttribute name="Flaeche">
<gen:value>13.137</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>20.643</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.106</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_13d6f20c-0348-4af9-baeb-43cb4cd12e54_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692490.894 5335125.813 523.36 692490.894 5335125.813 532.106 692489.293 5335125.421 530.553 692489.293 5335125.421 523.36 692490.894 5335125.813 523.36</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_1462fed7-08ff-40c4-b5a6-9a65f43cd5c7_2">
<gen:stringAttribute name="Flaeche">
<gen:value>12.342</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.158</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.620</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.126</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.588</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_1462fed7-08ff-40c4-b5a6-9a65f43cd5c7_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692494.556 5335153.31 520.27 692494.556 5335153.31 522.62 692498.313 5335154.231 522.62 692498.313 5335154.231 518.588 692494.556 5335153.31 520.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_1a83bec3-a9e6-497a-9e29-1dc32bb3f903_2">
<gen:stringAttribute name="Flaeche">
<gen:value>15.266</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>4.910</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>516.373</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_1a83bec3-a9e6-497a-9e29-1dc32bb3f903_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692502.157 5335127.943 516.373 692502.157 5335127.943 532.53 692501.208 5335127.886 532.53 692501.208 5335127.886 516.564 692502.157 5335127.943 516.373</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_1c0819f5-8f1a-435c-9acb-d42d8d3ba3ba_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.011</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_1c0819f5-8f1a-435c-9acb-d42d8d3ba3ba_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.23 5335140.778 526.21 692507.23 5335140.778 529.96 692506.03 5335139.344 529.96 692506.03 5335139.344 526.21 692507.23 5335140.778 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_1c14ff04-82da-42c5-a129-a29e920cc79c_2">
<gen:stringAttribute name="Flaeche">
<gen:value>8.313</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>4.888</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>516.350</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_1c14ff04-82da-42c5-a129-a29e920cc79c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692502.656 5335128.065 516.35 692502.656 5335128.065 532.53 692502.157 5335127.943 532.53 692502.157 5335127.943 516.373 692502.656 5335128.065 516.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_1cf9b786-d59e-4a00-a463-52f350f94110_2">
<gen:stringAttribute name="Flaeche">
<gen:value>26.505</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.181</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.644</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_1cf9b786-d59e-4a00-a463-52f350f94110_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692503.49 5335129.05 511.46 692503.39 5335130.3 511.46 692503.39 5335130.3 518.985 692503.39 5335130.3 532.543 692503.404 5335130.119 532.644 692503.49 5335129.05 532.551 692503.49 5335129.05 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_1d159179-cb84-4258-a9b7-ef4d49f1f359_2">
<gen:stringAttribute name="Flaeche">
<gen:value>6.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.203</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.665</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_1d159179-cb84-4258-a9b7-ef4d49f1f359_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.34 5335154.17 511.46 692497.96 5335155.02 511.46 692497.96 5335155.02 518.661 692498.313 5335154.231 518.588 692498.313 5335154.231 522.62 692498.34 5335154.17 522.665 692498.34 5335154.17 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_1f7c0fa7-836c-413c-a3bb-53ccf930e1d2_2">
<gen:stringAttribute name="Flaeche">
<gen:value>15.876</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.741</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.204</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_1f7c0fa7-836c-413c-a3bb-53ccf930e1d2_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692495.51 5335124.67 522.2 692495.51 5335124.67 511.46 692496.93 5335125.08 511.46 692496.93 5335125.08 522.18 692496.872 5335125.063 522.204 692495.51 5335124.67 522.2</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_1fe41424-ceb3-4ae4-89f3-a2b5829fff77_2">
<gen:stringAttribute name="Flaeche">
<gen:value>10.236</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.091</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_1fe41424-ceb3-4ae4-89f3-a2b5829fff77_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692489.28 5335125.48 511.46 692489.46 5335124.63 511.46 692489.46 5335124.63 522.031 692489.293 5335125.421 523.36 692489.293 5335125.421 530.553 692489.28 5335125.48 530.553 692489.28 5335125.48 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_2100aaf4-7dd8-4a7b-8dd9-b67aeb5c2979_2">
<gen:stringAttribute name="Flaeche">
<gen:value>20.349</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_2100aaf4-7dd8-4a7b-8dd9-b67aeb5c2979_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692493.267 5335147.603 540.75 692496.916 5335145.497 540.75 692496.916 5335145.497 535.02 692495.091 5335146.55 536.82 692493.267 5335147.603 535.02 692493.267 5335147.603 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_220d63ab-11d9-4895-bf3f-f10d2735d90d_2">
<gen:stringAttribute name="Flaeche">
<gen:value>23.740</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.568</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.030</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_220d63ab-11d9-4895-bf3f-f10d2735d90d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692504.58 5335130.65 511.46 692506.71 5335128.33 511.46 692506.71 5335128.33 518.986 692504.721 5335130.496 519.009 692504.63 5335130.596 518.979 692504.58 5335130.65 519.03 692504.58 5335130.65 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_26a9c7d8-549d-47f9-9823-42f2d9db0287_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.793</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.551</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.013</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_26a9c7d8-549d-47f9-9823-42f2d9db0287_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692494.54 5335157.4 511.46 692493.58 5335157.26 511.46 692493.58 5335157.26 531.013 692493.647 5335157.27 530.95 692493.647 5335157.27 518.608 692494.54 5335157.4 518.644 692494.54 5335157.4 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_2b364a14-8d05-48b8-b38c-2d598c0e91a4_2">
<gen:stringAttribute name="Flaeche">
<gen:value>101.354</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.593</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.056</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_2b364a14-8d05-48b8-b38c-2d598c0e91a4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692452.47 5335143.63 511.46 692452.47 5335143.63 522.056 692461.76 5335145.92 522.05 692461.76 5335145.92 511.46 692452.47 5335143.63 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_2b41926d-c9e2-46c3-a16b-b7b3f9af3c65_2">
<gen:stringAttribute name="Flaeche">
<gen:value>33.384</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.499</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.961</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_2b41926d-c9e2-46c3-a16b-b7b3f9af3c65_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.08 5335128.4 511.46 692510.93 5335130.65 511.46 692510.93 5335130.65 518.937 692510.906 5335130.636 518.961 692507.08 5335128.4 518.932 692507.08 5335128.4 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_2b80d4d5-660a-4111-9a98-fef0d9b5b65f_2">
<gen:stringAttribute name="Flaeche">
<gen:value>1.406</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.448</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.910</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>8.570</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>520.033</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_2b80d4d5-660a-4111-9a98-fef0d9b5b65f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.389 5335132.124 520.78 692501.389 5335132.124 521.91 692501.598 5335131.212 521.91 692501.598 5335131.212 520.033 692501.389 5335132.124 520.78</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_2ea85659-ffc6-45f7-bc1d-4acd9710aabe_2">
<gen:stringAttribute name="Flaeche">
<gen:value>12.874</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>20.367</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.830</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_2ea85659-ffc6-45f7-bc1d-4acd9710aabe_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692499.43 5335128.05 511.46 692499.66 5335127.03 511.46 692499.66 5335127.03 521.677 692499.461 5335127.913 523.36 692499.461 5335127.913 531.83 692499.43 5335128.05 531.829 692499.43 5335128.05 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_3225efbd-a217-4f35-b924-775193317c49_2">
<gen:stringAttribute name="Flaeche">
<gen:value>11.182</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.723</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.186</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_3225efbd-a217-4f35-b924-775193317c49_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692492.88 5335125.17 511.46 692493.83 5335124.74 511.46 692493.83 5335124.74 522.18 692492.919 5335125.152 522.186 692492.88 5335125.17 522.174 692492.88 5335125.17 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_327b2842-9230-4802-aa9b-1277a8f3bb35_2">
<gen:stringAttribute name="Flaeche">
<gen:value>20.201</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.555</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.017</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_327b2842-9230-4802-aa9b-1277a8f3bb35_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692491.82 5335126.1 511.46 692491.82 5335126.1 533.017 692490.88 5335125.92 532.116 692490.88 5335125.92 511.46 692491.82 5335126.1 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_36b4287e-4224-4ae1-9482-7952bc6da8bc_2">
<gen:stringAttribute name="Flaeche">
<gen:value>5.101</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>4.418</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.880</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_36b4287e-4224-4ae1-9482-7952bc6da8bc_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.78 5335127.24 511.46 692501.78 5335127.24 515.871 692500.67 5335126.92 515.88 692500.67 5335126.92 511.46 692501.78 5335127.24 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_370af134-4b4c-4243-9d9b-47cceac8f5ec_2">
<gen:stringAttribute name="Flaeche">
<gen:value>2.835</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.574</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.037</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_370af134-4b4c-4243-9d9b-47cceac8f5ec_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692506.71 5335128.33 511.46 692507.08 5335128.4 511.46 692507.08 5335128.4 518.932 692506.771 5335128.342 519.037 692506.71 5335128.33 518.986 692506.71 5335128.33 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_3712c236-718e-4713-96b8-ae54867c2eb0_2">
<gen:stringAttribute name="Flaeche">
<gen:value>33.477</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.295</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.758</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_3712c236-718e-4713-96b8-ae54867c2eb0_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692512.314 5335141.668 522.758 692512.24 5335140.94 522.642 692512.24 5335140.94 511.46 692512.54 5335143.91 511.46 692512.54 5335143.91 522.575 692512.314 5335141.668 522.758</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_3a719bfb-866c-4e9d-9c25-0269c968b9a2_2">
<gen:stringAttribute name="Flaeche">
<gen:value>9.684</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.182</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.645</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_3a719bfb-866c-4e9d-9c25-0269c968b9a2_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692484.54 5335155.64 511.46 692484.45 5335154.92 511.46 692484.45 5335154.92 532.58 692484.475 5335155.119 532.645 692484.475 5335155.119 521.82 692484.54 5335155.64 521.833 692484.54 5335155.64 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_3bcc7ef1-2d83-48b3-a5cd-45632ca77efe_2">
<gen:stringAttribute name="Flaeche">
<gen:value>8.362</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.085</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.547</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_3bcc7ef1-2d83-48b3-a5cd-45632ca77efe_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692488.97 5335126.8 511.46 692488.32 5335126.66 511.46 692488.32 5335126.66 521.749 692488.849 5335126.774 523.36 692488.849 5335126.774 530.43 692488.97 5335126.8 530.547 692488.97 5335126.8 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_3ef0be63-3181-466e-9423-97d87ddd8194_2">
<gen:stringAttribute name="Flaeche">
<gen:value>8.576</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.968</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.430</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_3ef0be63-3181-466e-9423-97d87ddd8194_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692482.481 5335153.216 523.36 692482.481 5335153.216 530.43 692482.21 5335154.398 530.43 692482.21 5335154.398 523.36 692482.481 5335153.216 523.36</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_419e743c-c219-4a62-b789-b5d5b516e8cc_2">
<gen:stringAttribute name="Flaeche">
<gen:value>4.836</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.417</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.879</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_419e743c-c219-4a62-b789-b5d5b516e8cc_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692494.71 5335156.76 511.46 692494.54 5335157.4 511.46 692494.54 5335157.4 518.644 692494.555 5335157.342 518.668 692494.71 5335156.76 518.879 692494.71 5335156.76 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_44fa8848-5e88-4e2f-8cdd-5c16b59f66f2_2">
<gen:stringAttribute name="Flaeche">
<gen:value>6.157</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_44fa8848-5e88-4e2f-8cdd-5c16b59f66f2_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.721 5335143.981 526.21 692507.721 5335143.981 529.96 692507.733 5335142.339 529.96 692507.733 5335142.339 526.21 692507.721 5335143.981 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_45326f16-6b63-41ad-85df-98c2066f8a0c_2">
<gen:stringAttribute name="Flaeche">
<gen:value>12.185</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.418</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.880</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_45326f16-6b63-41ad-85df-98c2066f8a0c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692488.92 5335158.58 511.46 692487.75 5335158.56 511.46 692487.75 5335158.56 521.853 692487.847 5335158.562 521.868 692488.872 5335158.579 521.88 692488.92 5335158.58 521.863 692488.92 5335158.58 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_46efeddb-3c7c-4ed4-9108-d70ab9c8668c_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.606</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.042</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.505</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_46efeddb-3c7c-4ed4-9108-d70ab9c8668c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692481.95 5335153.12 511.46 692482.56 5335153.23 511.46 692482.56 5335153.23 530.505 692482.481 5335153.216 530.43 692482.481 5335153.216 523.36 692481.95 5335153.12 522.112 692481.95 5335153.12 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_485e96cb-3add-4f82-8efb-242964368350_2">
<gen:stringAttribute name="Flaeche">
<gen:value>20.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_485e96cb-3add-4f82-8efb-242964368350_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692484.927 5335142.559 540.75 692487.273 5335146.134 540.75 692487.273 5335146.134 535.02 692486.1 5335144.346 536.82 692484.927 5335142.559 535.02 692484.927 5335142.559 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_48899b99-cb4a-4b21-b8e1-0328a41b2427_2">
<gen:stringAttribute name="Flaeche">
<gen:value>2.673</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.401</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.863</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_48899b99-cb4a-4b21-b8e1-0328a41b2427_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692487.25 5335158.45 511.46 692487 5335158.39 511.46 692487 5335158.39 521.842 692487.141 5335158.424 521.863 692487.25 5335158.45 521.86 692487.25 5335158.45 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_49b807b5-0e46-45e3-a2a7-b945159154e3_2">
<gen:stringAttribute name="Flaeche">
<gen:value>17.291</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.242</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.704</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_49b807b5-0e46-45e3-a2a7-b945159154e3_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692500.95 5335154.5 511.46 692500.95 5335154.5 522.704 692502.49 5335154.51 522.672 692502.49 5335154.51 511.46 692500.95 5335154.5 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_4f1ed6d1-f241-4134-a611-6b03b45969d5_2">
<gen:stringAttribute name="Flaeche">
<gen:value>20.349</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_4f1ed6d1-f241-4134-a611-6b03b45969d5_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692489.88 5335134.772 540.75 692486.231 5335136.878 540.75 692486.231 5335136.878 535.02 692488.056 5335135.825 536.82 692489.88 5335134.772 535.02 692489.88 5335134.772 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_4ff2db9b-9a2d-4a24-b10f-8a366a6248c9_2">
<gen:stringAttribute name="Flaeche">
<gen:value>13.753</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>20.947</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.409</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_4ff2db9b-9a2d-4a24-b10f-8a366a6248c9_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692491.97 5335157.78 511.46 692492.16 5335156.77 511.46 692492.16 5335156.77 532.409 692492.118 5335156.992 532.401 692492.118 5335156.992 523.36 692491.97 5335157.78 522.066 692491.97 5335157.78 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_50bc729a-6a36-4bea-8ebd-f0533fa84ea4_2">
<gen:stringAttribute name="Flaeche">
<gen:value>81.709</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.738</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.200</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.820</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_50bc729a-6a36-4bea-8ebd-f0533fa84ea4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692491.289 5335156.789 521.848 692487.717 5335155.913 523.97 692484.475 5335155.119 521.82 692484.475 5335155.119 532.645 692488.168 5335156.024 536.2 692491.289 5335156.789 533.198 692491.289 5335156.789 521.848</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_54befabf-bc4e-4434-baf4-5fbe24c34afd_2">
<gen:stringAttribute name="Flaeche">
<gen:value>48.739</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.950</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.448</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_54befabf-bc4e-4434-baf4-5fbe24c34afd_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.335 5335136.844 530.95 692499.871 5335130.155 530.95 692499.871 5335130.155 521.91 692499.524 5335131.667 521.91 692499.524 5335131.667 522.62 692498.335 5335136.844 526.21 692498.335 5335136.844 530.95</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_54d65c82-d0cd-4923-b35f-8eb0a7988a22_2">
<gen:stringAttribute name="Flaeche">
<gen:value>5.323</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.398</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.860</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_54d65c82-d0cd-4923-b35f-8eb0a7988a22_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692487.25 5335158.45 511.46 692487.25 5335158.45 521.86 692487.75 5335158.56 521.853 692487.75 5335158.56 511.46 692487.25 5335158.45 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_55bc9188-225c-4c4d-b3b3-10722e31ec3c_2">
<gen:stringAttribute name="Flaeche">
<gen:value>16.454</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.453</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_55bc9188-225c-4c4d-b3b3-10722e31ec3c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692505.54 5335153.86 511.46 692504.16 5335154.28 511.46 692504.16 5335154.28 522.807 692504.707 5335154.114 522.916 692505.54 5335153.86 522.824 692505.54 5335153.86 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_57bfed54-78bc-42f2-8edb-8344870e72cd_2">
<gen:stringAttribute name="Flaeche">
<gen:value>2.038</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>4.808</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>516.271</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_57bfed54-78bc-42f2-8edb-8344870e72cd_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692500.67 5335126.92 511.46 692500.67 5335126.92 515.88 692500.57 5335127.35 516.271 692500.57 5335127.35 511.46 692500.67 5335126.92 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_594c5a33-d28f-4389-bc1b-3cbe38af64bc_2">
<gen:stringAttribute name="Flaeche">
<gen:value>5.404</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_594c5a33-d28f-4389-bc1b-3cbe38af64bc_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692506.643 5335147.434 526.21 692506.643 5335147.434 529.96 692507.305 5335146.154 529.96 692507.305 5335146.154 526.21 692506.643 5335147.434 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_5b471bb6-74fc-48d3-83fd-a1e16bd977f2_2">
<gen:stringAttribute name="Flaeche">
<gen:value>6.730</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.315</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.778</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_5b471bb6-74fc-48d3-83fd-a1e16bd977f2_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692496.42 5335156.45 511.46 692495.55 5335156.75 511.46 692495.55 5335156.75 518.774 692496.162 5335156.539 518.778 692496.42 5335156.45 518.752 692496.42 5335156.45 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_5d87d100-a21f-42ef-b916-04036536d088_2">
<gen:stringAttribute name="Flaeche">
<gen:value>188.583</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.006</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_5d87d100-a21f-42ef-b916-04036536d088_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692471.23 5335124.84 511.46 692488.37 5335129.04 511.46 692488.37 5335129.04 530.468 692488.331 5335129.03 530.43 692488.331 5335129.03 522.127 692471.23 5335124.84 522.127 692471.23 5335124.84 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_5f21e4e7-8a62-4d3c-ae3c-6cb0ea2244c9_2">
<gen:stringAttribute name="Flaeche">
<gen:value>8.735</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_5f21e4e7-8a62-4d3c-ae3c-6cb0ea2244c9_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.158 5335149.536 526.21 692501.158 5335149.536 529.96 692503.487 5335149.482 529.96 692503.487 5335149.482 526.21 692501.158 5335149.536 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_6006558f-31e6-43b0-9a93-b56d2433654d_2">
<gen:stringAttribute name="Flaeche">
<gen:value>14.253</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>5.102</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>516.564</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_6006558f-31e6-43b0-9a93-b56d2433654d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.208 5335127.886 516.564 692501.208 5335127.886 532.53 692500.336 5335128.127 532.53 692500.336 5335128.127 530.95 692500.336 5335128.127 523.36 692500.336 5335128.127 516.99 692501.208 5335127.886 516.564</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_61c46311-1a99-43f7-ba01-0db341abe45c_2">
<gen:stringAttribute name="Flaeche">
<gen:value>4.449</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>4.408</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.871</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_61c46311-1a99-43f7-ba01-0db341abe45c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692502.75 5335127.52 511.46 692502.75 5335127.52 515.863 692501.78 5335127.24 515.871 692501.78 5335127.24 511.46 692502.75 5335127.52 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_6685c0a6-b56a-4c2d-9d88-a2d1f0bce083_2">
<gen:stringAttribute name="Flaeche">
<gen:value>14.135</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.327</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.790</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_6685c0a6-b56a-4c2d-9d88-a2d1f0bce083_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692508.75 5335151.99 511.46 692508.75 5335151.99 522.709 692509.61 5335151.08 522.79 692509.61 5335151.08 511.46 692508.75 5335151.99 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_6a0e37aa-ab59-4111-beae-db77c8ac301c_2">
<gen:stringAttribute name="Flaeche">
<gen:value>27.227</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.224</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.686</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_6a0e37aa-ab59-4111-beae-db77c8ac301c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692509.88 5335136.38 522.516 692509.88 5335136.38 511.46 692511.27 5335138.39 511.46 692511.27 5335138.39 522.686 692509.88 5335136.38 522.516</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_6c08a0e2-3899-4f62-98c7-a10b8c58c428_2">
<gen:stringAttribute name="Flaeche">
<gen:value>17.664</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.401</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.863</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_6c08a0e2-3899-4f62-98c7-a10b8c58c428_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692488.92 5335158.58 511.46 692488.92 5335158.58 521.863 692490.43 5335157.8 521.843 692490.43 5335157.8 511.46 692488.92 5335158.58 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_6cda9d25-84da-4f50-b9b3-4d88cab1e1e5_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.693</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.454</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_6cda9d25-84da-4f50-b9b3-4d88cab1e1e5_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692485.14 5335157 511.46 692485.14 5335157 521.864 692485.62 5335157.56 521.916 692485.62 5335157.56 511.46 692485.14 5335157 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_7183b68d-526b-493d-966e-150d754a06c3_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.943</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.047</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.509</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_7183b68d-526b-493d-966e-150d754a06c3_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692482.29 5335154.43 511.46 692481.69 5335154.19 511.46 692481.69 5335154.19 522.08 692482.21 5335154.398 523.36 692482.21 5335154.398 530.43 692482.29 5335154.43 530.509 692482.29 5335154.43 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_71c07642-44df-486a-8b47-3d7889fa258f_2">
<gen:stringAttribute name="Flaeche">
<gen:value>9.362</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.568</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>519.030</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_71c07642-44df-486a-8b47-3d7889fa258f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692504.58 5335130.65 511.46 692504.58 5335130.65 519.03 692503.39 5335130.3 518.985 692503.39 5335130.3 511.46 692504.58 5335130.65 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_72fd0baf-e7e6-4b80-8401-e52f4cdb23b5_2">
<gen:stringAttribute name="Flaeche">
<gen:value>52.689</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.588</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.050</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_72fd0baf-e7e6-4b80-8401-e52f4cdb23b5_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692461.76 5335145.92 511.46 692461.76 5335145.92 522.05 692466.59 5335147.12 522.043 692466.59 5335147.12 511.46 692461.76 5335145.92 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_7397367d-21e0-439b-96cb-4514b531a386_2">
<gen:stringAttribute name="Flaeche">
<gen:value>9.918</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.776</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>519.238</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_7397367d-21e0-439b-96cb-4514b531a386_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692502.654 5335131.06 519.714 692502.654 5335131.06 532.53 692503.254 5335130.593 532.53 692503.254 5335130.593 519.238 692502.654 5335131.06 519.714</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_7471c36e-9889-43c4-84cd-622f460e2521_2">
<gen:stringAttribute name="Flaeche">
<gen:value>279.335</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>13.048</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>524.510</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_7471c36e-9889-43c4-84cd-622f460e2521_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.335 5335136.844 526.21 692504.525 5335138.361 526.21 692504.525 5335138.361 529.96 692498.871 5335136.976 529.96 692498.871 5335136.976 535.02 692495.874 5335136.241 535.02 692495.874 5335136.241 540.75 692489.88 5335134.772 540.75 692489.88 5335134.772 535.02 692486.883 5335134.038 535.02 692486.883 5335134.038 530.76 692456.422 5335126.574 530.76 692456.422 5335126.574 524.51 692487.166 5335134.107 524.51 692487.166 5335134.107 530.43 692493.113 5335135.565 536.2 692498.335 5335136.844 530.95 692498.335 5335136.844 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_7eeda2e4-f70d-45b1-9a85-7115b945db54_2">
<gen:stringAttribute name="Flaeche">
<gen:value>15.850</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.594</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.056</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_7eeda2e4-f70d-45b1-9a85-7115b945db54_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692491.82 5335126.1 511.46 692492.88 5335125.17 511.46 692492.88 5335125.17 522.174 692491.873 5335126.053 522.134 692491.873 5335126.053 533.056 692491.82 5335126.1 533.017 692491.82 5335126.1 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_7ef4e683-6246-4e18-882b-98d129a8f90f_2">
<gen:stringAttribute name="Flaeche">
<gen:value>273.921</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>13.048</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>524.510</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_7ef4e683-6246-4e18-882b-98d129a8f90f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.158 5335149.536 526.21 692495.728 5335148.206 526.21 692495.728 5335148.206 530.95 692490.27 5335146.868 536.2 692484.275 5335145.399 530.43 692484.275 5335145.399 524.51 692453.793 5335137.93 524.51 692453.793 5335137.93 530.76 692484.275 5335145.399 530.76 692484.275 5335145.399 535.02 692487.273 5335146.134 535.02 692487.273 5335146.134 540.75 692493.267 5335147.603 540.75 692493.267 5335147.603 535.02 692496.264 5335148.337 535.02 692496.264 5335148.337 529.96 692501.158 5335149.536 529.96 692501.158 5335149.536 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_82425164-36b1-4cba-9f2e-c9b6097f1318_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.852</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.402</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.864</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_82425164-36b1-4cba-9f2e-c9b6097f1318_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692484.77 5335156.36 511.46 692484.54 5335155.64 511.46 692484.54 5335155.64 521.833 692484.604 5335155.842 521.864 692484.77 5335156.36 521.834 692484.77 5335156.36 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_828c3427-3f68-476b-a7eb-cabda0d71698_2">
<gen:stringAttribute name="Flaeche">
<gen:value>11.156</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.118</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.580</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_828c3427-3f68-476b-a7eb-cabda0d71698_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692483.94 5335154.76 511.46 692483.94 5335154.76 532.082 692484.45 5335154.92 532.58 692484.45 5335154.92 511.46 692483.94 5335154.76 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_84faeda3-299c-4bbe-a344-fa0c1b19ada1_2">
<gen:stringAttribute name="Flaeche">
<gen:value>51.173</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.298</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>530.760</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_84faeda3-299c-4bbe-a344-fa0c1b19ada1_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692486.231 5335136.878 540.75 692484.927 5335142.559 540.75 692484.927 5335142.559 535.02 692484.275 5335145.399 535.02 692484.275 5335145.399 530.76 692485.572 5335139.748 536.23 692486.883 5335134.038 530.76 692486.883 5335134.038 535.02 692486.231 5335136.878 535.02 692486.231 5335136.878 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_89d5452c-edd6-463c-b02f-f171abd1fd9a_2">
<gen:stringAttribute name="Flaeche">
<gen:value>20.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_89d5452c-edd6-463c-b02f-f171abd1fd9a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.22 5335139.816 540.75 692495.874 5335136.241 540.75 692495.874 5335136.241 535.02 692497.047 5335138.029 536.82 692498.22 5335139.816 535.02 692498.22 5335139.816 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_8b23a162-2652-4c52-9daf-f71757252869_2">
<gen:stringAttribute name="Flaeche">
<gen:value>76.731</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.738</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.200</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.645</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.107</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_8b23a162-2652-4c52-9daf-f71757252869_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692491.873 5335126.053 522.134 692495.114 5335126.847 524.48 692498.489 5335127.675 522.107 692498.489 5335127.675 532.806 692495.114 5335126.847 536.2 692491.873 5335126.053 533.056 692491.873 5335126.053 522.134</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_8b3b9a3a-bdb5-462d-9c5d-f0d6dfee5411_2">
<gen:stringAttribute name="Flaeche">
<gen:value>13.702</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.287</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.749</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_8b3b9a3a-bdb5-462d-9c5d-f0d6dfee5411_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692488.59 5335125.35 511.46 692488.59 5335125.35 521.66 692488.32 5335126.66 521.749 692488.32 5335126.66 511.46 692488.59 5335125.35 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_8e1cd80d-e1d6-42fb-9d06-18b58dfe76fb_2">
<gen:stringAttribute name="Flaeche">
<gen:value>10.787</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.052</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.515</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_8e1cd80d-e1d6-42fb-9d06-18b58dfe76fb_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692482.13 5335155.27 511.46 692482.29 5335154.43 511.46 692482.29 5335154.43 530.509 692482.262 5335154.577 530.515 692482.262 5335154.577 523.36 692482.13 5335155.27 522.065 692482.13 5335155.27 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_8f067821-8f3e-40fd-93d6-7c4879c522f7_2">
<gen:stringAttribute name="Flaeche">
<gen:value>13.645</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.340</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.802</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_8f067821-8f3e-40fd-93d6-7c4879c522f7_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.77 5335152.79 511.46 692506.73 5335153.4 511.46 692506.73 5335153.4 522.754 692507.43 5335152.989 522.802 692507.77 5335152.79 522.747 692507.77 5335152.79 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_95d280e1-ac64-451e-9c2a-4e1306e49e8b_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.537</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.293</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.755</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_95d280e1-ac64-451e-9c2a-4e1306e49e8b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692497.29 5335155.89 511.46 692496.42 5335156.45 511.46 692496.42 5335156.45 518.752 692496.931 5335156.121 518.755 692497.29 5335155.89 518.708 692497.29 5335155.89 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_9608e903-1cd0-4685-b980-c502dca56f3a_2">
<gen:stringAttribute name="Flaeche">
<gen:value>18.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.222</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.685</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_9608e903-1cd0-4685-b980-c502dca56f3a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692499.43 5335128.05 511.46 692499.43 5335128.05 531.829 692498.57 5335127.88 532.685 692498.57 5335127.88 511.46 692499.43 5335128.05 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_967b25f1-198b-4b02-94fa-12b62d1ac36e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>6.741</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_967b25f1-198b-4b02-94fa-12b62d1ac36e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692506.03 5335139.344 526.21 692506.03 5335139.344 529.96 692504.525 5335138.361 529.96 692504.525 5335138.361 526.21 692506.03 5335139.344 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_970ace7c-a366-4bb9-852c-f19982b4e764_2">
<gen:stringAttribute name="Flaeche">
<gen:value>37.043</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.968</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.430</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.665</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.127</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_970ace7c-a366-4bb9-852c-f19982b4e764_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692488.331 5335129.03 522.127 692488.331 5335129.03 530.43 692487.166 5335134.107 530.43 692487.166 5335134.107 524.51 692488.331 5335129.03 522.127</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_989be770-853b-49cb-a5a6-4d5644676ab2_2">
<gen:stringAttribute name="Flaeche">
<gen:value>23.054</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.521</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.983</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_989be770-853b-49cb-a5a6-4d5644676ab2_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692510.26 5335133.65 511.46 692510.26 5335133.65 518.983 692510.93 5335130.65 518.937 692510.93 5335130.65 511.46 692510.26 5335133.65 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_9da27cab-b31a-43ba-b311-acf03b3fe644_2">
<gen:stringAttribute name="Flaeche">
<gen:value>4.337</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.081</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.543</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.522</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.985</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_9da27cab-b31a-43ba-b311-acf03b3fe644_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692503.254 5335130.593 519.238 692503.254 5335130.593 532.53 692503.39 5335130.3 532.543 692503.39 5335130.3 518.985 692503.254 5335130.593 519.238</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_a0118ed4-8371-4836-8d95-44444dc8d4f5_2">
<gen:stringAttribute name="Flaeche">
<gen:value>8.999</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.454</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_a0118ed4-8371-4836-8d95-44444dc8d4f5_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692485.62 5335157.56 511.46 692485.62 5335157.56 521.916 692486.31 5335158.08 521.836 692486.31 5335158.08 511.46 692485.62 5335157.56 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_a1d5ba4c-04e7-42be-987b-2cf301042cc9_2">
<gen:stringAttribute name="Flaeche">
<gen:value>6.188</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.417</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.879</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_a1d5ba4c-04e7-42be-987b-2cf301042cc9_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692494.71 5335156.76 511.46 692494.71 5335156.76 518.879 692495.55 5335156.75 518.774 692495.55 5335156.75 511.46 692494.71 5335156.76 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_a546f6b4-57f1-4176-affd-c6d3e0219440_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.962</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>7.267</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.730</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_a546f6b4-57f1-4176-affd-c6d3e0219440_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692497.96 5335155.02 511.46 692497.29 5335155.89 511.46 692497.29 5335155.89 518.708 692497.728 5335155.322 518.73 692497.96 5335155.02 518.661 692497.96 5335155.02 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_a559d80b-b13c-46a7-a4e9-10ba38d78660_2">
<gen:stringAttribute name="Flaeche">
<gen:value>23.281</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.211</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.674</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_a559d80b-b13c-46a7-a4e9-10ba38d78660_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692502.86 5335128.15 511.46 692503.49 5335129.05 511.46 692503.49 5335129.05 532.551 692503.415 5335128.943 532.674 692502.899 5335128.205 532.647 692502.86 5335128.15 532.58 692502.86 5335128.15 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_a592b224-c32a-4cbe-b434-22038b82d531_2">
<gen:stringAttribute name="Flaeche">
<gen:value>12.441</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>20.620</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.082</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_a592b224-c32a-4cbe-b434-22038b82d531_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692483.94 5335154.76 511.46 692483.64 5335155.63 511.46 692483.64 5335155.63 522.083 692483.868 5335154.97 523.36 692483.868 5335154.97 532.06 692483.94 5335154.76 532.082 692483.94 5335154.76 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_a5cb4bfb-ff8b-4c03-893a-1b2ea62b2532_2">
<gen:stringAttribute name="Flaeche">
<gen:value>17.680</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.501</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.964</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_a5cb4bfb-ff8b-4c03-893a-1b2ea62b2532_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692510.52 5335149.83 511.46 692509.61 5335151.08 511.46 692509.61 5335151.08 522.79 692510.266 5335150.179 522.964 692510.52 5335149.83 522.916 692510.52 5335149.83 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_ab87c2dc-0881-4130-8bf3-fff6343e9473_2">
<gen:stringAttribute name="Flaeche">
<gen:value>10.371</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.562</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.024</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_ab87c2dc-0881-4130-8bf3-fff6343e9473_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692493.58 5335157.26 511.46 692493.28 5335158.06 511.46 692493.28 5335158.06 522.131 692493.549 5335157.342 523.36 692493.549 5335157.342 531.024 692493.58 5335157.26 531.013 692493.58 5335157.26 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_ad53be12-fb0a-4163-ab71-dd6a8b98ef0f_2">
<gen:stringAttribute name="Flaeche">
<gen:value>44.171</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.085</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.547</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_ad53be12-fb0a-4163-ab71-dd6a8b98ef0f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692488.97 5335126.8 511.46 692488.97 5335126.8 530.547 692488.37 5335129.04 530.468 692488.37 5335129.04 511.46 692488.97 5335126.8 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_b07db88b-067b-43c4-925d-99583d76bc4c_2">
<gen:stringAttribute name="Flaeche">
<gen:value>25.751</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.344</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.806</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_b07db88b-067b-43c4-925d-99583d76bc4c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692497.77 5335125.84 511.46 692498.57 5335127.88 511.46 692498.57 5335127.88 532.685 692498.489 5335127.675 532.806 692498.489 5335127.675 522.107 692497.77 5335125.84 522.181 692497.77 5335125.84 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_b34af73f-da19-4908-b58a-1f660eb7161a_2">
<gen:stringAttribute name="Flaeche">
<gen:value>8.805</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.091</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_b34af73f-da19-4908-b58a-1f660eb7161a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692488.59 5335125.35 511.46 692489.28 5335125.48 511.46 692489.28 5335125.48 530.553 692489.151 5335125.456 530.43 692489.151 5335125.456 523.36 692488.59 5335125.35 521.66 692488.59 5335125.35 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_b36973f7-9b0d-448a-b2d9-ca3f74d808ff_2">
<gen:stringAttribute name="Flaeche">
<gen:value>14.454</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.361</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.824</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_b36973f7-9b0d-448a-b2d9-ca3f74d808ff_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692505.54 5335153.86 511.46 692505.54 5335153.86 522.824 692506.73 5335153.4 522.754 692506.73 5335153.4 511.46 692505.54 5335153.86 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_b5e252d5-ec7c-4806-9784-b9835f30ebfe_2">
<gen:stringAttribute name="Flaeche">
<gen:value>14.869</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.596</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.058</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_b5e252d5-ec7c-4806-9784-b9835f30ebfe_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692491.5 5335156.54 511.46 692491.5 5335156.54 533.058 692492.16 5335156.77 532.409 692492.16 5335156.77 511.46 692491.5 5335156.54 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_b7211cd7-3bb7-429f-8628-4b3dd1237f95_2">
<gen:stringAttribute name="Flaeche">
<gen:value>11.711</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.650</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.112</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_b7211cd7-3bb7-429f-8628-4b3dd1237f95_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692481.95 5335153.12 511.46 692481.95 5335153.12 522.112 692481.69 5335154.19 522.08 692481.69 5335154.19 511.46 692481.95 5335153.12 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_b72c1644-f626-41f8-833c-5495d82cbde5_2">
<gen:stringAttribute name="Flaeche">
<gen:value>6.150</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_b72c1644-f626-41f8-833c-5495d82cbde5_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.733 5335142.339 526.21 692507.733 5335142.339 529.96 692507.23 5335140.778 529.96 692507.23 5335140.778 526.21 692507.733 5335142.339 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_b8b923d8-a1e9-40a0-a485-5eb31dbbb166_2">
<gen:stringAttribute name="Flaeche">
<gen:value>20.855</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.736</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>533.198</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_b8b923d8-a1e9-40a0-a485-5eb31dbbb166_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692491.5 5335156.54 511.46 692490.43 5335157.8 511.46 692490.43 5335157.8 521.843 692490.457 5335157.768 521.854 692491.289 5335156.789 521.848 692491.289 5335156.789 533.198 692491.5 5335156.54 533.058 692491.5 5335156.54 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_bccbfacb-fcc3-4e5c-aa5e-936cb781659e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>19.801</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.249</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.712</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_bccbfacb-fcc3-4e5c-aa5e-936cb781659e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692508.709 5335135.383 522.712 692508.53 5335135.23 522.69 692508.53 5335135.23 511.46 692509.88 5335136.38 511.46 692509.88 5335136.38 522.516 692508.709 5335135.383 522.712</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_bd38e6b4-a45d-4c2a-bc05-445cafae3df9_2">
<gen:stringAttribute name="Flaeche">
<gen:value>25.159</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.228</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.691</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_bd38e6b4-a45d-4c2a-bc05-445cafae3df9_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692512.54 5335143.91 522.575 692512.54 5335143.91 511.46 692512.2 5335146.13 511.46 692512.2 5335146.13 522.687 692512.379 5335144.964 522.691 692512.54 5335143.91 522.575</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_c0f68b81-a171-489b-80c9-ee897c2d8008_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.855</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.385</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.847</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_c0f68b81-a171-489b-80c9-ee897c2d8008_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692487 5335158.39 511.46 692486.31 5335158.08 511.46 692486.31 5335158.08 521.836 692486.423 5335158.131 521.847 692487 5335158.39 521.842 692487 5335158.39 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_c0f7ae63-f149-47e3-bfee-247cb5a449b4_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.691</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.420</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.883</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_c0f7ae63-f149-47e3-bfee-247cb5a449b4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692485.14 5335157 511.46 692484.77 5335156.36 511.46 692484.77 5335156.36 521.834 692485.012 5335156.778 521.883 692485.14 5335157 521.864 692485.14 5335157 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_c2b370d5-ae17-44be-a620-a19b88ca5577_2">
<gen:stringAttribute name="Flaeche">
<gen:value>12.144</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.718</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.181</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_c2b370d5-ae17-44be-a620-a19b88ca5577_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692497.77 5335125.84 511.46 692497.77 5335125.84 522.181 692496.93 5335125.08 522.18 692496.93 5335125.08 511.46 692497.77 5335125.84 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_c2e9003a-5140-4bec-aa0c-aea9b1fbf9b9_2">
<gen:stringAttribute name="Flaeche">
<gen:value>14.112</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.292</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.755</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_c2e9003a-5140-4bec-aa0c-aea9b1fbf9b9_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692512.2 5335146.13 511.46 692511.84 5335147.33 511.46 692511.84 5335147.33 522.755 692512.16 5335146.263 522.701 692512.2 5335146.13 522.687 692512.2 5335146.13 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_c622f18f-e139-4725-961a-c505689b5d5a_2">
<gen:stringAttribute name="Flaeche">
<gen:value>30.646</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.278</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.740</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_c622f18f-e139-4725-961a-c505689b5d5a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692511.27 5335138.39 511.46 692512.24 5335140.94 511.46 692512.24 5335140.94 522.642 692511.347 5335138.593 522.74 692511.27 5335138.39 522.686 692511.27 5335138.39 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_c7101198-8ab7-410a-8fee-16f92f071c11_2">
<gen:stringAttribute name="Flaeche">
<gen:value>13.655</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.730</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.192</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_c7101198-8ab7-410a-8fee-16f92f071c11_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692493.83 5335124.74 511.46 692495.09 5335124.55 511.46 692495.09 5335124.55 522.16 692493.876 5335124.733 522.192 692493.83 5335124.74 522.18 692493.83 5335124.74 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_c745da01-8c6c-4280-a89c-3918b2ff188d_2">
<gen:stringAttribute name="Flaeche">
<gen:value>19.014</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.344</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.807</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_c745da01-8c6c-4280-a89c-3918b2ff188d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692502.49 5335154.51 511.46 692502.49 5335154.51 522.672 692504.16 5335154.28 522.807 692504.16 5335154.28 511.46 692502.49 5335154.51 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_cb389c11-da5c-449a-aa5c-3af3e1f3675b_2">
<gen:stringAttribute name="Flaeche">
<gen:value>4.559</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.120</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.582</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_cb389c11-da5c-449a-aa5c-3af3e1f3675b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692502.86 5335128.15 511.46 692502.86 5335128.15 532.58 692502.65 5335128.1 532.582 692502.65 5335128.1 511.46 692502.86 5335128.15 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_cb89fb05-48b6-45b7-9398-7b00b43e0414_2">
<gen:stringAttribute name="Flaeche">
<gen:value>18.750</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.228</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.690</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_cb89fb05-48b6-45b7-9398-7b00b43e0414_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692510.26 5335133.65 511.46 692508.53 5335135.23 511.46 692508.53 5335135.23 522.69 692508.603 5335135.163 522.62 692508.603 5335135.163 519.645 692510.211 5335133.695 519.019 692510.26 5335133.65 518.983 692510.26 5335133.65 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_cbb1d83f-5daf-4f89-a083-b0abad57ae1c_2">
<gen:stringAttribute name="Flaeche">
<gen:value>6.306</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.158</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.620</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>8.182</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>519.645</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_cbb1d83f-5daf-4f89-a083-b0abad57ae1c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692508.603 5335135.163 522.62 692505.489 5335133.128 522.62 692505.489 5335133.128 520.78 692506.464 5335133.766 521.85 692508.603 5335135.163 519.645 692508.603 5335135.163 522.62</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_cc860c65-f4b7-4bbb-8375-d55de82630c5_2">
<gen:stringAttribute name="Flaeche">
<gen:value>4.776</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.375</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.837</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_cc860c65-f4b7-4bbb-8375-d55de82630c5_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692453.74 5335138.17 511.46 692453.81 5335137.85 511.46 692453.81 5335137.85 530.837 692453.793 5335137.93 530.76 692453.793 5335137.93 524.51 692453.74 5335138.17 524.407 692453.74 5335138.17 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_cd33858e-61e5-40af-818b-1b2c2da0377e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>18.482</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.415</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.877</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_cd33858e-61e5-40af-818b-1b2c2da0377e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692511.84 5335147.33 511.46 692511.15 5335148.8 511.46 692511.15 5335148.8 522.854 692511.507 5335148.039 522.877 692511.84 5335147.33 522.755 692511.84 5335147.33 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_d3c48867-28bc-4d75-bed1-5e860853a073_2">
<gen:stringAttribute name="Flaeche">
<gen:value>59.566</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_d3c48867-28bc-4d75-bed1-5e860853a073_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.871 5335136.976 529.96 692497.561 5335142.686 535.59 692496.264 5335148.337 529.96 692496.264 5335148.337 535.02 692496.916 5335145.497 535.02 692496.916 5335145.497 540.75 692498.22 5335139.816 540.75 692498.22 5335139.816 535.02 692498.871 5335136.976 535.02 692498.871 5335136.976 529.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_da899b95-e40d-453f-8f49-120273554631_2">
<gen:stringAttribute name="Flaeche">
<gen:value>12.304</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>20.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.401</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_da899b95-e40d-453f-8f49-120273554631_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692492.118 5335156.992 523.36 692492.118 5335156.992 532.401 692493.549 5335157.342 531.024 692493.549 5335157.342 523.36 692492.118 5335156.992 523.36</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_dca2ca21-61c2-4211-9b8a-e407baac9d70_2">
<gen:stringAttribute name="Flaeche">
<gen:value>10.909</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.448</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_dca2ca21-61c2-4211-9b8a-e407baac9d70_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692500.636 5335130.85 521.91 692500.636 5335130.85 532.53 692501.598 5335131.212 532.53 692501.598 5335131.212 521.91 692500.636 5335130.85 521.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_dd3fce78-f55f-4bad-aa97-9805ee17ce2d_2">
<gen:stringAttribute name="Flaeche">
<gen:value>4.871</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>4.806</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>516.269</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_dd3fce78-f55f-4bad-aa97-9805ee17ce2d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692500.336 5335128.127 516.99 692500.336 5335128.127 523.36 692500.518 5335127.332 521.843 692500.518 5335127.332 516.269 692500.336 5335128.127 516.99</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_dd714693-63eb-4a1f-9169-ceb73e7decea_2">
<gen:stringAttribute name="Flaeche">
<gen:value>5.388</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.380</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.843</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_dd714693-63eb-4a1f-9169-ceb73e7decea_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692500.05 5335127.17 511.46 692500.57 5335127.35 511.46 692500.57 5335127.35 516.271 692500.518 5335127.332 516.269 692500.518 5335127.332 521.843 692500.05 5335127.17 521.757 692500.05 5335127.17 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_df9841b6-6314-455a-b6b7-7cc64907e098_2">
<gen:stringAttribute name="Flaeche">
<gen:value>9.561</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.968</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.430</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_df9841b6-6314-455a-b6b7-7cc64907e098_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692489.151 5335125.456 523.36 692489.151 5335125.456 530.43 692488.849 5335126.774 530.43 692488.849 5335126.774 523.36 692489.151 5335125.456 523.36</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_dfb526a6-7272-4100-a82f-c41efc3ddc3a_2">
<gen:stringAttribute name="Flaeche">
<gen:value>13.104</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>20.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.060</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_dfb526a6-7272-4100-a82f-c41efc3ddc3a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692482.262 5335154.577 523.36 692482.262 5335154.577 530.515 692483.868 5335154.97 532.06 692483.868 5335154.97 523.36 692482.262 5335154.577 523.36</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_dff65b12-5484-4371-b5d8-896960f71c53_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.642</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_dff65b12-5484-4371-b5d8-896960f71c53_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692503.487 5335149.482 526.21 692503.487 5335149.482 529.96 692505.325 5335148.602 529.96 692505.325 5335148.602 526.21 692503.487 5335149.482 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_e149b81b-f97a-4aa7-96b1-b73709bf1916_2">
<gen:stringAttribute name="Flaeche">
<gen:value>4.250</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.295</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.757</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_e149b81b-f97a-4aa7-96b1-b73709bf1916_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692500.05 5335127.17 511.46 692500.05 5335127.17 521.757 692499.66 5335127.03 521.677 692499.66 5335127.03 511.46 692500.05 5335127.17 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_e2e9aaff-a0a5-454e-a312-72d4a7fb3077_2">
<gen:stringAttribute name="Flaeche">
<gen:value>180.136</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.054</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.516</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_e2e9aaff-a0a5-454e-a312-72d4a7fb3077_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692483.05 5335151.15 511.46 692466.59 5335147.12 511.46 692466.59 5335147.12 522.043 692482.961 5335151.128 522.045 692482.961 5335151.128 530.43 692483.05 5335151.15 530.516 692483.05 5335151.15 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_e4a490ca-44b1-4204-bf08-ae4bfb5b298e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>13.512</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>8.251</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>519.714</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_e4a490ca-44b1-4204-bf08-ae4bfb5b298e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.598 5335131.212 520.033 692501.598 5335131.212 521.91 692501.598 5335131.212 532.53 692502.654 5335131.06 532.53 692502.654 5335131.06 519.714 692501.598 5335131.212 520.033</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_e6fcd242-aa01-4190-a532-35717d6c9aac_2">
<gen:stringAttribute name="Flaeche">
<gen:value>115.362</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.352</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.814</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_e6fcd242-aa01-4190-a532-35717d6c9aac_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692455 5335132.71 511.46 692455 5335132.71 535.814 692453.81 5335137.85 530.837 692453.81 5335137.85 511.46 692455 5335132.71 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_e8e4ed0a-afe8-4bff-9cd6-b2623fd85ade_2">
<gen:stringAttribute name="Flaeche">
<gen:value>40.709</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.054</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.516</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_e8e4ed0a-afe8-4bff-9cd6-b2623fd85ade_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692483.05 5335151.15 511.46 692483.05 5335151.15 530.516 692482.56 5335153.23 530.505 692482.56 5335153.23 511.46 692483.05 5335151.15 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_ed16a6e7-1032-49e3-b656-7e31b54d0b4b_2">
<gen:stringAttribute name="Flaeche">
<gen:value>100.731</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.666</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.129</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_ed16a6e7-1032-49e3-b656-7e31b54d0b4b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692466.77 5335123.75 511.46 692466.77 5335123.75 522.129 692457.6 5335121.49 522.123 692457.6 5335121.49 511.46 692466.77 5335123.75 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_eeea9620-c987-412a-8960-06d625d125e1_2">
<gen:stringAttribute name="Flaeche">
<gen:value>80.988</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>19.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>530.950</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.146</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.608</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_eeea9620-c987-412a-8960-06d625d125e1_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692493.647 5335157.27 530.95 692495.728 5335148.206 530.95 692495.728 5335148.206 526.21 692494.556 5335153.31 522.62 692494.556 5335153.31 520.27 692493.647 5335157.27 518.608 692493.647 5335157.27 530.95</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_ef460dd0-d8d0-4254-b00d-47d8c9620348_2">
<gen:stringAttribute name="Flaeche">
<gen:value>48.979</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.666</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.129</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_ef460dd0-d8d0-4254-b00d-47d8c9620348_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692471.23 5335124.84 511.46 692471.23 5335124.84 522.127 692466.77 5335123.75 522.129 692466.77 5335123.75 511.46 692471.23 5335124.84 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_f08dcb06-4f10-461c-ac9e-4f2224412e47_2">
<gen:stringAttribute name="Flaeche">
<gen:value>14.251</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.668</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.131</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_f08dcb06-4f10-461c-ac9e-4f2224412e47_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692491.97 5335157.78 511.46 692491.97 5335157.78 522.066 692493.28 5335158.06 522.131 692493.28 5335158.06 511.46 692491.97 5335157.78 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_f1b19d23-04db-4e56-b5c3-0262c9a05747_2">
<gen:stringAttribute name="Flaeche">
<gen:value>16.476</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.621</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.083</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_f1b19d23-04db-4e56-b5c3-0262c9a05747_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692482.13 5335155.27 511.46 692482.13 5335155.27 522.065 692483.64 5335155.63 522.083 692483.64 5335155.63 511.46 692482.13 5335155.27 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_f1cb0770-1382-4617-b484-0a799a4b5279_2">
<gen:stringAttribute name="Flaeche">
<gen:value>12.299</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.259</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>522.721</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_f1cb0770-1382-4617-b484-0a799a4b5279_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.34 5335154.17 511.46 692498.34 5335154.17 522.665 692499.42 5335154.35 522.721 692499.42 5335154.35 511.46 692498.34 5335154.17 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_f3b2f5ae-ee3f-4234-8bba-7c77d58c1b02_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.234</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>20.367</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>531.830</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_f3b2f5ae-ee3f-4234-8bba-7c77d58c1b02_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692500.336 5335128.127 523.36 692500.336 5335128.127 530.95 692499.461 5335127.913 531.83 692499.461 5335127.913 523.36 692500.336 5335128.127 523.36</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_f5f242db-e2c1-43c7-9084-d33cff426efc_2">
<gen:stringAttribute name="Flaeche">
<gen:value>201.780</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.768</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.230</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>-0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.460</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_f5f242db-e2c1-43c7-9084-d33cff426efc_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692456.37 5335126.8 511.46 692457.6 5335121.49 511.46 692457.6 5335121.49 522.123 692456.422 5335126.574 524.51 692456.422 5335126.574 530.76 692455.1 5335132.281 536.23 692455 5335132.71 535.814 692455 5335132.71 511.46 692456.37 5335126.8 511.46</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006508_fae36168-ac2d-4528-a9aa-f2047ea5852e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>10.986</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.448</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_fae36168-ac2d-4528-a9aa-f2047ea5852e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692499.871 5335130.155 521.91 692499.871 5335130.155 530.95 692499.871 5335130.155 532.53 692500.636 5335130.85 532.53 692500.636 5335130.85 521.91 692499.871 5335130.155 521.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_040e8515-e095-4ca3-9db2-5f437e0c198a_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>40.599</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>257.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.454</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>25.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.820</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_040e8515-e095-4ca3-9db2-5f437e0c198a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692484.927 5335142.559 535.02 692486.1 5335144.346 536.82 692484.275 5335145.399 535.02 692484.927 5335142.559 535.02</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_07cef253-ef32-46cf-be90-14606da8515a_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>53.934</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>41.551</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>16.907</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.247</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.709</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_07cef253-ef32-46cf-be90-14606da8515a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692506.643 5335147.434 526.21 692510.266 5335150.179 522.964 692509.61 5335151.08 522.79 692508.75 5335151.99 522.709 692507.77 5335152.79 522.747 692507.43 5335152.989 522.802 692505.325 5335148.602 526.21 692506.643 5335147.434 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_0859f3f6-c871-4329-8235-bcc8298db3dd_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.923</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>257.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>78.929</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.738</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.200</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.968</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>530.430</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_0859f3f6-c871-4329-8235-bcc8298db3dd_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692490.27 5335146.868 536.2 692488.168 5335156.024 536.2 692484.475 5335155.119 532.645 692484.45 5335154.92 532.58 692483.94 5335154.76 532.082 692483.868 5335154.97 532.06 692482.262 5335154.577 530.515 692482.29 5335154.43 530.509 692482.21 5335154.398 530.43 692482.481 5335153.216 530.43 692482.56 5335153.23 530.505 692483.05 5335151.15 530.516 692482.961 5335151.128 530.43 692484.275 5335145.399 530.43 692490.27 5335146.868 536.2</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_0a30c205-4f46-442e-aabb-33df51653461_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>45.869</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>25.587</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>8.239</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_0a30c205-4f46-442e-aabb-33df51653461_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692505.325 5335148.602 529.96 692503.487 5335149.482 529.96 692501.982 5335143.769 535.59 692505.325 5335148.602 529.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_0e93a3b9-ab67-46c4-aabf-0b58b1ee5c36_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>53.604</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>292.106</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.827</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.508</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.371</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.834</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_0e93a3b9-ab67-46c4-aabf-0b58b1ee5c36_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692487.717 5335155.913 523.97 692485.012 5335156.778 521.883 692484.77 5335156.36 521.834 692484.604 5335155.842 521.864 692487.717 5335155.913 523.97</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_16b2535d-9ad7-4436-9055-652a84423c14_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>48.445</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>163.408</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.271</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>5.528</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>516.990</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>4.401</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>515.863</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_16b2535d-9ad7-4436-9055-652a84423c14_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692500.518 5335127.332 516.269 692500.57 5335127.35 516.271 692500.67 5335126.92 515.88 692501.78 5335127.24 515.871 692502.75 5335127.52 515.863 692502.656 5335128.065 516.35 692502.157 5335127.943 516.373 692501.208 5335127.886 516.564 692500.336 5335128.127 516.99 692500.518 5335127.332 516.269</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_17e9e09e-2dca-49e9-ae17-a19a16d8d8c7_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>44.534</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>187.099</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.149</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.018</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.480</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.697</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.160</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_17e9e09e-2dca-49e9-ae17-a19a16d8d8c7_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692495.09 5335124.55 522.16 692495.186 5335124.577 522.2 692495.114 5335126.847 524.48 692493.876 5335124.733 522.192 692495.09 5335124.55 522.16</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_182a36d9-3382-4eb7-a868-995db368666c_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>40.599</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>77.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.454</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>25.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.820</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_182a36d9-3382-4eb7-a868-995db368666c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.871 5335136.976 535.02 692498.22 5335139.816 535.02 692497.047 5335138.029 536.82 692498.871 5335136.976 535.02</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_1b66eaa5-e3c1-4e5c-95fd-864debcb3007_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>38.987</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.573</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>25.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.820</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_1b66eaa5-e3c1-4e5c-95fd-864debcb3007_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.871 5335136.976 535.02 692497.047 5335138.029 536.82 692495.874 5335136.241 535.02 692498.871 5335136.976 535.02</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_1d15e50d-bf78-4227-94f6-c31ecba923df_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>18.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>257.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.349</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.198</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.660</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_1d15e50d-bf78-4227-94f6-c31ecba923df_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692488.59 5335125.35 521.66 692489.151 5335125.456 523.36 692488.849 5335126.774 523.36 692488.32 5335126.66 521.749 692488.59 5335125.35 521.66</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_1fe8f35f-12f2-4426-a818-0887153eeed6_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>40.599</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>77.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.454</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>25.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.820</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_1fe8f35f-12f2-4426-a818-0887153eeed6_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692496.916 5335145.497 535.02 692496.264 5335148.337 535.02 692495.091 5335146.55 536.82 692496.916 5335145.497 535.02</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_222e12dd-dc30-4c71-bbc0-01d2a05fccff_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>28.257</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.637</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.214</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.677</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_222e12dd-dc30-4c71-bbc0-01d2a05fccff_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692499.66 5335127.03 521.677 692500.05 5335127.17 521.757 692500.518 5335127.332 521.843 692500.336 5335128.127 523.36 692499.461 5335127.913 523.36 692499.66 5335127.03 521.677</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_263d2faa-ec15-4957-b3bc-2c48dcf47f17_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>50.043</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>223.284</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.458</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.018</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.480</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.672</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.134</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_263d2faa-ec15-4957-b3bc-2c48dcf47f17_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692492.88 5335125.17 522.174 692492.919 5335125.152 522.186 692495.114 5335126.847 524.48 692491.873 5335126.053 522.134 692492.88 5335125.17 522.174</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_275e544a-af76-4e40-a3f0-bb07bd0d7511_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>37.576</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>303.267</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>22.117</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>37.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>548.950</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_275e544a-af76-4e40-a3f0-bb07bd0d7511_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692484.927 5335142.559 540.75 692491.573 5335141.188 548.95 692487.273 5335146.134 540.75 692484.927 5335142.559 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_27741fdb-82b8-4e1e-ba87-3f7df4345b0b_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>45.557</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>89.587</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>6.600</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_27741fdb-82b8-4e1e-ba87-3f7df4345b0b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.733 5335142.339 529.96 692507.721 5335143.981 529.96 692501.982 5335143.769 535.59 692507.733 5335142.339 529.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_2eeb2550-2eee-4132-a7e6-fd03a9e2378b_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>32.395</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>88.572</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.667</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>534.930</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.088</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.551</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_2eeb2550-2eee-4132-a7e6-fd03a9e2378b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692503.415 5335128.943 532.674 692503.49 5335129.05 532.551 692503.404 5335130.119 532.644 692501.968 5335129.547 534.93 692503.415 5335128.943 532.674</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_2f81174c-3fb0-4abc-ba8d-86b7cc2ed522_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>44.005</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>164.056</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.780</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.018</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.480</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.737</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.200</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_2f81174c-3fb0-4abc-ba8d-86b7cc2ed522_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692495.51 5335124.67 522.2 692496.872 5335125.063 522.204 692495.114 5335126.847 524.48 692495.186 5335124.577 522.2 692495.51 5335124.67 522.2</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_2fc33383-ce57-4e53-8190-b743dcde2618_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>33.889</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>176.532</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.374</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>534.930</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_2fc33383-ce57-4e53-8190-b743dcde2618_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692502.157 5335127.943 532.53 692501.968 5335129.547 534.93 692501.208 5335127.886 532.53 692502.157 5335127.943 532.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_3673c990-b43b-4ab6-8915-cdc336b3d0b0_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>45.462</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>77.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>4.215</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_3673c990-b43b-4ab6-8915-cdc336b3d0b0_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.54 5335145.131 529.96 692507.305 5335146.154 529.96 692501.982 5335143.769 535.59 692507.54 5335145.131 529.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_3691a00f-a8cf-44a2-97e9-bc25c216c434_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>37.983</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>29.990</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>21.915</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>37.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>548.950</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_3691a00f-a8cf-44a2-97e9-bc25c216c434_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692493.267 5335147.603 540.75 692491.573 5335141.188 548.95 692496.916 5335145.497 540.75 692493.267 5335147.603 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_381396e1-aef9-4025-b544-9396410c46f7_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>35.402</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>31.043</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>37.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>548.950</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_381396e1-aef9-4025-b544-9396410c46f7_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692495.874 5335136.241 540.75 692491.573 5335141.188 548.95 692489.88 5335134.772 540.75 692495.874 5335136.241 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_38ed53ea-20ea-470b-9ac3-3be3d3942e4a_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>55.757</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>275.102</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.367</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.508</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.820</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_38ed53ea-20ea-470b-9ac3-3be3d3942e4a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692487.717 5335155.913 523.97 692484.604 5335155.842 521.864 692484.54 5335155.64 521.833 692484.475 5335155.119 521.82 692487.717 5335155.913 523.97</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_3fbb2a54-e358-448e-a1bb-424004c9c34c_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>36.963</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>77.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>29.907</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>37.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>548.950</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_3fbb2a54-e358-448e-a1bb-424004c9c34c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692496.916 5335145.497 540.75 692491.573 5335141.188 548.95 692498.22 5335139.816 540.75 692496.916 5335145.497 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_40fa304e-0463-4ea1-82d8-c6e17e4d8bd8_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>51.503</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>358.172</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.732</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.508</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.406</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.868</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_40fa304e-0463-4ea1-82d8-c6e17e4d8bd8_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692488.872 5335158.579 521.88 692487.847 5335158.562 521.868 692487.717 5335155.913 523.97 692488.872 5335158.579 521.88</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_42b69ebe-20c9-49b3-a82c-903aad2924c9_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>47.713</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>137.921</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.026</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.018</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.480</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.717</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.180</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_42b69ebe-20c9-49b3-a82c-903aad2924c9_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692496.872 5335125.063 522.204 692496.93 5335125.08 522.18 692497.77 5335125.84 522.181 692495.114 5335126.847 524.48 692496.872 5335125.063 522.204</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_439a507a-1469-40d8-8cd5-76efb9839c8a_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>53.814</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>146.840</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>17.387</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.158</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.620</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_439a507a-1469-40d8-8cd5-76efb9839c8a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692508.603 5335135.163 522.62 692508.53 5335135.23 522.69 692508.709 5335135.383 522.712 692506.03 5335139.344 526.21 692504.525 5335138.361 526.21 692505.489 5335133.128 522.62 692508.603 5335135.163 522.62</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_44d61b0a-3dca-4655-9aec-aa0f50cf827a_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.555</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>129.926</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>7.653</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_44d61b0a-3dca-4655-9aec-aa0f50cf827a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692506.03 5335139.344 529.96 692507.23 5335140.778 529.96 692501.982 5335143.769 535.59 692506.03 5335139.344 529.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_47950fef-80b7-4626-9e97-4313bdc18a3e_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>66.494</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>77.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.570</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.808</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>520.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.126</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.588</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_47950fef-80b7-4626-9e97-4313bdc18a3e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.313 5335154.231 518.588 692497.96 5335155.02 518.661 692497.728 5335155.322 518.73 692494.556 5335153.31 520.27 692498.313 5335154.231 518.588</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_498f742d-9720-4e8e-8122-a787e14346d4_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>67.427</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>48.183</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.296</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.808</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>520.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.246</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.708</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_498f742d-9720-4e8e-8122-a787e14346d4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692497.728 5335155.322 518.73 692497.29 5335155.89 518.708 692496.931 5335156.121 518.755 692494.556 5335153.31 520.27 692497.728 5335155.322 518.73</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_4ca207e3-4491-4a24-a911-7817c34e0eb9_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>45.364</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>81.034</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>4.664</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_4ca207e3-4491-4a24-a911-7817c34e0eb9_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.721 5335143.981 529.96 692507.54 5335145.131 529.96 692501.982 5335143.769 535.59 692507.721 5335143.981 529.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_4f5f9f51-604b-47d5-b1fa-ae6df9928244_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>37.983</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>209.990</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>21.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>37.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>548.950</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_4f5f9f51-604b-47d5-b1fa-ae6df9928244_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692489.88 5335134.772 540.75 692491.573 5335141.188 548.95 692486.231 5335136.878 540.75 692489.88 5335134.772 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_52ccc7ce-0f28-4ab7-82d1-5ced6ad212b5_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>52.907</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>107.854</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>14.253</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.180</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.642</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_52ccc7ce-0f28-4ab7-82d1-5ced6ad212b5_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692511.347 5335138.593 522.74 692512.24 5335140.94 522.642 692512.314 5335141.668 522.758 692507.733 5335142.339 526.21 692507.23 5335140.778 526.21 692511.347 5335138.593 522.74</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_539ce256-6fbe-4fc1-ad49-29c279176760_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>67.244</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>199.856</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.048</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.043</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_539ce256-6fbe-4fc1-ad49-29c279176760_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692453.74 5335138.17 524.407 692453.793 5335137.93 524.51 692484.275 5335145.399 524.51 692482.961 5335151.128 522.045 692466.59 5335147.12 522.043 692461.76 5335145.92 522.05 692452.47 5335143.63 522.056 692453.74 5335138.17 524.407</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_54407ccc-ceff-430a-9feb-7ff0c3f08242_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>28.561</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.346</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.603</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.065</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_54407ccc-ceff-430a-9feb-7ff0c3f08242_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692482.262 5335154.577 523.36 692483.868 5335154.97 523.36 692483.64 5335155.63 522.083 692482.13 5335155.27 522.065 692482.262 5335154.577 523.36</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_560d6b42-1597-402d-8601-2bdcab7922f8_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>47.338</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>241.762</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>5.967</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.388</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.850</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.516</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.979</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_560d6b42-1597-402d-8601-2bdcab7922f8_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692504.721 5335130.496 519.009 692507.443 5335131.942 521.85 692506.464 5335133.766 521.85 692505.489 5335133.128 520.78 692504.63 5335130.596 518.979 692504.721 5335130.496 519.009</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_575f6d4e-a4b5-4aa6-8e68-767bbf4c670d_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>50.224</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>336.370</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.294</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.508</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.380</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.842</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_575f6d4e-a4b5-4aa6-8e68-767bbf4c670d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692487.717 5335155.913 523.97 692487.141 5335158.424 521.863 692487 5335158.39 521.842 692486.423 5335158.131 521.847 692487.717 5335155.913 523.97</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_5859e9ef-adcb-4b34-a673-c1092e9c9314_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>50.410</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>329.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.649</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.508</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.373</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.836</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_5859e9ef-adcb-4b34-a673-c1092e9c9314_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692487.717 5335155.913 523.97 692486.423 5335158.131 521.847 692486.31 5335158.08 521.836 692485.62 5335157.56 521.916 692487.717 5335155.913 523.97</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_58ffb4a7-5f01-4fcc-b7db-2c0ce3f5c60a_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.401</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>107.854</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>6.695</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_58ffb4a7-5f01-4fcc-b7db-2c0ce3f5c60a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.23 5335140.778 529.96 692507.733 5335142.339 529.96 692501.982 5335143.769 535.59 692507.23 5335140.778 529.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_5a361215-2458-4995-873a-db48ee36fc3e_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>37.775</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>317.758</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.570</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>534.930</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_5a361215-2458-4995-873a-db48ee36fc3e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.968 5335129.547 534.93 692500.636 5335130.85 532.53 692499.871 5335130.155 532.53 692501.968 5335129.547 534.93</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_625a8257-b160-4150-bbbb-a651d7e302cf_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>54.994</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>25.587</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>14.841</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.292</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.754</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_625a8257-b160-4150-bbbb-a651d7e302cf_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692505.325 5335148.602 526.21 692507.43 5335152.989 522.802 692506.73 5335153.4 522.754 692505.54 5335153.86 522.824 692504.707 5335154.114 522.916 692503.487 5335149.482 526.21 692505.325 5335148.602 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_68c077dc-3164-4cfb-918e-968900651d71_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>45.680</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>77.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>66.996</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.738</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.200</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>530.950</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_68c077dc-3164-4cfb-918e-968900651d71_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.335 5335136.844 530.95 692493.113 5335135.565 536.2 692495.114 5335126.847 536.2 692498.489 5335127.675 532.806 692498.57 5335127.88 532.685 692499.43 5335128.05 531.829 692499.461 5335127.913 531.83 692500.336 5335128.127 530.95 692499.871 5335130.155 530.95 692498.335 5335136.844 530.95</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_73033c50-b087-4273-bb96-4737d27b7b71_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>36.925</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>195.482</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>534.930</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_73033c50-b087-4273-bb96-4737d27b7b71_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.208 5335127.886 532.53 692501.968 5335129.547 534.93 692500.336 5335128.127 532.53 692501.208 5335127.886 532.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_73d5596d-c108-4b1c-86c6-9c23b3e2e023_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>33.731</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.232</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.153</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>534.930</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_73d5596d-c108-4b1c-86c6-9c23b3e2e023_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692502.157 5335127.943 532.53 692502.656 5335128.065 532.53 692502.65 5335128.1 532.582 692502.86 5335128.15 532.58 692502.899 5335128.205 532.647 692501.968 5335129.547 534.93 692502.157 5335127.943 532.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_73f8cfd6-8518-4c50-b7d3-dc479045d3be_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>67.421</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>32.105</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.730</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.808</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>520.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.290</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.752</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_73f8cfd6-8518-4c50-b7d3-dc479045d3be_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692496.931 5335156.121 518.755 692496.42 5335156.45 518.752 692496.162 5335156.539 518.778 692494.556 5335153.31 520.27 692496.931 5335156.121 518.755</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_757ddf5a-5387-421d-bde1-f3691306522b_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>33.987</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>63.546</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>0.705</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>534.930</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_757ddf5a-5387-421d-bde1-f3691306522b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692503.404 5335130.119 532.644 692503.39 5335130.3 532.543 692503.254 5335130.593 532.53 692501.968 5335129.547 534.93 692503.404 5335130.119 532.644</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_773bc449-71a1-4666-985d-d1c4c6946958_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>50.999</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>108.777</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.602</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.018</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.480</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.645</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.107</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_773bc449-71a1-4666-985d-d1c4c6946958_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692497.77 5335125.84 522.181 692498.489 5335127.675 522.107 692495.114 5335126.847 524.48 692497.77 5335125.84 522.181</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_78a90eca-c767-483c-b188-20d08dbc492e_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>37.576</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>123.267</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>22.117</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>37.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>548.950</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_78a90eca-c767-483c-b188-20d08dbc492e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.22 5335139.816 540.75 692491.573 5335141.188 548.95 692495.874 5335136.241 540.75 692498.22 5335139.816 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_7a5d0f89-9eae-464a-aa55-81f807537daa_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>38.987</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.573</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>25.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.820</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_7a5d0f89-9eae-464a-aa55-81f807537daa_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692486.1 5335144.346 536.82 692487.273 5335146.134 535.02 692484.275 5335145.399 535.02 692486.1 5335144.346 536.82</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_7ae50019-e5df-415b-b2e7-4254a0c4dac0_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>31.296</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.525</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.987</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_7ae50019-e5df-415b-b2e7-4254a0c4dac0_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692489.46 5335124.63 522.031 692491 5335124.98 521.987 692490.894 5335125.813 523.36 692489.293 5335125.421 523.36 692489.46 5335124.63 522.031</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_7bdef18a-bfa9-4310-bbcd-3311233ea431_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.667</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>250.130</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.768</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.230</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.298</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>530.760</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_7bdef18a-bfa9-4310-bbcd-3311233ea431_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692484.275 5335145.399 530.76 692453.793 5335137.93 530.76 692453.81 5335137.85 530.837 692455 5335132.71 535.814 692455.1 5335132.281 536.23 692485.572 5335139.748 536.23 692484.275 5335145.399 530.76</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_7cea64e6-e39d-4bd7-b8c2-86f802cab4dd_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>33.615</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>8.203</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.538</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>534.930</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_7cea64e6-e39d-4bd7-b8c2-86f802cab4dd_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.968 5335129.547 534.93 692502.654 5335131.06 532.53 692501.598 5335131.212 532.53 692501.968 5335129.547 534.93</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_7d06fc10-ee8f-4f94-bb58-9e5e782f4389_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>65.417</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>181.290</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.048</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.660</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.123</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_7d06fc10-ee8f-4f94-bb58-9e5e782f4389_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692456.422 5335126.574 524.51 692457.6 5335121.49 522.123 692466.77 5335123.75 522.129 692471.23 5335124.84 522.127 692488.331 5335129.03 522.127 692487.166 5335134.107 524.51 692456.422 5335126.574 524.51</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_7fc5558c-76cd-4b38-8185-d8ef819928f8_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>31.759</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.085</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.604</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.066</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_7fc5558c-76cd-4b38-8185-d8ef819928f8_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692492.118 5335156.992 523.36 692493.549 5335157.342 523.36 692493.28 5335158.06 522.131 692491.97 5335157.78 522.066 692492.118 5335156.992 523.36</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_819ab0c5-5956-41ea-bfe5-71f99211a9ad_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>35.133</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>339.380</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.507</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>534.930</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_819ab0c5-5956-41ea-bfe5-71f99211a9ad_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.968 5335129.547 534.93 692501.598 5335131.212 532.53 692500.636 5335130.85 532.53 692501.968 5335129.547 534.93</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_840239f8-afbe-4f5e-af33-0eeb71157811_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.191</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.448</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.910</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.448</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.910</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_840239f8-afbe-4f5e-af33-0eeb71157811_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692499.871 5335130.155 521.91 692500.636 5335130.85 521.91 692501.598 5335131.212 521.91 692501.389 5335132.124 521.91 692499.524 5335131.667 521.91 692499.871 5335130.155 521.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_844c62d1-3c7d-490b-8510-60981f698b48_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>49.096</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>61.762</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>8.038</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.388</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.850</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.557</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>519.019</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_844c62d1-3c7d-490b-8510-60981f698b48_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.443 5335131.942 521.85 692510.211 5335133.695 519.019 692508.603 5335135.163 519.645 692506.464 5335133.766 521.85 692507.443 5335131.942 521.85</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_86660993-e307-4ef9-8b69-0dd312934e0a_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>38.483</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>257.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.189</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>534.930</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_86660993-e307-4ef9-8b69-0dd312934e0a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692500.336 5335128.127 532.53 692501.968 5335129.547 534.93 692499.871 5335130.155 532.53 692500.336 5335128.127 532.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_89630b02-160d-4fb3-92d8-68114d37ba2f_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.784</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>204.034</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.752</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>13.018</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>524.480</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.718</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.180</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_89630b02-160d-4fb3-92d8-68114d37ba2f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692493.83 5335124.74 522.18 692493.876 5335124.733 522.192 692495.114 5335126.847 524.48 692492.919 5335125.152 522.186 692493.83 5335124.74 522.18</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_8ca620fa-d418-42d1-b99e-d9e5fe188531_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.944</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>77.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>71.951</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.738</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.200</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>530.950</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_8ca620fa-d418-42d1-b99e-d9e5fe188531_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692495.728 5335148.206 530.95 692493.647 5335157.27 530.95 692493.58 5335157.26 531.013 692493.549 5335157.342 531.024 692492.118 5335156.992 532.401 692492.16 5335156.77 532.409 692491.5 5335156.54 533.058 692491.289 5335156.789 533.198 692488.168 5335156.024 536.2 692490.27 5335146.868 536.2 692495.728 5335148.206 530.95</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_90f836b7-238a-46a7-b478-8f18d891b3b5_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>55.947</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>40.117</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.158</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.620</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_90f836b7-238a-46a7-b478-8f18d891b3b5_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692505.489 5335133.128 522.62 692504.525 5335138.361 526.21 692498.335 5335136.844 526.21 692499.524 5335131.667 522.62 692505.489 5335133.128 522.62</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_9506147c-32f6-42c2-924b-9fcc69740faa_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>55.568</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>35.215</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.158</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.620</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_9506147c-32f6-42c2-924b-9fcc69740faa_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.158 5335149.536 526.21 692500.04 5335154.411 522.782 692499.42 5335154.35 522.721 692498.34 5335154.17 522.665 692498.313 5335154.231 522.62 692494.556 5335153.31 522.62 692495.728 5335148.206 526.21 692501.158 5335149.536 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_9ada6dc3-f320-4c8b-b622-a1b7a5d20db6_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.960</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>251.400</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.768</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.230</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>19.298</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>530.760</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_9ada6dc3-f320-4c8b-b622-a1b7a5d20db6_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692456.422 5335126.574 530.76 692486.883 5335134.038 530.76 692485.572 5335139.748 536.23 692455.1 5335132.281 536.23 692456.422 5335126.574 530.76</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_9c817bf5-6bbd-4eeb-9fce-3cff8542902f_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.135</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>42.138</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_9c817bf5-6bbd-4eeb-9fce-3cff8542902f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692498.871 5335136.976 529.96 692504.525 5335138.361 529.96 692501.982 5335143.769 535.59 692497.561 5335142.686 535.59 692498.871 5335136.976 529.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_9e678d6f-da3b-48c7-8505-414ff2609543_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>54.730</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>1.328</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>21.275</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.209</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.672</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_9e678d6f-da3b-48c7-8505-414ff2609543_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.158 5335149.536 526.21 692503.487 5335149.482 526.21 692504.707 5335154.114 522.916 692504.16 5335154.28 522.807 692502.49 5335154.51 522.672 692500.95 5335154.5 522.704 692500.04 5335154.411 522.782 692501.158 5335149.536 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_a5fa3d38-0834-42b6-93d1-0fcd5b342033_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>47.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>78.354</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>6.728</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.388</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.850</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.474</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.937</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_a5fa3d38-0834-42b6-93d1-0fcd5b342033_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692510.906 5335130.636 518.961 692510.93 5335130.65 518.937 692510.26 5335133.65 518.983 692510.211 5335133.695 519.019 692507.443 5335131.942 521.85 692510.906 5335130.636 518.961</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_ab966bc8-480e-425c-80f6-1e5517b9ee7f_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>36.963</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>257.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>29.907</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>37.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>548.950</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_ab966bc8-480e-425c-80f6-1e5517b9ee7f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692486.231 5335136.878 540.75 692491.573 5335141.188 548.95 692484.927 5335142.559 540.75 692486.231 5335136.878 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_ac6fcea9-c430-43c4-86bd-707e682a269d_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>38.987</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.573</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>25.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.820</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_ac6fcea9-c430-43c4-86bd-707e682a269d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692489.88 5335134.772 535.02 692488.056 5335135.825 536.82 692486.883 5335134.038 535.02 692489.88 5335134.772 535.02</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_ad7b11ec-b70c-4c25-8b60-ee201e5cb893_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.699</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>257.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>74.863</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.738</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.200</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.968</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>530.430</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_ad7b11ec-b70c-4c25-8b60-ee201e5cb893_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692487.166 5335134.107 530.43 692488.331 5335129.03 530.43 692488.37 5335129.04 530.468 692488.97 5335126.8 530.547 692488.849 5335126.774 530.43 692489.151 5335125.456 530.43 692489.28 5335125.48 530.553 692489.293 5335125.421 530.553 692490.894 5335125.813 532.106 692490.88 5335125.92 532.116 692491.82 5335126.1 533.017 692491.873 5335126.053 533.056 692495.114 5335126.847 536.2 692493.113 5335135.565 536.2 692487.166 5335134.107 530.43</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_b21a7223-2999-4e06-88bf-bebc4da7b2f1_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>67.308</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>18.153</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.163</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.808</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>520.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.206</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.668</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_b21a7223-2999-4e06-88bf-bebc4da7b2f1_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692494.556 5335153.31 520.27 692496.162 5335156.539 518.778 692495.55 5335156.75 518.774 692494.71 5335156.76 518.879 692494.555 5335157.342 518.668 692494.556 5335153.31 520.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_b4116bb2-b4fe-486a-9c40-60bd6458186f_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>67.753</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.007</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>8.808</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>520.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.146</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.608</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_b4116bb2-b4fe-486a-9c40-60bd6458186f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692494.556 5335153.31 520.27 692494.555 5335157.342 518.668 692494.54 5335157.4 518.644 692493.647 5335157.27 518.608 692494.556 5335153.31 520.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_b447bf90-1b2d-43cd-95b2-72d85ad4a15f_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>45.842</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>38.756</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_b447bf90-1b2d-43cd-95b2-72d85ad4a15f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692497.561 5335142.686 535.59 692501.982 5335143.769 535.59 692501.158 5335149.536 529.96 692496.264 5335148.337 529.96 692497.561 5335142.686 535.59</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_b4c13952-c37e-4288-83fe-652a2ecd7cee_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.341</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>226.977</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>6.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.388</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.850</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.524</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.986</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_b4c13952-c37e-4288-83fe-652a2ecd7cee_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692506.71 5335128.33 518.986 692506.771 5335128.342 519.037 692507.443 5335131.942 521.85 692504.721 5335130.496 519.009 692506.71 5335128.33 518.986</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_ba3c503e-15a4-4073-9072-b7dc0e500af3_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>53.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>81.034</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>7.345</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.224</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.687</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_ba3c503e-15a4-4073-9072-b7dc0e500af3_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.721 5335143.981 526.21 692512.379 5335144.964 522.691 692512.2 5335146.13 522.687 692512.16 5335146.263 522.701 692507.54 5335145.131 526.21 692507.721 5335143.981 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_bb0420e2-971a-428f-9eb3-979e6089bdfd_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>35.401</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>31.043</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>37.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>548.950</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>29.288</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>540.750</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_bb0420e2-971a-428f-9eb3-979e6089bdfd_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692487.273 5335146.134 540.75 692491.573 5335141.188 548.95 692493.267 5335147.603 540.75 692487.273 5335146.134 540.75</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_bc23953d-86c0-4302-ad32-d10b7489bc51_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>52.967</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>89.587</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>14.654</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.112</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.575</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_bc23953d-86c0-4302-ad32-d10b7489bc51_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692512.54 5335143.91 522.575 692512.379 5335144.964 522.691 692507.721 5335143.981 526.21 692507.733 5335142.339 526.21 692512.314 5335141.668 522.758 692512.54 5335143.91 522.575</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_bdae1ae2-cb3e-478d-98ae-e31d5b953f38_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>57.268</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>50.073</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>2.512</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.508</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.386</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.848</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_bdae1ae2-cb3e-478d-98ae-e31d5b953f38_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692491.289 5335156.789 521.848 692490.457 5335157.768 521.854 692487.717 5335155.913 523.97 692491.289 5335156.789 521.848</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_c41411a4-3eb6-44a9-8751-3af37f196121_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>54.176</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>28.267</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.226</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.508</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.381</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.843</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_c41411a4-3eb6-44a9-8751-3af37f196121_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692490.457 5335157.768 521.854 692490.43 5335157.8 521.843 692488.92 5335158.58 521.863 692488.872 5335158.579 521.88 692487.717 5335155.913 523.97 692490.457 5335157.768 521.854</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_c7733056-c3c5-4336-9d6e-ff4791626ac5_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>54.067</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>62.659</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>11.121</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.391</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.854</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_c7733056-c3c5-4336-9d6e-ff4791626ac5_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.305 5335146.154 526.21 692511.507 5335148.039 522.877 692511.15 5335148.8 522.854 692510.52 5335149.83 522.916 692510.266 5335150.179 522.964 692506.643 5335147.434 526.21 692507.305 5335146.154 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_c8e7a891-7a09-4645-b432-c9faf8946af4_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>52.731</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>129.926</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>18.114</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.053</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.516</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_c8e7a891-7a09-4645-b432-c9faf8946af4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692509.88 5335136.38 522.516 692511.27 5335138.39 522.686 692511.347 5335138.593 522.74 692507.23 5335140.778 526.21 692506.03 5335139.344 526.21 692508.709 5335135.383 522.712 692509.88 5335136.38 522.516</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_ce3caa41-1dd1-4788-9fa7-199fc326373d_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.430</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>146.840</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>7.342</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_ce3caa41-1dd1-4788-9fa7-199fc326373d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692504.525 5335138.361 529.96 692506.03 5335139.344 529.96 692501.982 5335143.769 535.59 692504.525 5335138.361 529.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_daa3a916-e599-4255-93a6-030686eedfc0_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>52.361</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>305.345</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.690</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.508</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.402</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.864</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_daa3a916-e599-4255-93a6-030686eedfc0_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692487.717 5335155.913 523.97 692485.62 5335157.56 521.916 692485.14 5335157 521.864 692485.012 5335156.778 521.883 692487.717 5335155.913 523.97</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_db3fb65f-6246-42b8-8204-8c9602ee9c0e_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>40.599</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>257.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.454</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>25.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.820</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_db3fb65f-6246-42b8-8204-8c9602ee9c0e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692486.883 5335134.038 535.02 692488.056 5335135.825 536.82 692486.231 5335136.878 535.02 692486.883 5335134.038 535.02</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_db828987-0df4-44fd-b9f9-9344d7b1e107_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>23.377</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>257.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.594</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>11.898</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.360</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.617</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.080</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_db828987-0df4-44fd-b9f9-9344d7b1e107_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692481.95 5335153.12 522.112 692482.481 5335153.216 523.36 692482.21 5335154.398 523.36 692481.69 5335154.19 522.08 692481.95 5335153.12 522.112</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_e075b1a1-37dd-44e4-bf04-a652decaad90_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>45.969</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>62.659</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>5.837</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_e075b1a1-37dd-44e4-bf04-a652decaad90_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.305 5335146.154 529.96 692506.643 5335147.434 529.96 692501.982 5335143.769 535.59 692507.305 5335146.154 529.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_e075dbdf-2351-41be-b448-4ffbe6df9af8_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>53.581</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>77.074</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>8.586</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>14.748</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>526.210</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>11.238</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>522.701</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_e075dbdf-2351-41be-b448-4ffbe6df9af8_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.54 5335145.131 526.21 692512.16 5335146.263 522.701 692511.84 5335147.33 522.755 692511.507 5335148.039 522.877 692507.305 5335146.154 526.21 692507.54 5335145.131 526.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_e8b50866-0f53-48b0-8bf2-67f6e16dfcfd_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>45.589</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>1.328</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>9.370</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_e8b50866-0f53-48b0-8bf2-67f6e16dfcfd_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.982 5335143.769 535.59 692503.487 5335149.482 529.96 692501.158 5335149.536 529.96 692501.982 5335143.769 535.59</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_ecc3ff64-ead3-42b1-80c4-2c9afacc8d4b_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>51.383</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>166.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>8.275</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>9.318</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>520.780</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.516</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.979</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_ecc3ff64-ead3-42b1-80c4-2c9afacc8d4b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692501.598 5335131.212 520.033 692502.654 5335131.06 519.714 692503.254 5335130.593 519.238 692503.39 5335130.3 518.985 692504.58 5335130.65 519.03 692504.63 5335130.596 518.979 692505.489 5335133.128 520.78 692501.389 5335132.124 520.78 692501.598 5335131.212 520.033</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_f09df779-6084-44df-9521-96c397eaaba2_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>50.709</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>348.486</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.206</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>12.508</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>523.970</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>10.391</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>521.853</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_f09df779-6084-44df-9521-96c397eaaba2_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692487.717 5335155.913 523.97 692487.847 5335158.562 521.868 692487.75 5335158.56 521.853 692487.25 5335158.45 521.86 692487.141 5335158.424 521.863 692487.717 5335155.913 523.97</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_f1222130-c1ba-47bb-a965-1a3a61c61665_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>38.987</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>346.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>3.573</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>25.358</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>536.820</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>23.558</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>535.020</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_f1222130-c1ba-47bb-a965-1a3a61c61665_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692493.267 5335147.603 535.02 692495.091 5335146.55 536.82 692496.264 5335148.337 535.02 692493.267 5335147.603 535.02</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_f3b5c47d-25e9-4d90-9485-ca2628de2ade_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>34.054</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>126.132</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.231</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>534.930</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.185</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.647</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_f3b5c47d-25e9-4d90-9485-ca2628de2ade_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692502.899 5335128.205 532.647 692503.415 5335128.943 532.674 692501.968 5335129.547 534.93 692502.899 5335128.205 532.647</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_f4fe5448-f446-4099-9a1d-3f7ea63b38f7_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>44.710</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>150.070</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>9.817</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>10.388</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>521.850</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>7.470</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>518.932</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_f4fe5448-f446-4099-9a1d-3f7ea63b38f7_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692507.08 5335128.4 518.932 692510.906 5335130.636 518.961 692507.443 5335131.942 521.85 692506.771 5335128.342 519.037 692507.08 5335128.4 518.932</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_fbef0479-4636-4676-8335-036fd878902f_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>46.023</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>41.551</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>7.138</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>24.128</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>535.590</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>18.498</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>529.960</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_fbef0479-4636-4676-8335-036fd878902f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692506.643 5335147.434 529.96 692505.325 5335148.602 529.96 692501.982 5335143.769 535.59 692506.643 5335147.434 529.96</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006508_fd50813b-953f-4b9c-9c47-81f7e5df788a_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>33.952</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>37.875</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>1.099</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>23.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>534.930</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>21.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>532.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006508_fd50813b-953f-4b9c-9c47-81f7e5df788a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692503.254 5335130.593 532.53 692502.654 5335131.06 532.53 692501.968 5335129.547 534.93 692503.254 5335130.593 532.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:address>
<Address><xalAddress><xAL:AddressDetails>
 <xAL:Country>
  <xAL:CountryName>Germany</xAL:CountryName>
  <xAL:Locality Type="Town">
   <xAL:LocalityName>München</xAL:LocalityName>
   <xAL:Thoroughfare Type="Street">
    <xAL:ThoroughfareName>St.-Anna-Platz 5</xAL:ThoroughfareName>
   </xAL:Thoroughfare>
  </xAL:Locality>
 </xAL:Country>
</xAL:AddressDetails></xalAddress>
</Address>
</bldg:address>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006936">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSezxM</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>513.828</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>510.268</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>513.380</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_2000</bldg:function>
<bldg:roofType>1000</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">3.56</bldg:measuredHeight>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006936_61e8982f-b7d6-44f8-84f0-4cdc43d576c2_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006936_37e89d20-d3e8-436b-82e7-e0a3fd947ab6_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006936_591a1f03-4ce9-418d-9b7d-18b5a995d65e_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006936_b6571e6e-8560-46e9-af9d-594173fd1453_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006936_cf887e36-f5c4-48fe-be1f-4ddb555b123a_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006936_1f6ef487-82d6-42e0-89b6-de99ef386f46_2_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006936_61e8982f-b7d6-44f8-84f0-4cdc43d576c2_2">
<gen:stringAttribute name="Flaeche">
<gen:value>12.868</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>510.268</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.268</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006936_61e8982f-b7d6-44f8-84f0-4cdc43d576c2_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.1 5335132.26 510.268 692601.99 5335136.01 510.268 692604.73 5335134.65 510.268 692602.82 5335130.88 510.268 692600.1 5335132.26 510.268</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006936_37e89d20-d3e8-436b-82e7-e0a3fd947ab6_2">
<gen:stringAttribute name="Flaeche">
<gen:value>10.176</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.560</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.828</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.268</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006936_37e89d20-d3e8-436b-82e7-e0a3fd947ab6_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692602.82 5335130.88 510.268 692602.82 5335130.88 513.828 692600.1 5335132.26 513.381 692600.1 5335132.26 510.268 692602.82 5335130.88 510.268</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006936_591a1f03-4ce9-418d-9b7d-18b5a995d65e_2">
<gen:stringAttribute name="Flaeche">
<gen:value>15.044</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.560</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.828</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.268</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006936_591a1f03-4ce9-418d-9b7d-18b5a995d65e_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692604.73 5335134.65 510.268 692604.73 5335134.65 513.828 692602.82 5335130.88 513.828 692602.82 5335130.88 510.268 692604.73 5335134.65 510.268</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006936_b6571e6e-8560-46e9-af9d-594173fd1453_2">
<gen:stringAttribute name="Flaeche">
<gen:value>13.069</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.113</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.381</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.268</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006936_b6571e6e-8560-46e9-af9d-594173fd1453_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.1 5335132.26 510.268 692600.1 5335132.26 513.381 692601.99 5335136.01 513.38 692601.99 5335136.01 510.268 692600.1 5335132.26 510.268</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006936_cf887e36-f5c4-48fe-be1f-4ddb555b123a_2">
<gen:stringAttribute name="Flaeche">
<gen:value>10.203</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.560</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.828</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.268</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006936_cf887e36-f5c4-48fe-be1f-4ddb555b123a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692601.99 5335136.01 510.268 692601.99 5335136.01 513.38 692604.73 5335134.65 513.828 692604.73 5335134.65 510.268 692601.99 5335136.01 510.268</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006936_1f6ef487-82d6-42e0-89b6-de99ef386f46_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>81.666</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>296.868</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>13.005</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.560</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.828</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>3.112</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>513.380</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006936_1f6ef487-82d6-42e0-89b6-de99ef386f46_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692602.82 5335130.88 513.828 692604.73 5335134.65 513.828 692601.99 5335136.01 513.38 692600.1 5335132.26 513.381 692602.82 5335130.88 513.828</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006937">
<creationDate>2023-06-05</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSezyH</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>513.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>510.268</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>513.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_2000</bldg:function>
<bldg:roofType>1000</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">2.732</bldg:measuredHeight>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006937_0cdabf50-b82e-4a04-ac08-3ca68abdfc4b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006937_0a84ab7b-be0b-4f34-85cb-ede537291474_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006937_1df41e32-d38c-4cb3-b0cd-377c02216718_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006937_1fe3bc21-ca89-4f36-b47e-392890a4624c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006937_8a2d5557-645e-4dc4-aa10-b8080ea6ad2b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006937_92613603-fd41-4ce3-a404-e4996c8e0737_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006937_bc774ff3-422e-473c-afad-24af474911eb_2_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006937_0cdabf50-b82e-4a04-ac08-3ca68abdfc4b_2">
<gen:stringAttribute name="Flaeche">
<gen:value>55.585</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>510.270</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.270</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006937_0cdabf50-b82e-4a04-ac08-3ca68abdfc4b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.32 5335136.84 510.27 692604.99 5335146.27 510.27 692610.08 5335145.47 510.27 692604.73 5335134.65 510.27 692601.99 5335136.01 510.27 692600.32 5335136.84 510.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006937_0a84ab7b-be0b-4f34-85cb-ede537291474_2">
<gen:stringAttribute name="Flaeche">
<gen:value>32.952</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.732</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.270</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006937_0a84ab7b-be0b-4f34-85cb-ede537291474_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692610.08 5335145.47 510.27 692610.08 5335145.47 513 692604.73 5335134.65 513 692604.73 5335134.65 510.27 692610.08 5335145.47 510.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006937_1df41e32-d38c-4cb3-b0cd-377c02216718_2">
<gen:stringAttribute name="Flaeche">
<gen:value>5.091</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.732</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.270</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006937_1df41e32-d38c-4cb3-b0cd-377c02216718_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692601.99 5335136.01 510.27 692601.99 5335136.01 513 692600.32 5335136.84 513 692600.32 5335136.84 510.27 692601.99 5335136.01 510.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006937_1fe3bc21-ca89-4f36-b47e-392890a4624c_2">
<gen:stringAttribute name="Flaeche">
<gen:value>14.066</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.732</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.270</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006937_1fe3bc21-ca89-4f36-b47e-392890a4624c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692604.99 5335146.27 510.27 692604.99 5335146.27 513 692610.08 5335145.47 513 692610.08 5335145.47 510.27 692604.99 5335146.27 510.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006937_8a2d5557-645e-4dc4-aa10-b8080ea6ad2b_2">
<gen:stringAttribute name="Flaeche">
<gen:value>28.728</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.732</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.270</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006937_8a2d5557-645e-4dc4-aa10-b8080ea6ad2b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692600.32 5335136.84 510.27 692600.32 5335136.84 513 692604.99 5335146.27 513 692604.99 5335146.27 510.27 692600.32 5335136.84 510.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006937_92613603-fd41-4ce3-a404-e4996c8e0737_2">
<gen:stringAttribute name="Flaeche">
<gen:value>8.351</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.732</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.002</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.270</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006937_92613603-fd41-4ce3-a404-e4996c8e0737_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692604.73 5335134.65 510.27 692604.73 5335134.65 513 692601.99 5335136.01 513 692601.99 5335136.01 510.27 692604.73 5335134.65 510.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006937_bc774ff3-422e-473c-afad-24af474911eb_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>55.585</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.732</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>2.732</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>513.000</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006937_bc774ff3-422e-473c-afad-24af474911eb_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692601.99 5335136.01 513 692604.73 5335134.65 513 692610.08 5335145.47 513 692604.99 5335146.27 513 692600.32 5335136.84 513 692601.99 5335136.01 513</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006944">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfn6R</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>513.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>510.850</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>513.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_2000</bldg:function>
<bldg:roofType>1000</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">2.703</bldg:measuredHeight>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006944_802bb309-e66b-46f5-8cce-de29f97593b5_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006944_50b951f7-af1b-40a1-a236-157ac2c4ebdb_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006944_8fbea0eb-01b2-4794-b3c3-08f025e244f1_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006944_9775af53-4048-41e5-9cf1-1d3ba7d1447c_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006944_b0fbba6d-fb2b-4ec1-9ab0-6424d614a2c3_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006944_cade3776-3ad5-4bec-a542-fad4939110b6_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006944_d69850f9-1dba-4cd3-9a0c-9f404ea8ee94_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006944_10911707-fa1d-4075-b959-0a8e0f246481_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006944_802bb309-e66b-46f5-8cce-de29f97593b5">
<gen:stringAttribute name="Flaeche">
<gen:value>26.264</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>510.850</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.850</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006944_802bb309-e66b-46f5-8cce-de29f97593b5_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692543.705 5335170.033 510.85 692543.232 5335167.803 510.85 692539.54 5335167.539 510.85 692539.457 5335167.876 510.85 692539.939 5335171.635 510.85 692540.316 5335174.565 510.85 692540.557 5335174.518 510.85 692544.511 5335173.748 510.85 692543.705 5335170.033 510.85</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006944_50b951f7-af1b-40a1-a236-157ac2c4ebdb">
<gen:stringAttribute name="Flaeche">
<gen:value>6.162</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.703</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.850</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006944_50b951f7-af1b-40a1-a236-157ac2c4ebdb_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692543.705 5335170.033 510.85 692543.705 5335170.033 513.553 692543.232 5335167.803 513.553 692543.232 5335167.803 510.85 692543.705 5335170.033 510.85</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006944_8fbea0eb-01b2-4794-b3c3-08f025e244f1">
<gen:stringAttribute name="Flaeche">
<gen:value>10.275</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.703</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.850</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006944_8fbea0eb-01b2-4794-b3c3-08f025e244f1_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692544.511 5335173.748 510.85 692544.511 5335173.748 513.553 692543.705 5335170.033 513.553 692543.705 5335170.033 510.85 692544.511 5335173.748 510.85</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006944_9775af53-4048-41e5-9cf1-1d3ba7d1447c">
<gen:stringAttribute name="Flaeche">
<gen:value>18.229</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.703</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.850</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006944_9775af53-4048-41e5-9cf1-1d3ba7d1447c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692539.457 5335167.876 513.553 692539.939 5335171.635 513.553 692540.316 5335174.565 513.553 692540.316 5335174.565 510.85 692539.939 5335171.635 510.85 692539.457 5335167.876 510.85 692539.457 5335167.876 513.553</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006944_b0fbba6d-fb2b-4ec1-9ab0-6424d614a2c3">
<gen:stringAttribute name="Flaeche">
<gen:value>10.005</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.703</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.850</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006944_b0fbba6d-fb2b-4ec1-9ab0-6424d614a2c3_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692543.232 5335167.803 510.85 692543.232 5335167.803 513.553 692539.54 5335167.539 513.553 692539.54 5335167.539 510.85 692543.232 5335167.803 510.85</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006944_cade3776-3ad5-4bec-a542-fad4939110b6">
<gen:stringAttribute name="Flaeche">
<gen:value>11.552</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.703</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.850</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006944_cade3776-3ad5-4bec-a542-fad4939110b6_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692540.557 5335174.518 513.553 692544.511 5335173.748 513.553 692544.511 5335173.748 510.85 692540.557 5335174.518 510.85 692540.316 5335174.565 510.85 692540.316 5335174.565 513.553 692540.557 5335174.518 513.553</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006944_d69850f9-1dba-4cd3-9a0c-9f404ea8ee94">
<gen:stringAttribute name="Flaeche">
<gen:value>0.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.703</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>510.850</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006944_d69850f9-1dba-4cd3-9a0c-9f404ea8ee94_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692539.54 5335167.539 510.85 692539.54 5335167.539 513.553 692539.457 5335167.876 513.553 692539.457 5335167.876 510.85 692539.54 5335167.539 510.85</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006944_10911707-fa1d-4075-b959-0a8e0f246481">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>26.264</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.703</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.553</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>2.703</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>513.553</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006944_10911707-fa1d-4075-b959-0a8e0f246481_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692539.54 5335167.539 513.553 692543.232 5335167.803 513.553 692543.705 5335170.033 513.553 692544.511 5335173.748 513.553 692540.557 5335174.518 513.553 692540.316 5335174.565 513.553 692539.939 5335171.635 513.553 692539.457 5335167.876 513.553 692539.54 5335167.539 513.553</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006947">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfnvZ</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>513.630</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.120</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>513.630</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_2000</bldg:function>
<bldg:roofType>1000</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">2.51</bldg:measuredHeight>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006947_47f7feba-b08b-424b-935d-034686c7c11e_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006947_23857719-5ec5-4324-b952-492313d16293_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006947_560bc30d-2646-4e52-bede-a921969f8995_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006947_cea55618-6b19-4588-b2df-18135b36cb52_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006947_d32352e1-675c-4745-99a5-0c1a1628c281_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006947_fdd731be-c82f-49e8-bfee-cb56d7a0e7da_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006947_f9050b58-eb89-44c4-b4d5-03721b8e1008_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006947_47f7feba-b08b-424b-935d-034686c7c11e">
<gen:stringAttribute name="Flaeche">
<gen:value>17.764</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.120</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.120</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006947_47f7feba-b08b-424b-935d-034686c7c11e_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692543.375 5335152.616 511.12 692549.599 5335151.596 511.12 692549.119 5335148.485 511.12 692545.868 5335148.989 511.12 692544.213 5335149.335 511.12 692543.375 5335152.616 511.12</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006947_23857719-5ec5-4324-b952-492313d16293">
<gen:stringAttribute name="Flaeche">
<gen:value>7.901</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.630</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.120</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006947_23857719-5ec5-4324-b952-492313d16293_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692549.599 5335151.596 511.12 692549.599 5335151.596 513.63 692549.119 5335148.485 513.63 692549.119 5335148.485 511.12 692549.599 5335151.596 511.12</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006947_560bc30d-2646-4e52-bede-a921969f8995">
<gen:stringAttribute name="Flaeche">
<gen:value>8.500</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.630</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.120</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006947_560bc30d-2646-4e52-bede-a921969f8995_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692544.213 5335149.335 511.12 692544.213 5335149.335 513.63 692543.375 5335152.616 513.63 692543.375 5335152.616 511.12 692544.213 5335149.335 511.12</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006947_cea55618-6b19-4588-b2df-18135b36cb52">
<gen:stringAttribute name="Flaeche">
<gen:value>4.244</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.630</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.120</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006947_cea55618-6b19-4588-b2df-18135b36cb52_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692545.868 5335148.989 511.12 692545.868 5335148.989 513.63 692544.213 5335149.335 513.63 692544.213 5335149.335 511.12 692545.868 5335148.989 511.12</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006947_d32352e1-675c-4745-99a5-0c1a1628c281">
<gen:stringAttribute name="Flaeche">
<gen:value>8.257</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.630</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.120</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006947_d32352e1-675c-4745-99a5-0c1a1628c281_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692549.119 5335148.485 511.12 692549.119 5335148.485 513.63 692545.868 5335148.989 513.63 692545.868 5335148.989 511.12 692549.119 5335148.485 511.12</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006947_fdd731be-c82f-49e8-bfee-cb56d7a0e7da">
<gen:stringAttribute name="Flaeche">
<gen:value>15.831</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.630</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.120</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006947_fdd731be-c82f-49e8-bfee-cb56d7a0e7da_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692543.375 5335152.616 511.12 692543.375 5335152.616 513.63 692549.599 5335151.596 513.63 692549.599 5335151.596 511.12 692543.375 5335152.616 511.12</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006947_f9050b58-eb89-44c4-b4d5-03721b8e1008">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>17.764</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.630</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>2.510</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>513.630</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006947_f9050b58-eb89-44c4-b4d5-03721b8e1008_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692544.213 5335149.335 513.63 692545.868 5335148.989 513.63 692549.119 5335148.485 513.63 692549.599 5335151.596 513.63 692543.375 5335152.616 513.63 692544.213 5335149.335 513.63</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006950">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfnp9</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>514.381</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.240</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>513.704</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_2000</bldg:function>
<bldg:roofType>1000</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">3.141</bldg:measuredHeight>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006950_47edc86b-a0d8-4ffb-8281-88c967d87d5d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006950_1c863107-29db-46d3-93bf-75bfaed90fa9_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006950_520446bd-f691-4ca5-bf9d-044815d17f46_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006950_76aefe13-4f39-42f1-ba00-e37217aecab8_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006950_8626242a-7207-4d33-9bfa-778b69a1f801_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006950_95d69d65-7c5b-450b-8cde-e30981061367_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006950_9963452e-183b-47ab-93dd-4769be59c6d2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006950_df4bef7d-7502-42c2-b11c-eac2c3d5de1d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006950_eb2548a0-b39a-4fb2-8e53-b9467a42eb35_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006950_07a60973-37ac-411d-84c2-ed4f33dee87b_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006950_47edc86b-a0d8-4ffb-8281-88c967d87d5d">
<gen:stringAttribute name="Flaeche">
<gen:value>52.486</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.240</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.240</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006950_47edc86b-a0d8-4ffb-8281-88c967d87d5d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.37 5335080.847 511.24 692537.22 5335080.831 511.24 692535.387 5335088.744 511.24 692534.438 5335092.841 511.24 692534.571 5335092.861 511.24 692534.617 5335092.868 511.24 692537.596 5335093.725 511.24 692539.018 5335086.546 511.24 692541.422 5335086.99 511.24 692542.544 5335081.33 511.24 692537.37 5335080.847 511.24</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006950_1c863107-29db-46d3-93bf-75bfaed90fa9">
<gen:stringAttribute name="Flaeche">
<gen:value>0.465</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.094</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>514.334</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.240</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006950_1c863107-29db-46d3-93bf-75bfaed90fa9_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.37 5335080.847 511.24 692537.37 5335080.847 514.316 692537.22 5335080.831 514.334 692537.22 5335080.831 511.24 692537.37 5335080.847 511.24</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006950_520446bd-f691-4ca5-bf9d-044815d17f46">
<gen:stringAttribute name="Flaeche">
<gen:value>20.148</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.753</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.993</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.240</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006950_520446bd-f691-4ca5-bf9d-044815d17f46_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.596 5335093.725 511.24 692537.596 5335093.725 513.993 692539.018 5335086.546 513.993 692539.018 5335086.546 511.24 692537.596 5335093.725 511.24</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006950_76aefe13-4f39-42f1-ba00-e37217aecab8">
<gen:stringAttribute name="Flaeche">
<gen:value>9.101</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.119</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>514.359</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.240</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006950_76aefe13-4f39-42f1-ba00-e37217aecab8_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692534.617 5335092.868 511.24 692534.617 5335092.868 514.359 692537.596 5335093.725 513.993 692537.596 5335093.725 511.24 692534.617 5335092.868 511.24</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006950_8626242a-7207-4d33-9bfa-778b69a1f801">
<gen:stringAttribute name="Flaeche">
<gen:value>6.377</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.753</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.993</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.240</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006950_8626242a-7207-4d33-9bfa-778b69a1f801_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692539.018 5335086.546 511.24 692539.018 5335086.546 513.993 692541.422 5335086.99 513.704 692541.422 5335086.99 511.24 692539.018 5335086.546 511.24</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006950_95d69d65-7c5b-450b-8cde-e30981061367">
<gen:stringAttribute name="Flaeche">
<gen:value>14.218</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.464</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.704</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.240</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006950_95d69d65-7c5b-450b-8cde-e30981061367_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692541.422 5335086.99 511.24 692541.422 5335086.99 513.704 692542.544 5335081.33 513.704 692542.544 5335081.33 511.24 692541.422 5335086.99 511.24</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006950_9963452e-183b-47ab-93dd-4769be59c6d2">
<gen:stringAttribute name="Flaeche">
<gen:value>0.567</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.141</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>514.381</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.240</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006950_9963452e-183b-47ab-93dd-4769be59c6d2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692534.438 5335092.841 514.381 692534.571 5335092.861 514.365 692534.617 5335092.868 514.359 692534.617 5335092.868 511.24 692534.571 5335092.861 511.24 692534.438 5335092.841 511.24 692534.438 5335092.841 514.381</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006950_df4bef7d-7502-42c2-b11c-eac2c3d5de1d">
<gen:stringAttribute name="Flaeche">
<gen:value>38.433</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.141</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>514.381</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.240</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006950_df4bef7d-7502-42c2-b11c-eac2c3d5de1d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692535.387 5335088.744 511.24 692537.22 5335080.831 511.24 692537.22 5335080.831 514.334 692535.387 5335088.744 514.365 692534.438 5335092.841 514.381 692534.438 5335092.841 511.24 692535.387 5335088.744 511.24</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006950_eb2548a0-b39a-4fb2-8e53-b9467a42eb35">
<gen:stringAttribute name="Flaeche">
<gen:value>14.394</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.076</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>514.316</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.240</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006950_eb2548a0-b39a-4fb2-8e53-b9467a42eb35_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692542.544 5335081.33 511.24 692542.544 5335081.33 513.704 692537.37 5335080.847 514.316 692537.37 5335080.847 511.24 692542.544 5335081.33 511.24</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006950_07a60973-37ac-411d-84c2-ed4f33dee87b">
<gen:stringAttribute name="Dachneigung">
<gen:value>83.240</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>78.778</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>52.854</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.141</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>514.381</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>2.464</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>513.704</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006950_07a60973-37ac-411d-84c2-ed4f33dee87b_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692535.387 5335088.744 514.365 692537.22 5335080.831 514.334 692537.37 5335080.847 514.316 692542.544 5335081.33 513.704 692541.422 5335086.99 513.704 692539.018 5335086.546 513.993 692537.596 5335093.725 513.993 692534.617 5335092.868 514.359 692534.571 5335092.861 514.365 692534.438 5335092.841 514.381 692535.387 5335088.744 514.365</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_5006960">
<creationDate>2026-05-26</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfosN</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>518.238</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.526</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>2000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>513.570</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_3041</bldg:function>
<bldg:roofType>2100</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">6.712</bldg:measuredHeight>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_47344eed-f597-4716-b19b-2216c7bad34b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_24453864-bba2-4ced-a34d-2842db70f83f_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_255c2d63-3eef-4326-a2c4-0e2d3bcf7b8c_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_34e30746-2289-4abd-94d2-c754dcfacbcc_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_414b0d60-2678-4f90-acb8-610e7606dc9b_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_60c8d582-01d8-4d15-9d3b-226e444d86b1_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_61ee33eb-a307-4a11-819a-4a577bee4e36_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_84e3d01d-0080-4392-add0-78c89631c14d_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_9ad36aeb-9e1f-4a45-90da-ce8ffc488888_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_dd0dc0bb-51c9-41ba-91aa-706fdc64f931_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_f5add84c-67d1-4405-9805-4d7200280af4_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_23a9c30d-2601-41a1-bd96-afd76e899016_2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_5006960_9b4059ef-ef08-4dad-986a-fdc597012c3a_2_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_5006960_47344eed-f597-4716-b19b-2216c7bad34b_2">
<gen:stringAttribute name="Flaeche">
<gen:value>10.662</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.530</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_47344eed-f597-4716-b19b-2216c7bad34b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692511.23 5335135.17 511.53 692511.85 5335135.39 511.53 692512.47 5335134.01 511.53 692512.06 5335133.81 511.53 692512.59 5335131.6 511.53 692510.93 5335130.65 511.53 692510.26 5335133.65 511.53 692508.53 5335135.23 511.53 692509.88 5335136.38 511.53 692511.23 5335135.17 511.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006960_24453864-bba2-4ced-a34d-2842db70f83f_2">
<gen:stringAttribute name="Flaeche">
<gen:value>1.433</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>5.813</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>517.339</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_24453864-bba2-4ced-a34d-2842db70f83f_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692511.23 5335135.17 511.53 692511.23 5335135.17 517.339 692511.253 5335135.178 517.336 692511.253 5335135.178 513.57 692511.85 5335135.39 513.57 692511.85 5335135.39 511.53 692511.23 5335135.17 511.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006960_255c2d63-3eef-4326-a2c4-0e2d3bcf7b8c_2">
<gen:stringAttribute name="Flaeche">
<gen:value>14.394</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>5.427</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>516.953</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_255c2d63-3eef-4326-a2c4-0e2d3bcf7b8c_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692510.93 5335130.65 511.53 692510.93 5335130.65 515.472 692510.26 5335133.65 516.953 692510.26 5335133.65 511.53 692510.93 5335130.65 511.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006960_34e30746-2289-4abd-94d2-c754dcfacbcc_2">
<gen:stringAttribute name="Flaeche">
<gen:value>10.089</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>4.994</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>516.520</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_34e30746-2289-4abd-94d2-c754dcfacbcc_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692512.06 5335133.81 511.53 692512.06 5335133.81 516.52 692512.59 5335131.6 515.418 692512.59 5335131.6 511.53 692512.06 5335133.81 511.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006960_414b0d60-2678-4f90-acb8-610e7606dc9b_2">
<gen:stringAttribute name="Flaeche">
<gen:value>14.071</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>6.592</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.118</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_414b0d60-2678-4f90-acb8-610e7606dc9b_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692510.26 5335133.65 511.53 692510.26 5335133.65 516.953 692508.53 5335135.23 518.118 692508.53 5335135.23 511.53 692510.26 5335133.65 511.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006960_60c8d582-01d8-4d15-9d3b-226e444d86b1_2">
<gen:stringAttribute name="Flaeche">
<gen:value>7.488</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.946</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.472</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_60c8d582-01d8-4d15-9d3b-226e444d86b1_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692512.59 5335131.6 511.53 692512.59 5335131.6 515.418 692510.93 5335130.65 515.472 692510.93 5335130.65 511.53 692512.59 5335131.6 511.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006960_61ee33eb-a307-4a11-819a-4a577bee4e36_2">
<gen:stringAttribute name="Flaeche">
<gen:value>11.346</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>6.712</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.238</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_61ee33eb-a307-4a11-819a-4a577bee4e36_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692509.88 5335136.38 511.53 692509.88 5335136.38 518.238 692511.23 5335135.17 517.339 692511.23 5335135.17 511.53 692509.88 5335136.38 511.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006960_84e3d01d-0080-4392-add0-78c89631c14d_2">
<gen:stringAttribute name="Flaeche">
<gen:value>5.351</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>5.810</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>517.336</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>2.044</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>513.570</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_84e3d01d-0080-4392-add0-78c89631c14d_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692511.253 5335135.178 513.57 692511.253 5335135.178 517.336 692512.114 5335133.836 516.516 692512.114 5335133.836 513.57 692511.253 5335135.178 513.57</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006960_9ad36aeb-9e1f-4a45-90da-ce8ffc488888_2">
<gen:stringAttribute name="Flaeche">
<gen:value>11.790</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>6.712</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.238</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_9ad36aeb-9e1f-4a45-90da-ce8ffc488888_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692508.53 5335135.23 511.53 692508.53 5335135.23 518.118 692509.88 5335136.38 518.238 692509.88 5335136.38 511.53 692508.53 5335135.23 511.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006960_dd0dc0bb-51c9-41ba-91aa-706fdc64f931_2">
<gen:stringAttribute name="Flaeche">
<gen:value>1.108</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>4.994</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>516.520</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_dd0dc0bb-51c9-41ba-91aa-706fdc64f931_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692512.47 5335134.01 511.53 692512.47 5335134.01 513.57 692512.114 5335133.836 513.57 692512.114 5335133.836 516.516 692512.06 5335133.81 516.52 692512.06 5335133.81 511.53 692512.47 5335134.01 511.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_5006960_f5add84c-67d1-4405-9805-4d7200280af4_2">
<gen:stringAttribute name="Flaeche">
<gen:value>3.086</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.044</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.570</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.004</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.530</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_f5add84c-67d1-4405-9805-4d7200280af4_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692511.85 5335135.39 511.53 692511.85 5335135.39 513.57 692512.47 5335134.01 513.57 692512.47 5335134.01 511.53 692511.85 5335135.39 511.53</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006960_23a9c30d-2601-41a1-bd96-afd76e899016_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>62.798</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>147.106</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>11.098</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>6.712</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>518.238</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>3.892</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>515.418</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_23a9c30d-2601-41a1-bd96-afd76e899016_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692510.26 5335133.65 516.953 692510.93 5335130.65 515.472 692512.59 5335131.6 515.418 692512.06 5335133.81 516.52 692512.114 5335133.836 516.516 692511.253 5335135.178 517.336 692511.23 5335135.17 517.339 692509.88 5335136.38 518.238 692508.53 5335135.23 518.118 692510.26 5335133.65 516.953</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_5006960_9b4059ef-ef08-4dad-986a-fdc597012c3a_2">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>0.791</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.044</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.570</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>2.044</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>513.570</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_5006960_9b4059ef-ef08-4dad-986a-fdc597012c3a_2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692512.114 5335133.836 513.57 692512.47 5335134.01 513.57 692511.85 5335135.39 513.57 692511.253 5335135.178 513.57 692512.114 5335133.836 513.57</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_52670819">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfnsN</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.340</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_2000</bldg:function>
<bldg:roofType>1000</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">2.598</bldg:measuredHeight>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670819_7d52df95-779b-4b4d-ad47-2ada35ca399c_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670819_0f27f175-c758-4f44-8520-359aa307d006_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670819_9e7282dc-6831-4ecc-8d22-461712df9613_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670819_a8f518f8-75f9-497b-9aa2-4328775bb062_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670819_ae27b484-72b8-48d4-915b-acec89ce1e02_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670819_b00cca7b-9ac3-42ad-9638-1f71e8197b45_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670819_b513b220-fd6f-4242-995a-ff25f491e49e_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670819_d8b05c5f-065a-434d-a82f-05f2cc7d4294_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670819_eaee58b3-a1b2-41a9-8ccc-13ae1cca6b6d_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670819_407581ee-430b-46d4-b540-fe3ff49dc7af_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_52670819_7d52df95-779b-4b4d-ad47-2ada35ca399c">
<gen:stringAttribute name="Flaeche">
<gen:value>18.702</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.340</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.340</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670819_7d52df95-779b-4b4d-ad47-2ada35ca399c_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.686 5335077.647 511.34 692537.341 5335080.566 511.34 692537.419 5335080.619 511.34 692537.37 5335080.847 511.34 692542.544 5335081.33 511.34 692542.561 5335081.16 511.34 692543.249 5335081.217 511.34 692543.604 5335078.298 511.34 692537.686 5335077.647 511.34</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670819_0f27f175-c758-4f44-8520-359aa307d006">
<gen:stringAttribute name="Flaeche">
<gen:value>7.639</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.340</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670819_0f27f175-c758-4f44-8520-359aa307d006_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692543.604 5335078.298 513.938 692543.604 5335078.298 511.34 692543.249 5335081.217 511.34 692543.249 5335081.217 513.938 692543.604 5335078.298 513.938</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670819_9e7282dc-6831-4ecc-8d22-461712df9613">
<gen:stringAttribute name="Flaeche">
<gen:value>0.245</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.340</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670819_9e7282dc-6831-4ecc-8d22-461712df9613_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.341 5335080.566 513.938 692537.419 5335080.619 513.938 692537.419 5335080.619 511.34 692537.341 5335080.566 511.34 692537.341 5335080.566 513.938</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670819_a8f518f8-75f9-497b-9aa2-4328775bb062">
<gen:stringAttribute name="Flaeche">
<gen:value>1.794</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.340</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670819_a8f518f8-75f9-497b-9aa2-4328775bb062_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692542.561 5335081.16 513.938 692543.249 5335081.217 513.938 692543.249 5335081.217 511.34 692542.561 5335081.16 511.34 692542.561 5335081.16 513.938</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670819_ae27b484-72b8-48d4-915b-acec89ce1e02">
<gen:stringAttribute name="Flaeche">
<gen:value>7.636</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.340</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670819_ae27b484-72b8-48d4-915b-acec89ce1e02_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.686 5335077.647 511.34 692537.686 5335077.647 513.938 692537.341 5335080.566 513.938 692537.341 5335080.566 511.34 692537.686 5335077.647 511.34</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670819_b00cca7b-9ac3-42ad-9638-1f71e8197b45">
<gen:stringAttribute name="Flaeche">
<gen:value>0.444</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.340</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670819_b00cca7b-9ac3-42ad-9638-1f71e8197b45_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692542.561 5335081.16 513.938 692542.561 5335081.16 511.34 692542.544 5335081.33 511.34 692542.544 5335081.33 513.938 692542.561 5335081.16 513.938</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670819_b513b220-fd6f-4242-995a-ff25f491e49e">
<gen:stringAttribute name="Flaeche">
<gen:value>15.468</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.340</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670819_b513b220-fd6f-4242-995a-ff25f491e49e_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.686 5335077.647 511.34 692543.604 5335078.298 511.34 692543.604 5335078.298 513.938 692537.686 5335077.647 513.938 692537.686 5335077.647 511.34</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670819_d8b05c5f-065a-434d-a82f-05f2cc7d4294">
<gen:stringAttribute name="Flaeche">
<gen:value>0.606</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.340</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670819_d8b05c5f-065a-434d-a82f-05f2cc7d4294_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.419 5335080.619 511.34 692537.419 5335080.619 513.938 692537.37 5335080.847 513.938 692537.37 5335080.847 511.34 692537.419 5335080.619 511.34</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670819_eaee58b3-a1b2-41a9-8ccc-13ae1cca6b6d">
<gen:stringAttribute name="Flaeche">
<gen:value>13.500</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.340</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670819_eaee58b3-a1b2-41a9-8ccc-13ae1cca6b6d_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.37 5335080.847 513.938 692542.544 5335081.33 513.938 692542.544 5335081.33 511.34 692537.37 5335080.847 511.34 692537.37 5335080.847 513.938</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_52670819_407581ee-430b-46d4-b540-fe3ff49dc7af">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>18.702</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>2.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>2.598</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>513.938</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670819_407581ee-430b-46d4-b540-fe3ff49dc7af_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.686 5335077.647 513.938 692543.604 5335078.298 513.938 692543.249 5335081.217 513.938 692542.561 5335081.16 513.938 692542.544 5335081.33 513.938 692537.37 5335080.847 513.938 692537.419 5335080.619 513.938 692537.341 5335080.566 513.938 692537.686 5335077.647 513.938</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</cityObjectMember>
<cityObjectMember>
<bldg:Building gml:id="DEBY_LOD2_52670821">
<creationDate>2021-03-24</creationDate>
<externalReference>
<informationSystem>http://repository.gdi-de.org/schemas/adv/citygml/fdv/art.htm#_9100</informationSystem>
<externalObject>
<name>DEBYvAAAAABSfnkG</name>
</externalObject>
</externalReference>
<gen:stringAttribute name="DatenquelleBodenhoehe">
<gen:value>1100</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleDachhoehe">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="DatenquelleLage">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Gemeindeschluessel">
<gen:value>09162000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheDach">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="HoeheGrund">
<gen:value>511.440</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Methode">
<gen:value>1000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="NiedrigsteTraufeDesGebaeudes">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Grundrissaktualitaet">
<gen:value>2026-02-06</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Geometrietyp2DReferenz">
<gen:value>3000</gen:value>
</gen:stringAttribute>
<bldg:function>31001_2000</bldg:function>
<bldg:roofType>1000</bldg:roofType>
<bldg:measuredHeight uom="urn:adv:uom:m">3.929</bldg:measuredHeight>
<bldg:lod2Solid>
<gml:Solid srsDimension="3">
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670821_622cf80c-9386-407f-b9e7-fc9f3d4c856f_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670821_2a1d4a21-42d0-47ee-998f-993089ff1d07_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670821_50ffb858-b7cf-4afa-a686-b1fdab417b62_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670821_62a5a5fa-034a-4933-898a-e54d06f909d2_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670821_6d139bfa-8427-434e-9c84-9cf5da2a82f3_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670821_9da67fec-6999-451b-8500-c3b035b814ab_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670821_b5dafe89-54eb-41c7-acd3-8b3fc36b2284_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670821_ccce512d-2d65-4e17-94ed-4ba6ea73c1c8_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670821_ce5cf96c-b519-46db-9ffd-d459aa67660a_poly"/>
<gml:surfaceMember xlink:href="#DEBY_LOD2_52670821_e23920d3-379b-4900-82b3-47a4ccf33ab8_poly"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="DEBY_LOD2_52670821_622cf80c-9386-407f-b9e7-fc9f3d4c856f">
<gen:stringAttribute name="Flaeche">
<gen:value>44.376</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>511.440</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.440</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670821_622cf80c-9386-407f-b9e7-fc9f3d4c856f_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692531.054 5335092.088 511.44 692534.212 5335092.992 511.44 692534.438 5335092.841 511.44 692537.22 5335080.831 511.44 692537.37 5335080.847 511.44 692537.419 5335080.619 511.44 692537.341 5335080.566 511.44 692533.891 5335079.731 511.44 692531.054 5335092.088 511.44</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670821_2a1d4a21-42d0-47ee-998f-993089ff1d07">
<gen:stringAttribute name="Flaeche">
<gen:value>12.906</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.929</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.440</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670821_2a1d4a21-42d0-47ee-998f-993089ff1d07_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692531.054 5335092.088 511.44 692531.054 5335092.088 515.369 692534.212 5335092.992 515.369 692534.212 5335092.992 511.44 692531.054 5335092.088 511.44</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670821_50ffb858-b7cf-4afa-a686-b1fdab417b62">
<gen:stringAttribute name="Flaeche">
<gen:value>1.068</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.929</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.440</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670821_50ffb858-b7cf-4afa-a686-b1fdab417b62_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692534.212 5335092.992 511.44 692534.212 5335092.992 515.369 692534.438 5335092.841 515.369 692534.438 5335092.841 511.44 692534.212 5335092.992 511.44</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670821_62a5a5fa-034a-4933-898a-e54d06f909d2">
<gen:stringAttribute name="Flaeche">
<gen:value>0.371</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.929</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.440</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670821_62a5a5fa-034a-4933-898a-e54d06f909d2_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.419 5335080.619 511.44 692537.419 5335080.619 515.369 692537.341 5335080.566 515.369 692537.341 5335080.566 511.44 692537.419 5335080.619 511.44</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670821_6d139bfa-8427-434e-9c84-9cf5da2a82f3">
<gen:stringAttribute name="Flaeche">
<gen:value>48.437</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.929</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.440</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670821_6d139bfa-8427-434e-9c84-9cf5da2a82f3_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692534.438 5335092.841 511.44 692534.438 5335092.841 515.369 692537.22 5335080.831 515.369 692537.22 5335080.831 511.44 692534.438 5335092.841 511.44</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670821_9da67fec-6999-451b-8500-c3b035b814ab">
<gen:stringAttribute name="Flaeche">
<gen:value>13.946</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.929</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.440</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670821_9da67fec-6999-451b-8500-c3b035b814ab_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.341 5335080.566 511.44 692537.341 5335080.566 515.369 692533.891 5335079.731 515.369 692533.891 5335079.731 511.44 692537.341 5335080.566 511.44</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670821_b5dafe89-54eb-41c7-acd3-8b3fc36b2284">
<gen:stringAttribute name="Flaeche">
<gen:value>49.814</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.929</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.440</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670821_b5dafe89-54eb-41c7-acd3-8b3fc36b2284_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692533.891 5335079.731 511.44 692533.891 5335079.731 515.369 692531.054 5335092.088 515.369 692531.054 5335092.088 511.44 692533.891 5335079.731 511.44</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670821_ccce512d-2d65-4e17-94ed-4ba6ea73c1c8">
<gen:stringAttribute name="Flaeche">
<gen:value>0.593</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.929</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.440</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670821_ccce512d-2d65-4e17-94ed-4ba6ea73c1c8_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.22 5335080.831 511.44 692537.22 5335080.831 515.369 692537.37 5335080.847 515.369 692537.37 5335080.847 511.44 692537.22 5335080.831 511.44</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="DEBY_LOD2_52670821_ce5cf96c-b519-46db-9ffd-d459aa67660a">
<gen:stringAttribute name="Flaeche">
<gen:value>0.916</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.929</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>0.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>511.440</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670821_ce5cf96c-b519-46db-9ffd-d459aa67660a_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692537.37 5335080.847 511.44 692537.37 5335080.847 515.369 692537.419 5335080.619 515.369 692537.419 5335080.619 511.44 692537.37 5335080.847 511.44</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="DEBY_LOD2_52670821_e23920d3-379b-4900-82b3-47a4ccf33ab8">
<gen:stringAttribute name="Dachneigung">
<gen:value>90.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Dachorientierung">
<gen:value>-1.000</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Flaeche">
<gen:value>44.376</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX">
<gen:value>3.929</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MAX_ASL">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN">
<gen:value>3.929</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="Z_MIN_ASL">
<gen:value>515.369</gen:value>
</gen:stringAttribute>
<bldg:lod2MultiSurface>
<gml:MultiSurface srsDimension="3">
<gml:surfaceMember>
<gml:Polygon gml:id="DEBY_LOD2_52670821_e23920d3-379b-4900-82b3-47a4ccf33ab8_poly">
<gml:exterior>
<gml:LinearRing>
<gml:posList>692533.891 5335079.731 515.369 692537.341 5335080.566 515.369 692537.419 5335080.619 515.369 692537.37 5335080.847 515.369 692537.22 5335080.831 515.369 692534.438 5335092.841 515.369 692534.212 5335092.992 515.369 692531.054 5335092.088 515.369 692533.891 5335079.731 515.369</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</cityObjectMember>
</CityModel>
